/* ==========================================================================
   AERO-TWIN: MASTER APPLICATION CONTROLLER & TELEMETRY COORDINATOR
   SIH 2026 Problem Statement ID: 26054 (DRDO / iDEX MALE UAV Aero Piston Engine)
   ========================================================================== */

// Tactical Web Audio API Synthesizer
class TacticalAudio {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) this.ctx = new AudioContext();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  playClick() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.04);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  playCaution() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(587.33, this.ctx.currentTime); // D5
    osc.frequency.setValueAtTime(880, this.ctx.currentTime + 0.1); // A5
    gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.36);
  }

  playAlarm() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(950, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(350, this.ctx.currentTime + 0.25);
    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.3);
  }

  playChirp() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1800, this.ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.07, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.09);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.1);
  }
}

// Master Application Entry
document.addEventListener('DOMContentLoaded', () => {
  const soundFx = new TacticalAudio();
  const telemetry = new TelemetryEngine();
  const aiEngine = new AIDiagnosticNet();
  const engine3D = new AeroEngine3D('engine-canvas-3d');
  const subsystem3D = new Subsystem3DViewer('subsystem-cad-canvas');
  const missionPlanner = new MissionPlanner('mission-radar-canvas', telemetry, aiEngine, soundFx);
  const faultSim = new FaultSimulator(telemetry, soundFx);
  const reportGen = new ReportGenerator(telemetry, aiEngine);
  const hardwareLink = new HardwareLink(telemetry);

  // Bind Telemetry Stream to 3D Renderer & UI
  telemetry.onUpdate((state, fftBins) => {
    // 1. Update 3D Canvas
    engine3D.updateTelemetry(state);
    if (subsystem3D) subsystem3D.updateTelemetry(state);

    // 2. Run AI Diagnostic Network
    const aiResult = aiEngine.evaluate(state, fftBins);

    // 3. Update DOM Telemetry Elements
    updateTelemetryUI(state, aiResult);

    // 4. Update FFT Canvas
    renderFftSpectrum(fftBins);
    if (typeof renderVibeModal === 'function') {
      renderVibeModal();
    }

    // 5. Update CAN-Bus Terminal
    renderCanBusTerminal(state.canFrames);

    // 6. Update Mission Advisory
    updateMissionAdvisory(state, aiResult);
  });

  // =========================================================================
  // CENTRALIZED NAVIGATION, BROWSER HISTORY & HOME PORTAL CONTROLLER
  // =========================================================================
  const navTabs = document.querySelectorAll('.nav-tab-btn');
  const viewSections = document.querySelectorAll('.view-section');
  const btnBackToHome = document.getElementById('btn-back-to-home');
  const pillTwinBackHome = document.getElementById('pill-twin-back-home');

  const VALID_VIEWS = ['view-home', 'view-twin', 'view-mission', 'view-sandbox'];
  let currentActiveView = 'view-home';

  function updateBackButtonsVisibility(targetView) {
    if (btnBackToHome) {
      btnBackToHome.style.display = (targetView === 'view-home') ? 'none' : 'inline-flex';
    }
  }

  function navigateToView(targetView, updateHistory = true) {
    if (!targetView || !VALID_VIEWS.includes(targetView) || !document.getElementById(targetView)) {
      targetView = 'view-home';
    }

    try { soundFx.playClick(); } catch (e) {}

    currentActiveView = targetView;
    updateBackButtonsVisibility(targetView);

    // Synchronize browser history so native Back button returns to Home without closing the page
    if (updateHistory) {
      try {
        const targetHash = '#' + targetView;
        if (window.location.hash !== targetHash) {
          history.pushState({ view: targetView }, '', targetHash);
        }
      } catch (err) {
        console.warn('[AERO-TWIN] History pushState error:', err);
      }
    }

    navTabs.forEach(t => {
      const match = t.getAttribute('data-view') === targetView;
      t.classList.toggle('active', match);
      t.setAttribute('aria-selected', match ? 'true' : 'false');
    });

    viewSections.forEach(v => {
      v.classList.toggle('active-view', v.id === targetView);
    });

    const activeSection = document.getElementById(targetView);
    if (activeSection) {
      const syncCanvases = () => {
        if (targetView === 'view-twin') {
          engine3D.initCanvasSize();
          engine3D.render();
          if (subsystem3D) {
            subsystem3D.initCanvasSize();
            subsystem3D.render();
          }
        } else if (targetView === 'view-mission') {
          missionPlanner.initCanvasSize();
        } else if (targetView === 'view-sandbox') {
          syncSandboxSliders(faultSim.currentScenario);
        }
      };

      // Immediate sync
      syncCanvases();
      // Sync after layout settles
      setTimeout(syncCanvases, 50);
      // Sync after fadeIn animation completes
      setTimeout(syncCanvases, 260);

      if (typeof window.scrollTo === 'function') {
        try {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (e) {
          try { window.scrollTo(0, 0); } catch (e2) {}
        }
      }
    }
  }

  // Intercept Browser Back / Forward buttons & Hash Changes
  window.addEventListener('popstate', (event) => {
    // 1. If any modal dialog is currently open, close the modal first without leaving the page
    const activeModal = document.querySelector('.modal-backdrop.active');
    if (activeModal) {
      activeModal.classList.remove('active');
      try { soundFx.playClick(); } catch (e) {}
      try {
        history.pushState({ view: currentActiveView }, '', '#' + currentActiveView);
      } catch (e) {}
      return;
    }

    // 2. Resolve destination view: default to 'view-home' if back was pressed
    let targetView = 'view-home';
    if (event.state && event.state.view && VALID_VIEWS.includes(event.state.view)) {
      targetView = event.state.view;
    } else if (window.location.hash) {
      const hashView = window.location.hash.replace('#', '');
      if (VALID_VIEWS.includes(hashView)) {
        targetView = hashView;
      }
    }

    // 3. Navigate smoothly to target view (prevent duplicate pushState)
    navigateToView(targetView, false);
  });

  // Initialize initial history state on page load: ALWAYS default to Home View
  try {
    let initialView = 'view-home';
    const rawHash = window.location.hash ? window.location.hash.replace('#', '') : '';
    if (VALID_VIEWS.includes(rawHash)) {
      initialView = rawHash;
    }
    currentActiveView = initialView;
    try {
      history.replaceState({ view: initialView }, '', '#' + initialView);
    } catch (e) {}
    navigateToView(initialView, false);
  } catch (err) {
    console.warn('[AERO-TWIN] History init error:', err);
    navigateToView('view-home', false);
  }

  // Header Nav Tabs
  navTabs.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetView = btn.getAttribute('data-view');
      navigateToView(targetView, true);
    });
  });

  // Dedicated "BACK TO HOME" Header Button
  if (btnBackToHome) {
    btnBackToHome.addEventListener('click', () => {
      navigateToView('view-home', true);
    });
  }

  // "BACK TO HOME" Scenario Strip Pill in 3D Cockpit
  if (pillTwinBackHome) {
    pillTwinBackHome.addEventListener('click', () => {
      navigateToView('view-home', true);
    });
  }

  // Header Brand Logo click returns to Home Page
  const brandHomeLink = document.getElementById('brand-home-link');
  if (brandHomeLink) {
    brandHomeLink.addEventListener('click', () => {
      navigateToView('view-home', true);
    });
    brandHomeLink.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        navigateToView('view-home', true);
      }
    });
  }

  // Home Hero Primary & Secondary CTA Buttons
  const btnHomeLaunchCockpit = document.getElementById('btn-home-launch-cockpit');
  if (btnHomeLaunchCockpit) {
    btnHomeLaunchCockpit.addEventListener('click', () => navigateToView('view-twin'));
  }

  const btnHomeMission = document.getElementById('btn-home-mission');
  if (btnHomeMission) {
    btnHomeMission.addEventListener('click', () => navigateToView('view-mission'));
  }

  const btnHomeSandbox = document.getElementById('btn-home-sandbox');
  if (btnHomeSandbox) {
    btnHomeSandbox.addEventListener('click', () => navigateToView('view-sandbox'));
  }

  const btnHomePreflight = document.getElementById('btn-home-preflight');
  if (btnHomePreflight) {
    btnHomePreflight.addEventListener('click', () => {
      const pBtn = document.getElementById('btn-open-preflight');
      if (pBtn) pBtn.click();
    });
  }

  // Home Module Showcase Cards Direct Action Triggers
  const btnHomeCardTwin = document.getElementById('btn-home-card-twin');
  if (btnHomeCardTwin) {
    btnHomeCardTwin.addEventListener('click', () => navigateToView('view-twin'));
  }

  const btnHomeCardPinn = document.getElementById('btn-home-card-pinn');
  if (btnHomeCardPinn) {
    btnHomeCardPinn.addEventListener('click', () => {
      const btnHeaderDeep = document.getElementById('btn-header-deep-ai');
      const btnCockpitDeep = document.getElementById('btn-cockpit-deep-ai');
      const aiDeep = document.getElementById('ai-deep-modal');
      if (btnHeaderDeep) {
        btnHeaderDeep.click();
      } else if (btnCockpitDeep) {
        btnCockpitDeep.click();
      } else if (aiDeep) {
        try { soundFx.playClick(); } catch (e) {}
        aiDeep.classList.add('active');
        if (typeof renderAIDeepModal === 'function') renderAIDeepModal();
      }
    });
  }

  const btnHomeCardMission = document.getElementById('btn-home-card-mission');
  if (btnHomeCardMission) {
    btnHomeCardMission.addEventListener('click', () => navigateToView('view-mission'));
  }

  const btnHomeCardSandbox = document.getElementById('btn-home-card-sandbox');
  if (btnHomeCardSandbox) {
    btnHomeCardSandbox.addEventListener('click', () => navigateToView('view-sandbox'));
  }

  const btnHomeCardPreflight = document.getElementById('btn-home-card-preflight');
  if (btnHomeCardPreflight) {
    btnHomeCardPreflight.addEventListener('click', () => {
      const pBtn = document.getElementById('btn-open-preflight');
      if (pBtn) pBtn.click();
    });
  }

  const btnHomeCardHardware = document.getElementById('btn-home-card-hardware');
  if (btnHomeCardHardware) {
    btnHomeCardHardware.addEventListener('click', () => {
      const hBtn = document.getElementById('btn-open-hardware');
      if (hBtn) hBtn.click();
    });
  }

  // Home Architecture Banner Modals
  const btnHomeDossier = document.getElementById('btn-home-dossier');
  if (btnHomeDossier) {
    btnHomeDossier.addEventListener('click', () => {
      const dBtn = document.getElementById('btn-open-dossier');
      if (dBtn) dBtn.click();
    });
  }

  const btnHomeReport = document.getElementById('btn-home-report');
  if (btnHomeReport) {
    btnHomeReport.addEventListener('click', () => {
      const rBtn = document.getElementById('btn-open-report');
      if (rBtn) rBtn.click();
    });
  }

  // Make entire Home Module Cards interactive and clickable
  const bindCardSurfaceClick = (cardId, action) => {
    const card = document.getElementById(cardId);
    if (!card) return;
    card.style.cursor = 'pointer';
    card.addEventListener('click', (e) => {
      if (e.target.closest('button')) return; // Button handles its own click
      action();
    });
  };

  bindCardSurfaceClick('card-mod-twin', () => navigateToView('view-twin'));
  bindCardSurfaceClick('card-mod-pinn', () => {
    const btnHeaderDeep = document.getElementById('btn-header-deep-ai');
    if (btnHeaderDeep) btnHeaderDeep.click();
  });
  bindCardSurfaceClick('card-mod-mission', () => navigateToView('view-mission'));
  bindCardSurfaceClick('card-mod-sandbox', () => navigateToView('view-sandbox'));
  bindCardSurfaceClick('card-mod-preflight', () => {
    const pBtn = document.getElementById('btn-open-preflight');
    if (pBtn) pBtn.click();
  });
  bindCardSurfaceClick('card-mod-hardware', () => {
    const hBtn = document.getElementById('btn-open-hardware');
    if (hBtn) hBtn.click();
  });

  // Viewport Camera Mode Buttons
  const camBtns = document.querySelectorAll('.cam-btn[data-mode]');
  camBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      camBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      engine3D.setViewMode(btn.getAttribute('data-mode'));
    });
  });

  // Camera Presets
  const presetBtns = document.querySelectorAll('.cam-btn[data-preset]');
  presetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      presetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      engine3D.setCameraPreset(btn.getAttribute('data-preset'));
    });
  });

  // 3D Leader-Line Labels Toggle
  const labelsToggleBtn = document.getElementById('btn-toggle-3d-labels');
  if (labelsToggleBtn) {
    labelsToggleBtn.addEventListener('click', () => {
      soundFx.playClick();
      engine3D.showLabels = !engine3D.showLabels;
      labelsToggleBtn.classList.toggle('active', engine3D.showLabels);
    });
  }

  // Defect Inspector Scroll & Highlight Action
  const inspectorToggleBtn = document.getElementById('btn-toggle-inspector');
  const headerInspectorBtn = document.getElementById('btn-header-inspector');
  const defectInspectorPanel = document.getElementById('component-defect-inspector');

  const scrollToInspector = () => {
    soundFx.playClick();
    if (defectInspectorPanel) {
      defectInspectorPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
      defectInspectorPanel.classList.add('highlight-pulse');
      setTimeout(() => defectInspectorPanel.classList.remove('highlight-pulse'), 1600);
    }
  };

  if (inspectorToggleBtn) inspectorToggleBtn.addEventListener('click', scrollToInspector);
  if (headerInspectorBtn) headerInspectorBtn.addEventListener('click', scrollToInspector);

  // 3D Focus Camera on Active Component Button
  const focusCompBtn = document.getElementById('btn-focus-current-comp');
  if (focusCompBtn) {
    focusCompBtn.addEventListener('click', () => {
      soundFx.playClick();
      engine3D.focusOn(engine3D.activeComponentKey);
      const viewportCard = document.querySelector('.viewport-card');
      if (viewportCard) {
        viewportCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  }

  // Comprehensive Subsystem Anatomy & Operating Principle Educational Guide Data
  const SUBSYSTEM_ANATOMY_GUIDE_DATA = {
    cyl1: {
      tag: 'CEMILAC AERO-CYL-101 • BANK A (FRONT LEFT)',
      fn: 'Houses the front-left reciprocating combustion chamber, converting high-pressure deflagration expansion into rotary shaft horsepower via the #1 crank throw.',
      principle: 'Operates on the 4-stroke Otto cycle (Intake, Compression, Power, Exhaust) over 720° crankshaft rotation. Fires at 0° crank angle with opposed Boxer dynamic balance canceling primary vibration forces.',
      specs: 'Bore: 97.5mm • Stroke: 82mm • Displacement: 612cc • CHT limit: 185°C continuous / 215°C transient • Dual aviation spark plugs.',
      failure: 'Exhaust valve margin erosion, pre-ignition knock (3.2 kHz acoustic spike), cylinder cooling fin airflow masking, head gasket micro-blowby.'
    },
    cyl2: {
      tag: 'CEMILAC AERO-CYL-202 • BANK B (FRONT RIGHT)',
      fn: 'Houses the front-right combustion chamber, driving #2 crank throw with balanced counter-thrust directly opposite Cylinder 1.',
      principle: 'Fires at 180° crank angle (π radians phase shift). Provides Boxer horizontal counter-oscillation that naturally cancels primary shaking forces.',
      specs: 'Bore: 97.5mm • Stroke: 82mm • Compression: 9.5:1 • Spark advance: 22° BTDC • Max EGT limit: 850°C • High-conductivity aluminum-nickel alloy head.',
      failure: 'Lean-misfire from injector spray pattern distortion, spark plug gap fouling, wrist pin bushing galling under low-viscosity cold oil.'
    },
    cyl3: {
      tag: 'CEMILAC AERO-CYL-304 • BANK A (REAR LEFT)',
      fn: 'Houses the rear-left combustion chamber. Located furthest down the cooling air baffle plenum, making it the most thermally demanding cylinder.',
      principle: 'Fires at 360° crank angle (2π radians phase shift). Employs high-lift sodium-filled exhaust valves to conduct combustion heat through bronze guides.',
      specs: 'Max CHT: 185°C continuous (215°C transient) • Bore: 97.5mm • Stroke: 82mm • Compression: 9.5:1 • Dual aviation spark plugs.',
      failure: 'Pre-ignition acoustic knock (3200 Hz), thermal runaway from cooling baffle leak, valve seat micro-cracking from steep thermal gradients.'
    },
    cyl4: {
      tag: 'CEMILAC AERO-CYL-403 • BANK B (REAR RIGHT)',
      fn: 'Houses the rear-right combustion chamber, driving #4 crank throw adjacent to the rear starter ring flywheel and magneto drive gear.',
      principle: 'Fires at 540° crank angle (3π radians phase shift). Completes the 720° engine cycle with smooth 180° power stroke spacing.',
      specs: 'Bore: 97.5mm • Stroke: 82mm • Displacement: 612cc • Nitride-hardened steel liner • ARP 2000 connecting rod cap bolts (45 Nm).',
      failure: 'Ring flutter at high RPM (overspeed >4800 RPM), intake runner seal vacuum leak, high crankcase blowby pressure (>0.15 bar).'
    },
    turbo: {
      tag: 'CEMILAC AERO-TC-501 • VARIABLE FLIGHT WASTEGATE',
      fn: 'Recovers residual thermal energy from 800°C exhaust gas to drive a centrifugal compressor, maintaining sea-level manifold pressure up to 25,000 ft altitude.',
      principle: 'Radial inflow turbine spinning up to 140,000 RPM powers a billet 8-blade compressor. Electronic wastegate actuator bleeds exhaust to maintain target MAP (34.5 inHg).',
      specs: 'Max Turbo Speed: 145,000 RPM • Max Compressor Temp: 140°C • Peak Boost: 1.35 bar (39.9 inHg) • CHRA Oil Flow: 1.8 L/min at 50 PSI.',
      failure: 'Wastegate pneumatic line leak or mechanical linkage binding (overboost / underboost), journal bearing carbon coking during hot shut-down, turbine wheel surge.'
    },
    crankshaft: {
      tag: 'CEMILAC AERO-CRK-400 • FORGED STEEL BOXER',
      fn: 'Transfers combustion power pulses from all 4 connecting rods into a continuous rotary torque, driving the propeller reduction gearbox and accessory gears.',
      principle: 'Precision 4-throw flat-plane layout with 4 aerodynamic counterweight webs (180° boxer phasing). Dynamically balanced to ISO G2.5 standard.',
      specs: 'Material: 4340 Forged Chrome-Moly Steel • Journal Diameter: 52.0mm • Max Torsional Harmonic: <0.25° at 4200 RPM • Flywheel: 20-tooth starter ring.',
      failure: 'Hydrodynamic journal oil film collapse (<25 PSI), main bearing journal scuffing, torsional fatigue micro-fractures, flywheel attachment bolt shear.'
    },
    oil_system: {
      tag: 'CEMILAC AERO-LUB-102 • DRY/WET SUMP CIRCULATION',
      fn: 'Delivers continuous pressurized 15W-50 synthetic oil to crankshaft bearings, camshaft lobes, hydraulic lifters, cylinder walls, and turbo CHRA bearings.',
      principle: 'Crank-driven positive-displacement gerotor pump draws oil through fine mesh pickup screen, circulating through an external heat exchanger and 10-micron filter.',
      specs: 'Normal Pressure: 45–65 PSI (min 30 PSI at idle) • Oil Temp: 75–105°C (max 120°C) • Sump Capacity: 5.5 Liters • Filter Bypass Valve: 18 PSI diff.',
      failure: 'Suction aerated cavitation at high bank angles or low level, pressure relief spring fatigue, oil filter element clogging (bypassing raw debris), cooler clogging.'
    },
    fuel_system: {
      tag: 'CEMILAC AERO-FMS-200 • MULTI-PORT ELECTRONIC INJECTION',
      fn: 'Atomizes and meters aviation gasoline (AvGas 100LL or unleaded Mogas 95) with stoichiometric precision into each intake runner via sequential multi-port injectors.',
      principle: 'High-pressure electric vane pump pressurizes the anodized aluminum fuel rail to 43.5 PSI. Dual ECU circuits modulate injector pulse width (PWM) from mass airflow.',
      specs: 'Rail Pressure: 3.0 bar (43.5 PSI) • Injector Flow: 380 cc/min • Return Rate: 45 L/hr • Emergency Firewall Shutoff: Solenoid fail-closed in <150ms.',
      failure: 'Nozzle varnish / micro-debris clogging, fuel rail vapor lock at high altitude and hot ambient, fuel pump relay drop-out, fuel-water contamination.'
    },
    gearbox: {
      tag: 'CEMILAC AERO-PRSU-150 • HELICAL REDUCTION UNIT',
      fn: 'Reduces high engine speed (4200–5000 RPM) to optimal propeller aerodynamic efficiency speed (2100–2500 RPM) while absorbing propeller gyroscopic moments.',
      principle: 'Case-hardened single-stage helical spur gear train (ratio 1.95:1) with integrated torsional rubber damper or slipper clutch to smooth firing pulses.',
      specs: 'Gear Ratio: 1.95:1 (Engine 4200 RPM -> Prop 2154 RPM) • Max Input Torque: 380 Nm • Helical Angle: 17.5° • Dual Angular-Contact Thrust Bearings.',
      failure: 'Gear tooth flank micro-pitting, torsional elastomeric isolator delamination, thrust bearing end-play excess (>0.12mm), reduction casing oil seal weep.'
    },
    uav_airframe: {
      tag: 'DRDO TAPAS-BH-201 MALE UAV PLATFORM • ADE / CEMILAC CERTIFIED',
      fn: 'Medium Altitude Long Endurance (MALE) Unmanned Aerial Vehicle designed for continuous 18+ hours intelligence, surveillance, and reconnaissance (ISR) missions.',
      principle: 'High-aspect-ratio carbon-composite airframe with twin tail booms and an inverted V-tail (ruddervators). Pusher engine configuration minimizes nose drag and leaves the front fuselage clear for EO/IR payloads and SATCOM antennas.',
      specs: 'Wingspan: 20.6 M (67.6 FT) • Length: 9.5 M • MTOW: 1,800 KG • Payload: 350 KG • Propulsion: 115 HP Turbocharged Boxer Aero Piston Engine • Service Ceiling: 30,000 FT • Cruise Speed: 118 KTS • Glide Ratio: 14.8:1.',
      failure: 'Airframe structural stress during turbulence, engine firewall overheat, ice accumulation on leading edges at high altitude, actuator servo failure.'
    }
  };

  const updateEducationalGuideDOM = (compKey) => {
    const data = SUBSYSTEM_ANATOMY_GUIDE_DATA[compKey] || SUBSYSTEM_ANATOMY_GUIDE_DATA['cyl3'];
    const tagEl = document.getElementById('guide-subsystem-tag');
    const fnEl = document.getElementById('guide-function-desc');
    const principleEl = document.getElementById('guide-principle-desc');
    const specsEl = document.getElementById('guide-specs-desc');
    const failureEl = document.getElementById('guide-failure-desc');

    if (tagEl) tagEl.textContent = data.tag;
    if (fnEl) fnEl.textContent = data.fn;
    if (principleEl) principleEl.textContent = data.principle;
    if (specsEl) specsEl.textContent = data.specs;
    if (failureEl) failureEl.textContent = data.failure;
  };

  // Quick Component Selector Pills
  const compPills = document.querySelectorAll('#component-quick-pills .comp-pill');
  compPills.forEach(pill => {
    pill.addEventListener('click', () => {
      const compKey = pill.getAttribute('data-comp');
      if (compKey) {
        soundFx.playClick();
        engine3D.inspectComponent(compKey);
        if (subsystem3D) subsystem3D.loadSubsystem(compKey);
        updateEducationalGuideDOM(compKey);
      }
    });
  });

  // Dynamic On-Demand Component Emergency Trigger Controller
  const COMPONENT_SHORT_NAMES = {
    cyl1: 'CYLINDER #1',
    cyl2: 'CYLINDER #2',
    cyl3: 'CYLINDER #3',
    cyl4: 'CYLINDER #4',
    turbo: 'TURBOCHARGER',
    crankshaft: 'CRANKSHAFT',
    oil_system: 'OIL PUMP',
    fuel_system: 'FUEL RAIL',
    gearbox: 'PRSU GEARBOX',
    uav_airframe: 'UAV AIRFRAME'
  };

  let isComponentEmergencyActive = false;
  let activeEmergencyCompKey = null;

  const btnTriggerCompEmergency = document.getElementById('btn-trigger-component-emergency');
  const btnCadEmergencyTrigger = document.getElementById('btn-cad-emergency-trigger');
  const btnQuickEmergency = document.getElementById('btn-quick-emergency');
  const emergencyBtns = [btnTriggerCompEmergency, btnCadEmergencyTrigger, btnQuickEmergency].filter(Boolean);

  function updateEmergencyButtonsUI(compKey) {
    const currentComp = compKey || engine3D.activeComponentKey || 'cyl3';
    const name = COMPONENT_SHORT_NAMES[currentComp] || 'COMPONENT';
    const isThisActive = isComponentEmergencyActive && (activeEmergencyCompKey === currentComp);

    emergencyBtns.forEach(btn => {
      if (isThisActive) {
        btn.innerHTML = `<span>🛡️ RESTORE ${name} (NOMINAL)</span>`;
        btn.classList.add('emergency-active');
        btn.title = `Click to restore ${name} back to healthy nominal flight envelope`;
      } else {
        btn.innerHTML = `<span>🚨 TRIGGER ${name} EMERGENCY</span>`;
        btn.classList.remove('emergency-active');
        btn.title = `Simulate critical in-flight failure on ${name} for defense evaluation`;
      }
    });
  }

  function toggleComponentEmergency() {
    const compKey = engine3D.activeComponentKey || 'cyl3';
    if (!isComponentEmergencyActive || activeEmergencyCompKey !== compKey) {
      soundFx.playAlarm();
      faultSim.triggerComponentEmergency(compKey);
      isComponentEmergencyActive = true;
      activeEmergencyCompKey = compKey;
      updateEmergencyButtonsUI(compKey);
      if (compKey === 'fuel_system' || compKey === 'uav_airframe') {
        updateFuelWallUI(true);
      } else {
        updateFuelWallUI(false);
      }
    } else {
      soundFx.playChirp();
      faultSim.clearComponentEmergency();
      isComponentEmergencyActive = false;
      activeEmergencyCompKey = null;
      updateEmergencyButtonsUI(compKey);
      updateFuelWallUI(false);
      missionPlanner.reset();
    }
  }

  emergencyBtns.forEach(btn => {
    btn.addEventListener('click', toggleComponentEmergency);
  });

  // Hook up direct canvas picking on main 3D engine model to also update dedicated subsystem 3D viewer, guide & emergency button
  const originalInspect = engine3D.inspectComponent.bind(engine3D);
  engine3D.inspectComponent = (compKey) => {
    originalInspect(compKey);
    if (subsystem3D) subsystem3D.loadSubsystem(compKey);
    updateEducationalGuideDOM(compKey);
    updateEmergencyButtonsUI(compKey);
  };

  // Subsystem CAD View Mode Buttons (SOLID, CUTAWAY, EXPLODED, X-RAY)
  const cadModeBtns = document.querySelectorAll('.cad-btn[data-cad-mode]');
  cadModeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      cadModeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (subsystem3D) subsystem3D.setViewMode(btn.getAttribute('data-cad-mode'));
    });
  });

  // Subsystem CAD 3D Anatomy Labels Toggle
  const cadAnatomyBtn = document.getElementById('btn-cad-anatomy');
  if (cadAnatomyBtn) {
    cadAnatomyBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.toggleAnatomyLabels();
    });
  }

  // Subsystem CAD Slow-Mo Toggle
  const cadSlowMoBtn = document.getElementById('btn-cad-slowmo');
  if (cadSlowMoBtn) {
    cadSlowMoBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.toggleSlowMo();
    });
  }

  // Subsystem CAD Kinematic Speed Selector (1.0x LIVE, 0.2x, 0.05x SLOW-MO, 0.01x ULTRA)
  const cadSpeedBtns = document.querySelectorAll('#cad-speed-pills .speed-btn');
  cadSpeedBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      const spd = parseFloat(btn.getAttribute('data-speed'));
      if (subsystem3D) subsystem3D.setKinematicSpeed(spd);
    });
  });

  // Freeze/Resume Playback Toggle Button
  const pauseToggleBtn = document.getElementById('btn-cad-pause-toggle');
  if (pauseToggleBtn) {
    pauseToggleBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.togglePause();
    });
  }

  // Step -15° and +15° Manual Scrubber Buttons
  const stepPrevBtn = document.getElementById('btn-cad-step-prev');
  if (stepPrevBtn) {
    stepPrevBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.stepCrankAngle(-15);
    });
  }

  const stepNextBtn = document.getElementById('btn-cad-step-next');
  if (stepNextBtn) {
    stepNextBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.stepCrankAngle(15);
    });
  }

  // Subsystem CAD Auto-Spin Button
  const cadAutoSpinBtn = document.getElementById('btn-cad-autorotate');
  if (cadAutoSpinBtn) {
    cadAutoSpinBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) subsystem3D.toggleAutoRotate();
    });
  }

  // Subsystem CAD Reset Button
  const cadResetBtn = document.getElementById('btn-cad-reset');
  if (cadResetBtn) {
    cadResetBtn.addEventListener('click', () => {
      soundFx.playClick();
      if (subsystem3D) {
        subsystem3D.setViewMode('solid');
        subsystem3D.resetCamera();
      }
      cadModeBtns.forEach(b => b.classList.remove('active'));
      const solidCadBtn = document.querySelector('.cad-btn[data-cad-mode="solid"]');
      if (solidCadBtn) solidCadBtn.classList.add('active');
    });
  }

  // Initial populate of 3D Defect Inspector (starts in ISO view with Cyl 3 diagnostics)
  engine3D.activeComponentKey = 'cyl3';
  engine3D.updateComponentInspectorDOM('cyl3');
  if (subsystem3D) subsystem3D.loadSubsystem('cyl3');
  updateEducationalGuideDOM('cyl3');
  updateEmergencyButtonsUI('cyl3');

  // UI Helper for Fuel Wall Button and State
  const updateFuelWallUI = (isCutoff) => {
    const statusTxt = document.getElementById('fuel-wall-status-txt');
    const toggleBtn = document.getElementById('btn-toggle-fuel-wall');
    const sandboxVal = document.getElementById('val-sandbox-fuel-wall');
    const sandboxBtn = document.getElementById('btn-sandbox-fuel-wall');

    if (isCutoff) {
      if (statusTxt) statusTxt.textContent = '🚨 FUEL WALL: CLOSED (CUTOFF)';
      if (toggleBtn) {
        toggleBtn.style.borderColor = 'var(--crimson-crit)';
        toggleBtn.style.color = 'var(--crimson-crit)';
      }
      if (sandboxVal) {
        sandboxVal.textContent = 'CLOSED (CUTOFF / STARVED)';
        sandboxVal.style.color = 'var(--crimson-crit)';
      }
      if (sandboxBtn) {
        sandboxBtn.textContent = 'RESTORE FUEL FLOW (ARM VALVE)';
        sandboxBtn.className = 'tactical-btn';
        sandboxBtn.style.borderColor = 'var(--emerald-safe)';
        sandboxBtn.style.color = 'var(--emerald-safe)';
      }
    } else {
      if (statusTxt) statusTxt.textContent = '🛡️ FUEL WALL: OPEN (ARMED)';
      if (toggleBtn) {
        toggleBtn.style.borderColor = 'var(--emerald-safe)';
        toggleBtn.style.color = 'var(--emerald-safe)';
      }
      if (sandboxVal) {
        sandboxVal.textContent = 'OPEN (ARMED)';
        sandboxVal.style.color = 'var(--emerald-safe)';
      }
      if (sandboxBtn) {
        sandboxBtn.textContent = 'TRIGGER FUEL WALL CUTOFF';
        sandboxBtn.className = 'tactical-btn danger';
        sandboxBtn.style.borderColor = '';
        sandboxBtn.style.color = '';
      }
    }
  };

  // Synchronize Sandbox Sliders & Value Labels based on selected scenario
  function syncSandboxSliders(scenario) {
    const cyl3Slider = document.getElementById('slider-cyl3-heat');
    const wgSlider = document.getElementById('slider-wg-leak');
    const oilSlider = document.getElementById('slider-oil-wear');
    const vibeSlider = document.getElementById('slider-bearing-wear');
    const throttleSlider = document.getElementById('slider-throttle');
    const afrSlider = document.getElementById('slider-afr-mixture');
    const fuelLeakSlider = document.getElementById('slider-fuel-leak');

    if (scenario === 'nominal') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0;
      safeSetText('val-bearing-wear', '0%');
      if (throttleSlider) throttleSlider.value = 75;
      safeSetText('val-throttle', '75%');
      if (afrSlider) afrSlider.value = 0;
      safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('cyl3');
    } else if (scenario === 'cyl3_thermal') {
      if (cyl3Slider) cyl3Slider.value = 72;
      safeSetText('val-cyl3-heat', '+72°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0;
      safeSetText('val-bearing-wear', '0%');
      if (throttleSlider) throttleSlider.value = 82;
      safeSetText('val-throttle', '82%');
      if (afrSlider) afrSlider.value = 0;
      safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('cyl3');
    } else if (scenario === 'turbo_wastegate') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0.85;
      safeSetText('val-wg-leak', '85%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0;
      safeSetText('val-bearing-wear', '0%');
      if (throttleSlider) throttleSlider.value = 85;
      safeSetText('val-throttle', '85%');
      if (afrSlider) afrSlider.value = 0;
      safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('turbo');
    } else if (scenario === 'injector_clog') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0;
      safeSetText('val-bearing-wear', '0%');
      if (fuelLeakSlider) fuelLeakSlider.value = 0.70;
      safeSetText('val-fuel-leak', '70%');
      if (throttleSlider) throttleSlider.value = 72;
      safeSetText('val-throttle', '72%');
      if (afrSlider) afrSlider.value = 0.25;
      safeSetText('val-afr-mixture', '18.4 : 1 (LEAN / KNOCK)');
      engine3D.inspectComponent('cyl2');
    } else if (scenario === 'oil_cavitation') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0.80;
      safeSetText('val-oil-wear', '80%');
      if (vibeSlider) vibeSlider.value = 0.65;
      safeSetText('val-bearing-wear', '65%');
      if (throttleSlider) throttleSlider.value = 78;
      safeSetText('val-throttle', '78%');
      if (afrSlider) afrSlider.value = 0;
      safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('oil_system');
    } else if (scenario === 'sensor_drift') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0;
      safeSetText('val-bearing-wear', '0%');
      if (throttleSlider) throttleSlider.value = 75;
      safeSetText('val-throttle', '75%');
      if (afrSlider) afrSlider.value = 0;
      safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('cyl4');
    } else if (scenario === 'combustion_instability') {
      if (cyl3Slider) cyl3Slider.value = 0;
      safeSetText('val-cyl3-heat', '+0°C');
      if (wgSlider) wgSlider.value = 0;
      safeSetText('val-wg-leak', '0%');
      if (oilSlider) oilSlider.value = 0;
      safeSetText('val-oil-wear', '0%');
      if (vibeSlider) vibeSlider.value = 0.45;
      safeSetText('val-bearing-wear', '45%');
      if (throttleSlider) throttleSlider.value = 75;
      safeSetText('val-throttle', '75%');
      if (afrSlider) afrSlider.value = 0.18;
      safeSetText('val-afr-mixture', '17.2 : 1 (LEAN)');
      if (fuelLeakSlider) fuelLeakSlider.value = 0;
      safeSetText('val-fuel-leak', '0%');
      engine3D.inspectComponent('cyl1');
    }
  };

  // Scenario Buttons (Quick Injector & Sandbox View)
  const bindScenarioButtons = () => {
    const pills = document.querySelectorAll('.scenario-pill, .scenario-card');
    pills.forEach(pill => {
      pill.addEventListener('click', () => {
        const scenario = pill.getAttribute('data-scenario');
        if (!scenario) return;
        soundFx.playClick();

        document.querySelectorAll(`.scenario-pill[data-scenario="${scenario}"], .scenario-card[data-scenario="${scenario}"]`)
          .forEach(el => el.classList.add('active'));
        document.querySelectorAll(`.scenario-pill:not([data-scenario="${scenario}"]), .scenario-card:not([data-scenario="${scenario}"])`)
          .forEach(el => el.classList.remove('active'));

        faultSim.loadScenario(scenario);
        syncSandboxSliders(scenario);

        if (scenario === 'nominal') {
          if (isComponentEmergencyActive) {
            faultSim.clearComponentEmergency();
            isComponentEmergencyActive = false;
            activeEmergencyCompKey = null;
            updateEmergencyButtonsUI(engine3D.activeComponentKey);
          }
          telemetry.toggleFuelWall(false);
          updateFuelWallUI(false);
          missionPlanner.reset();
        }
      });
    });
  };
  bindScenarioButtons();

  // Manual Fault Sliders
  const setupSliders = () => {
    const cyl3Slider = document.getElementById('slider-cyl3-heat');
    if (cyl3Slider) {
      cyl3Slider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-cyl3-heat').textContent = `+${val}°C`;
        faultSim.setManualCylinderHeat(2, val);
      });
    }

    const wgSlider = document.getElementById('slider-wg-leak');
    if (wgSlider) {
      wgSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-wg-leak').textContent = `${Math.round(val * 100)}%`;
        faultSim.setManualWastegateLeak(val);
      });
    }

    const oilSlider = document.getElementById('slider-oil-wear');
    if (oilSlider) {
      oilSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-oil-wear').textContent = `${Math.round(val * 100)}%`;
        faultSim.setManualOilPumpWear(val);
      });
    }

    const vibeSlider = document.getElementById('slider-bearing-wear');
    if (vibeSlider) {
      vibeSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-bearing-wear').textContent = `${Math.round(val * 100)}%`;
        faultSim.setManualBearingDamage(val);
      });
    }

    const throttleSlider = document.getElementById('slider-throttle');
    if (throttleSlider) {
      throttleSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value) / 100;
        document.getElementById('val-throttle').textContent = `${Math.round(val * 100)}%`;
        telemetry.setThrottle(val);
      });
    }

    // Fuel Pressure Loss Slider
    const fuelLeakSlider = document.getElementById('slider-fuel-leak');
    if (fuelLeakSlider) {
      fuelLeakSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        document.getElementById('val-fuel-leak').textContent = `${Math.round(val * 100)}%`;
        telemetry.setFuelPressureLoss(val);
      });
    }

    // Air-Fuel Mixture (AFR) Slider
    const afrSlider = document.getElementById('slider-afr-mixture');
    if (afrSlider) {
      afrSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        telemetry.setMixture(val);
        const afrVal = (14.7 * (1 + val)).toFixed(1);
        let note = 'STOICH';
        if (val < -0.1) note = 'RICH';
        else if (val > 0.1) note = 'LEAN / KNOCK';
        const lbl = document.getElementById('val-afr-mixture');
        if (lbl) lbl.textContent = `${afrVal} : 1 (${note})`;
      });
    }

    // Emergency Fuel Wall Cutoff Buttons
    const toggleFuelWallHandler = () => {
      const isCutoff = telemetry.toggleFuelWall();
      if (isCutoff) {
        soundFx.playAlarm();
      } else {
        soundFx.playChirp();
      }
      updateFuelWallUI(isCutoff);
    };

    const toggleFuelWallBtn = document.getElementById('btn-toggle-fuel-wall');
    if (toggleFuelWallBtn) {
      toggleFuelWallBtn.addEventListener('click', toggleFuelWallHandler);
    }

    const sandboxFuelWallBtn = document.getElementById('btn-sandbox-fuel-wall');
    if (sandboxFuelWallBtn) {
      sandboxFuelWallBtn.addEventListener('click', toggleFuelWallHandler);
    }

    const resetSandboxBtn = document.getElementById('btn-reset-sandbox');
    if (resetSandboxBtn) {
      resetSandboxBtn.addEventListener('click', () => {
        soundFx.playChirp();
        if (cyl3Slider) cyl3Slider.value = 0;
        safeSetText('val-cyl3-heat', '+0°C');
        if (wgSlider) wgSlider.value = 0;
        safeSetText('val-wg-leak', '0%');
        if (oilSlider) oilSlider.value = 0;
        safeSetText('val-oil-wear', '0%');
        if (vibeSlider) vibeSlider.value = 0;
        safeSetText('val-bearing-wear', '0%');
        if (throttleSlider) throttleSlider.value = 75;
        safeSetText('val-throttle', '75%');
        if (afrSlider) afrSlider.value = 0;
        safeSetText('val-afr-mixture', '14.7 : 1 (STOICH)');
        if (fuelLeakSlider) fuelLeakSlider.value = 0;
        safeSetText('val-fuel-leak', '0%');
        telemetry.setFuelPressureLoss(0);

        if (isComponentEmergencyActive) {
          faultSim.clearComponentEmergency();
          isComponentEmergencyActive = false;
          activeEmergencyCompKey = null;
          updateEmergencyButtonsUI(engine3D.activeComponentKey);
        }
        telemetry.toggleFuelWall(false);
        updateFuelWallUI(false);
        missionPlanner.reset();

        const nomCard = document.querySelector('.scenario-card[data-scenario="nominal"], .scenario-pill[data-scenario="nominal"]');
        if (nomCard) nomCard.click();

        const origHtml = resetSandboxBtn.innerHTML;
        resetSandboxBtn.innerHTML = '<span>✓ ALL NOMINAL RESET</span>';
        setTimeout(() => { resetSandboxBtn.innerHTML = origHtml; }, 2500);
      });
    }
  };
  setupSliders();

  // Tactical Operation Guide Steps (Cards 01, 02, 03)
  const stepCard1 = document.getElementById('step-card-1');
  const stepCard2 = document.getElementById('step-card-2');
  const stepCard3 = document.getElementById('step-card-3');
  const stepCards = [stepCard1, stepCard2, stepCard3].filter(Boolean);

  function setActiveStepCard(stepNum) {
    stepCards.forEach((card, idx) => {
      if (idx + 1 === stepNum) {
        card.classList.add('active-step');
      } else {
        card.classList.remove('active-step');
      }
    });
  }

  // Execute Failsafe Derate Button (Mission View)
  const failsafeBtn = document.getElementById('btn-execute-failsafe');
  if (failsafeBtn) {
    failsafeBtn.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(3);
      missionPlanner.executeFailsafeDerate();
      failsafeBtn.disabled = true;
      failsafeBtn.innerHTML = `<span>✓ FAILSAFE DERATE EXECUTED (HDG 194°)</span>`;
      setTimeout(() => {
        failsafeBtn.disabled = false;
        failsafeBtn.innerHTML = `<span>⚡ EXECUTE FAILSAFE DERATE &amp; DIVERT</span>`;
      }, 5000);
    });
  }

  // 1-Click Mission Simulation Scenarios
  const btnTestNominal = document.getElementById('btn-test-nominal');
  const btnTestOverheat = document.getElementById('btn-test-overheat');
  const btnTestFlameout = document.getElementById('btn-test-flameout');
  const btnTestReset = document.getElementById('btn-test-reset');
  const scenarioBtns = [btnTestNominal, btnTestOverheat, btnTestFlameout, btnTestReset].filter(Boolean);

  function setScenarioActive(btn) {
    scenarioBtns.forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
  }

  // Step Card 01: Border Patrol loiter
  if (stepCard1) {
    stepCard1.addEventListener('click', () => {
      soundFx.playClick();
      setActiveStepCard(1);
      setScenarioActive(btnTestNominal);
      if (isComponentEmergencyActive) {
        faultSim.clearComponentEmergency();
        isComponentEmergencyActive = false;
        activeEmergencyCompKey = null;
        updateEmergencyButtonsUI(engine3D.activeComponentKey);
      }
      missionPlanner.testNominal();
    });
  }

  // Step Card 02: Health Degradation & Recovery Reach Contraction
  if (stepCard2) {
    stepCard2.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(2);
      setScenarioActive(btnTestOverheat);
      missionPlanner.testOverheat();
    });
  }

  // Step Card 03: Autonomous Failsafe AI Diversion
  if (stepCard3) {
    stepCard3.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(3);
      setScenarioActive(null);
      missionPlanner.executeFailsafeDerate();
      if (failsafeBtn) {
        failsafeBtn.innerHTML = `<span>✓ AUTONOMOUS DIVERSION ENGAGED</span>`;
        setTimeout(() => {
          failsafeBtn.innerHTML = `<span>⚡ EXECUTE FAILSAFE DERATE &amp; DIVERT</span>`;
        }, 4000);
      }
    });
  }

  if (btnTestNominal) {
    btnTestNominal.addEventListener('click', () => {
      soundFx.playClick();
      setActiveStepCard(1);
      setScenarioActive(btnTestNominal);
      if (isComponentEmergencyActive) {
        faultSim.clearComponentEmergency();
        isComponentEmergencyActive = false;
        activeEmergencyCompKey = null;
        updateEmergencyButtonsUI(engine3D.activeComponentKey);
      }
      missionPlanner.testNominal();
      updateFuelWallUI(false);
    });
  }

  if (btnTestOverheat) {
    btnTestOverheat.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(2);
      setScenarioActive(btnTestOverheat);
      missionPlanner.testOverheat();
    });
  }

  if (btnTestFlameout) {
    btnTestFlameout.addEventListener('click', () => {
      soundFx.playAlarm();
      setActiveStepCard(2);
      setScenarioActive(btnTestFlameout);
      missionPlanner.testFlameout();
      updateFuelWallUI(true);
    });
  }

  if (btnTestReset) {
    btnTestReset.addEventListener('click', () => {
      soundFx.playClick();
      setActiveStepCard(1);
      setScenarioActive(btnTestNominal);
      if (isComponentEmergencyActive) {
        faultSim.clearComponentEmergency();
        isComponentEmergencyActive = false;
        activeEmergencyCompKey = null;
        updateEmergencyButtonsUI(engine3D.activeComponentKey);
      }
      missionPlanner.testNominal();
      updateFuelWallUI(false);
    });
  }

  // Airfield Divert Buttons with Live Tactical Feedback
  const btnDivertAlpha = document.getElementById('btn-divert-alpha');
  const btnDivertBravo = document.getElementById('btn-divert-bravo');
  const btnDivertCharlie = document.getElementById('btn-divert-charlie');

  if (btnDivertAlpha) {
    btnDivertAlpha.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(3);
      missionPlanner.divertTo(missionPlanner.getBases()[0]);
      btnDivertAlpha.textContent = '✓ HEADING 238°';
      btnDivertAlpha.classList.add('active-heading');
      setTimeout(() => {
        btnDivertAlpha.textContent = 'RETURN HOME';
        btnDivertAlpha.classList.remove('active-heading');
      }, 3000);
    });
  }
  if (btnDivertBravo) {
    btnDivertBravo.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(3);
      missionPlanner.divertTo(missionPlanner.getBases()[1]);
      btnDivertBravo.textContent = '✓ HEADING 194°';
      btnDivertBravo.classList.add('active-heading');
      setTimeout(() => {
        btnDivertBravo.textContent = 'DIVERT HERE';
        btnDivertBravo.classList.remove('active-heading');
      }, 3000);
    });
  }
  if (btnDivertCharlie) {
    btnDivertCharlie.addEventListener('click', () => {
      soundFx.playCaution();
      setActiveStepCard(3);
      missionPlanner.divertTo(missionPlanner.getBases()[2]);
      btnDivertCharlie.textContent = '✓ HEADING 215°';
      btnDivertCharlie.classList.add('active-heading');
      setTimeout(() => {
        btnDivertCharlie.textContent = 'DIVERT HERE';
        btnDivertCharlie.classList.remove('active-heading');
      }, 3000);
    });
  }

  // Entire Airfield Cards are also clickable for intuitive flight diverting
  const cardAlpha = document.getElementById('base-card-alpha');
  const cardBravo = document.getElementById('base-card-bravo');
  const cardCharlie = document.getElementById('base-card-charlie');

  if (cardAlpha) {
    cardAlpha.addEventListener('click', (e) => {
      if (!e.target.closest('button') && btnDivertAlpha) {
        btnDivertAlpha.click();
      }
    });
  }
  if (cardBravo) {
    cardBravo.addEventListener('click', (e) => {
      if (!e.target.closest('button') && btnDivertBravo) {
        btnDivertBravo.click();
      }
    });
  }
  if (cardCharlie) {
    cardCharlie.addEventListener('click', (e) => {
      if (!e.target.closest('button') && btnDivertCharlie) {
        btnDivertCharlie.click();
      }
    });
  }

  // Center UAV Button with Lock Confirmation
  const btnCenterUav = document.getElementById('btn-center-uav');
  if (btnCenterUav) {
    btnCenterUav.addEventListener('click', () => {
      soundFx.playClick();
      missionPlanner.centerOnUAV();
      const origHtml = btnCenterUav.innerHTML;
      btnCenterUav.innerHTML = '<span>✓ UAV LOCKED</span>';
      setTimeout(() => {
        btnCenterUav.innerHTML = origHtml;
      }, 2500);
    });
  }

  // Audio Mute Toggle Button
  const audioToggleBtn = document.getElementById('audio-toggle-btn');
  if (audioToggleBtn) {
    audioToggleBtn.addEventListener('click', () => {
      const isMuted = soundFx.toggleMute();
      audioToggleBtn.innerHTML = isMuted 
        ? `<svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15zM17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2"/></svg>`
        : `<svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>`;
    });
  }

  // Airworthiness Report Modal & Export
  const reportModal = document.getElementById('report-modal');
  const openReportBtn = document.getElementById('btn-open-report');
  const closeReportBtn = document.getElementById('btn-close-report');
  const printReportBtn = document.getElementById('btn-print-report');
  const exportCsvBtn = document.getElementById('btn-export-csv');

  if (openReportBtn && reportModal) {
    openReportBtn.addEventListener('click', () => {
      soundFx.playClick();
      const reportContainer = document.getElementById('report-modal-content');
      if (reportContainer) {
        reportContainer.innerHTML = reportGen.generateHtmlReport();
      }
      reportModal.classList.add('active');
    });
  }

  if (closeReportBtn && reportModal) {
    closeReportBtn.addEventListener('click', () => {
      soundFx.playClick();
      reportModal.classList.remove('active');
    });
  }

  if (printReportBtn) {
    printReportBtn.addEventListener('click', () => {
      window.print();
    });
  }

  if (exportCsvBtn) {
    exportCsvBtn.addEventListener('click', () => {
      soundFx.playChirp();
      reportGen.exportCsv();
    });
  }

  // SIH 26054 Problem Statement Dossier Modal
  const dossierModal = document.getElementById('dossier-modal');
  const openDossierBtn = document.getElementById('btn-open-dossier');
  const closeDossierBtn = document.getElementById('btn-close-dossier');

  if (openDossierBtn && dossierModal) {
    openDossierBtn.addEventListener('click', () => {
      soundFx.playClick();
      dossierModal.classList.add('active');
    });
  }

  if (closeDossierBtn && dossierModal) {
    closeDossierBtn.addEventListener('click', () => {
      soundFx.playClick();
      dossierModal.classList.remove('active');
    });
  }

  // Real Engine Hardware Link Modal & Handlers
  const hardwareModal = document.getElementById('hardware-modal');
  const openHwBtn = document.getElementById('btn-open-hardware');
  const closeHwBtn = document.getElementById('btn-close-hardware');
  const connectSerialBtn = document.getElementById('btn-hw-connect-serial');
  const disconnectSerialBtn = document.getElementById('btn-hw-disconnect-serial');
  const simulateSerialBtn = document.getElementById('btn-hw-simulate-serial');
  const connectApiBtn = document.getElementById('btn-hw-connect-api');
  const disconnectApiBtn = document.getElementById('btn-hw-disconnect-api');
  const startFeederBtn = document.getElementById('btn-hw-start-feeder');
  const sendPacketBtn = document.getElementById('btn-hw-send-packet');
  const copyPythonBtn = document.getElementById('btn-copy-python');
  const copyCurlBtn = document.getElementById('btn-copy-curl');
  const baudSelect = document.getElementById('hw-baud-select');
  const activeSourceLbl = document.getElementById('hw-active-source-lbl');
  const packetsCountLbl = document.getElementById('hw-packets-count');
  const headerHwLabel = document.getElementById('header-hardware-label');
  const serialMsg = document.getElementById('hw-serial-msg');
  const apiMsg = document.getElementById('hw-api-msg');

  if (openHwBtn && hardwareModal) {
    openHwBtn.addEventListener('click', () => {
      soundFx.playClick();
      hardwareModal.classList.add('active');
    });
  }

  if (closeHwBtn && hardwareModal) {
    closeHwBtn.addEventListener('click', () => {
      soundFx.playClick();
      hardwareModal.classList.remove('active');
    });
  }

  // Universal Modal Backdrop Click & Escape Key to Close for ALL modals
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        soundFx.playClick();
        modal.classList.remove('active');
      }
    });
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.active').forEach(modal => {
        soundFx.playClick();
        modal.classList.remove('active');
      });
    }
  });

  // OPTION 1: Real Web Serial Port Connection
  if (connectSerialBtn) {
    connectSerialBtn.addEventListener('click', async () => {
      soundFx.playClick();
      const baud = baudSelect ? baudSelect.value : 115200;
      if (serialMsg) serialMsg.textContent = 'Requesting USB COM port access...';
      try {
        await hardwareLink.connectSerial(baud);
        soundFx.playChirp();
        if (serialMsg) {
          serialMsg.textContent = `✓ Connected to USB Serial @ ${baud} bps. Streaming live sensors.`;
          serialMsg.style.color = 'var(--emerald-safe)';
        }
      } catch (err) {
        if (serialMsg) {
          serialMsg.textContent = `Notice: ${err.message || 'Port selection was cancelled'}. Use "Simulate USB Arduino" for demo.`;
          serialMsg.style.color = 'var(--amber-warn)';
        }
      }
    });
  }

  if (disconnectSerialBtn) {
    disconnectSerialBtn.addEventListener('click', async () => {
      soundFx.playCaution();
      await hardwareLink.disconnect();
      if (serialMsg) {
        serialMsg.textContent = 'Disconnected from serial port. Returned to simulated mode.';
        serialMsg.style.color = 'var(--text-muted)';
      }
    });
  }

  // OPTION 1 Emulator: Virtual Arduino CH340 Stream
  if (simulateSerialBtn) {
    simulateSerialBtn.addEventListener('click', () => {
      soundFx.playChirp();
      if (hardwareLink.connectionType === 'SERIAL_EMU') {
        hardwareLink.disconnect();
        simulateSerialBtn.textContent = '🎮 SIMULATE USB ARDUINO SENSORS (NO HW NEEDED)';
        simulateSerialBtn.classList.remove('active');
        if (serialMsg) serialMsg.textContent = 'Emulated Arduino stopped.';
      } else {
        hardwareLink.simulateSerialStream();
        simulateSerialBtn.textContent = '⏹️ STOP ARDUINO EMULATION';
        simulateSerialBtn.classList.add('active');
        if (serialMsg) {
          serialMsg.textContent = '✓ Live emulated Arduino CH340 stream active @ 115200 bps.';
          serialMsg.style.color = 'var(--emerald-safe)';
        }
      }
    });
  }

  // OPTION 2: Network Ingestion Bridge Polling
  if (connectApiBtn) {
    connectApiBtn.addEventListener('click', () => {
      soundFx.playClick();
      hardwareLink.startApiBridgePolling();
      soundFx.playChirp();
      if (apiMsg) {
        apiMsg.textContent = '✓ Polling active on http://localhost:3000/api/telemetry. Ready for POST packets.';
        apiMsg.style.color = 'var(--cyan-hud)';
      }
      if (disconnectApiBtn) disconnectApiBtn.style.display = 'flex';
      connectApiBtn.style.display = 'none';
    });
  }

  if (disconnectApiBtn) {
    disconnectApiBtn.addEventListener('click', () => {
      soundFx.playCaution();
      hardwareLink.disconnect();
      if (apiMsg) {
        apiMsg.textContent = 'Network polling stopped. Returned to internal simulation.';
        apiMsg.style.color = 'var(--text-muted)';
      }
      if (connectApiBtn) connectApiBtn.style.display = 'flex';
      disconnectApiBtn.style.display = 'none';
      if (startFeederBtn) {
        startFeederBtn.textContent = '🚀 START VIRTUAL TEST BENCH FEEDER';
        startFeederBtn.className = 'tactical-btn primary';
      }
    });
  }

  // OPTION 2: Virtual Test Bench Feeder
  if (startFeederBtn) {
    startFeederBtn.addEventListener('click', () => {
      soundFx.playChirp();
      if (hardwareLink.isFeederActive) {
        hardwareLink.stopVirtualFeeder();
        hardwareLink.disconnect();
        startFeederBtn.textContent = '🚀 START VIRTUAL TEST BENCH FEEDER';
        startFeederBtn.className = 'tactical-btn primary';
        if (apiMsg) apiMsg.textContent = 'Test bench feeder stopped.';
        if (connectApiBtn) connectApiBtn.style.display = 'flex';
        if (disconnectApiBtn) disconnectApiBtn.style.display = 'none';
      } else {
        hardwareLink.startVirtualFeeder();
        startFeederBtn.textContent = '⏹️ STOP TEST BENCH FEEDER';
        startFeederBtn.className = 'tactical-btn danger';
        if (apiMsg) {
          apiMsg.textContent = '✓ Physical Dyno Test Bench streaming at 10 Hz into /api/telemetry.';
          apiMsg.style.color = 'var(--emerald-safe)';
        }
        if (connectApiBtn) connectApiBtn.style.display = 'none';
        if (disconnectApiBtn) disconnectApiBtn.style.display = 'flex';
      }
    });
  }

  // OPTION 2: Send Single Packet
  if (sendPacketBtn) {
    sendPacketBtn.addEventListener('click', async () => {
      soundFx.playClick();
      sendPacketBtn.disabled = true;
      sendPacketBtn.textContent = 'SENDING...';
      const ok = await hardwareLink.sendSingleTestPacket();
      soundFx.playChirp();
      if (ok) {
        if (apiMsg) {
          apiMsg.textContent = '✓ Test packet accepted by /api/telemetry (HTTP 200 OK).';
          apiMsg.style.color = 'var(--emerald-safe)';
        }
      } else {
        if (apiMsg) {
          apiMsg.textContent = 'Failed to reach /api/telemetry. Check server status.';
          apiMsg.style.color = 'var(--crimson-crit)';
        }
      }
      setTimeout(() => {
        sendPacketBtn.disabled = false;
        sendPacketBtn.textContent = '📤 SEND 1 PACKET';
      }, 1200);
    });
  }

  // Copy Code Snippets
  if (copyPythonBtn) {
    copyPythonBtn.addEventListener('click', () => {
      soundFx.playClick();
      navigator.clipboard.writeText('python hardware_bridge.py --test-bench');
      copyPythonBtn.textContent = '✓ COPIED';
      setTimeout(() => { copyPythonBtn.textContent = 'COPY'; }, 2000);
    });
  }

  if (copyCurlBtn) {
    copyCurlBtn.addEventListener('click', () => {
      soundFx.playClick();
      navigator.clipboard.writeText('curl.exe -X POST http://localhost:3000/api/telemetry -H "Content-Type: application/json" -d "{\\"rpm\\":4400,\\"map\\":36.2,\\"cht\\":[175,172,178,174],\\"oilPress\\":54,\\"vibrationRms\\":2.1}"');
      copyCurlBtn.textContent = '✓ COPIED CURL COMMAND';
      setTimeout(() => { copyCurlBtn.textContent = '📋 COPY CURL TEST COMMAND'; }, 2000);
    });
  }

  hardwareLink.onStatusChange((status) => {
    if (activeSourceLbl) activeSourceLbl.textContent = status.label;
    if (headerHwLabel) {
      headerHwLabel.textContent = status.connected 
        ? `LIVE ENGINE (${status.type})` 
        : 'CONNECT ENGINE';
    }
    if (connectSerialBtn && disconnectSerialBtn) {
      const isRealSerial = status.connected && status.type === 'SERIAL' && hardwareLink.connectionType === 'SERIAL';
      connectSerialBtn.style.display = isRealSerial ? 'none' : 'flex';
      disconnectSerialBtn.style.display = isRealSerial ? 'flex' : 'none';
    }
  });

  // =========================================================================
  // PRE-FLIGHT T-2h AI ENGINE HEALTH AUDIT & TAKEOFF VERDICT MODAL CONTROLLER
  // =========================================================================
  const preflightModal = document.getElementById('preflight-modal');
  const openPreflightBtn = document.getElementById('btn-open-preflight');
  const cockpitPreflightBtn = document.getElementById('btn-cockpit-preflight-audit');
  const closePreflightBtn = document.getElementById('btn-close-preflight');
  const applyGroundFixBtn = document.getElementById('btn-apply-ground-fix');
  const preflightPills = document.querySelectorAll('.preflight-pill-btn[data-preflight-scen]');

  function renderPreflightModal(auditData) {
    const audit = auditData || aiEngine.getPreflightAudit(telemetry.state, telemetry);
    if (!preflightModal) return;

    // 1. Verdict Card Styling & Contents
    const verdictCard = document.getElementById('preflight-verdict-card');
    const verdictIcon = document.getElementById('preflight-verdict-icon');
    const verdictTag = document.getElementById('preflight-verdict-tag');
    const verdictHeadline = document.getElementById('preflight-verdict-headline');
    const verdictSummary = document.getElementById('preflight-verdict-summary');
    const readinessScoreEl = document.getElementById('preflight-readiness-score');
    const failProbEl = document.getElementById('preflight-fail-prob');
    const riskLevelEl = document.getElementById('preflight-risk-level');

    const isGo = audit.decision === 'GO';

    if (verdictCard) {
      verdictCard.className = `preflight-verdict-card ${isGo ? 'go' : 'no-go'}`;
    }
    if (verdictIcon) {
      verdictIcon.textContent = isGo ? '✓' : '⚠️';
    }
    if (verdictTag) {
      verdictTag.textContent = isGo ? 'TAKEOFF CLEARED • GO VERDICT' : 'TAKEOFF PROHIBITED • NO-GO VERDICT';
    }
    if (verdictHeadline) {
      verdictHeadline.textContent = audit.headline;
    }
    if (verdictSummary) {
      verdictSummary.textContent = audit.summary;
    }
    if (readinessScoreEl) {
      readinessScoreEl.textContent = `${audit.readinessScore.toFixed(1)}%`;
      readinessScoreEl.style.color = isGo ? 'var(--emerald-safe)' : 'var(--crimson-crit)';
    }
    if (failProbEl) {
      failProbEl.textContent = audit.futureForecast.failureProbability;
      failProbEl.style.color = isGo ? 'var(--emerald-safe)' : 'var(--crimson-crit)';
    }
    if (riskLevelEl) {
      riskLevelEl.textContent = audit.riskLevel;
      riskLevelEl.style.color = isGo ? 'var(--emerald-safe)' : 'var(--crimson-crit)';
    }

    // 2. Phase 1: Past Health & Historical Logs
    const past = audit.pastHistory;
    safeSetText('pf-past-hours', `${past.accumulatedHours} / ${past.totalTboHours} HRS TBO`);
    safeSetText('pf-past-cycles', `${past.thermalDutyCycles} / ${past.maxAllowedCycles} Sorties`);
    safeSetText('pf-past-degradation', past.historicalDegradationRate);
    safeSetText('pf-past-spectrometry', past.oilSpectrometry);
    safeSetText('pf-past-status', past.maintenanceHistoryStatus);

    // 3. Phase 2: Present Ground Telemetry
    const present = audit.presentGroundTelemetry;
    safeSetText('pf-present-rpm', `${present.groundIdleRpm} RPM`);
    safeSetText('pf-present-oil', present.oilPressure);
    safeSetText('pf-present-map', present.mapBoost);
    safeSetText('pf-present-vibe', present.vibrationRms);

    const cylContainer = document.getElementById('pf-cyl-bars-container');
    if (cylContainer && present.cylBalance) {
      cylContainer.innerHTML = present.cylBalance.map(c => `
        <div class="pf-cyl-bar-item ${c.status !== 'NOMINAL' ? 'anom' : ''}">
          <span class="pf-cyl-id">${c.cyl}</span>
          <span class="pf-cyl-val">${c.cht}°C</span>
          <span style="font-size: 8.5px; font-family: var(--font-mono); color: ${c.status === 'NOMINAL' ? 'var(--emerald-safe)' : 'var(--crimson-crit)'}">${c.score.toFixed(0)}%</span>
        </div>
      `).join('');
    }

    // 4. Phase 3: Future In-Flight Forecast
    const future = audit.futureForecast;
    safeSetText('pf-future-ttf', future.predictedTimeFailure);
    const ttfEl = document.getElementById('pf-future-ttf');
    if (ttfEl) ttfEl.style.color = isGo ? 'var(--emerald-safe)' : 'var(--crimson-crit)';

    safeSetText('pf-future-mode', future.failureMode);
    safeSetText('pf-future-risk', future.failureProbability);
    safeSetText('pf-future-ceiling', future.projectedAltitudeCeiling);
    safeSetText('pf-future-rtb', isGo ? 'GUARANTEED (100% MARGIN)' : 'INSUFFICIENT (ASSET LOSS RISK)');
    const rtbEl = document.getElementById('pf-future-rtb');
    if (rtbEl) rtbEl.className = isGo ? 'pm-val text-green' : 'pm-val text-crit';

    // 5. Prescriptive Solution Card
    const sol = audit.solution;
    const solCard = document.getElementById('preflight-solution-card');
    if (solCard) {
      solCard.style.borderColor = isGo ? 'rgba(16, 185, 129, 0.4)' : 'rgba(245, 158, 11, 0.5)';
      solCard.style.boxShadow = isGo ? '0 0 15px rgba(16, 185, 129, 0.15)' : '0 0 25px rgba(245, 158, 11, 0.2)';
    }
    safeSetText('pf-solution-icon', isGo ? '✓' : '🛠️');
    safeSetText('pf-solution-title', sol.issueTitle);
    safeSetText('pf-solution-time', `EST. FIX TIME: ${sol.estimatedFixTime}`);
    safeSetText('pf-solution-directive', sol.cemilacDirective);
    safeSetText('pf-solution-root', sol.rootCause);
    safeSetText('pf-solution-parts', sol.requiredParts);

    const stepsList = document.getElementById('pf-solution-steps');
    if (stepsList && sol.correctiveSteps) {
      stepsList.innerHTML = sol.correctiveSteps.map(step => `<li>${step}</li>`).join('');
    }

    // Interactive Ground Fix Action Button
    if (applyGroundFixBtn) {
      if (isGo) {
        applyGroundFixBtn.textContent = '✓ ALL SYSTEMS NOMINAL & VERIFIED (ENGINE AIRWORTHY)';
        applyGroundFixBtn.style.background = 'rgba(16, 185, 129, 0.15)';
        applyGroundFixBtn.style.borderColor = 'var(--emerald-safe)';
        applyGroundFixBtn.style.color = 'var(--emerald-safe)';
        applyGroundFixBtn.disabled = true;
      } else {
        applyGroundFixBtn.textContent = '🔧 EXECUTE GROUND MAINTENANCE FIX & RE-AUDIT ENGINE';
        applyGroundFixBtn.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.25), rgba(0, 240, 255, 0.25))';
        applyGroundFixBtn.style.borderColor = 'var(--emerald-safe)';
        applyGroundFixBtn.style.color = '#fff';
        applyGroundFixBtn.disabled = false;
      }
    }
  }

  // Open / Close events
  const openPreflightModal = () => {
    try { soundFx.playClick(); } catch (e) {}
    if (preflightModal) {
      preflightModal.classList.add('active');
    }
    try {
      renderPreflightModal();
    } catch (err) {
      console.error('[AERO-TWIN] Preflight render error:', err);
    }
  };

  const closePreflightModal = () => {
    try { soundFx.playClick(); } catch (e) {}
    if (preflightModal) {
      preflightModal.classList.remove('active');
    }
  };

  if (openPreflightBtn) {
    openPreflightBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openPreflightModal();
    });
  }
  if (cockpitPreflightBtn) {
    cockpitPreflightBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openPreflightModal();
    });
  }
  const scenarioPreflightPill = document.getElementById('pill-open-preflight-audit');
  if (scenarioPreflightPill) {
    scenarioPreflightPill.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openPreflightModal();
    });
  }
  if (closePreflightBtn) {
    closePreflightBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      closePreflightModal();
    });
  }
  if (preflightModal) {
    preflightModal.addEventListener('click', (e) => {
      if (e.target === preflightModal) {
        closePreflightModal();
      }
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && preflightModal && preflightModal.classList.contains('active')) {
      closePreflightModal();
    }
  });

  // Scenario Buttons inside Preflight Modal
  preflightPills.forEach(pill => {
    pill.addEventListener('click', () => {
      soundFx.playClick();
      preflightPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const scen = pill.getAttribute('data-preflight-scen');

      if (scen === 'nominal') {
        faultSim.loadScenario('nominal');
        aiEngine.applyGroundFix(telemetry);
      } else if (scen === 'cyl3_thermal') {
        faultSim.loadScenario('cyl3_thermal');
      } else if (scen === 'turbo_wastegate') {
        faultSim.loadScenario('turbo_wastegate');
      } else if (scen === 'injector_clog') {
        faultSim.loadScenario('injector_clog');
      } else if (scen === 'oil_cavitation') {
        faultSim.loadScenario('oil_cavitation');
      }

      syncSandboxSliders(scen);
      renderPreflightModal();
    });
  });

  // Apply Ground Maintenance Fix Button
  if (applyGroundFixBtn) {
    applyGroundFixBtn.addEventListener('click', () => {
      soundFx.playChirp();
      applyGroundFixBtn.textContent = '⚙️ EXECUTING CEMILAC REPAIR & RUN-UP TEST...';
      applyGroundFixBtn.disabled = true;

      setTimeout(() => {
        faultSim.loadScenario('nominal');
        aiEngine.applyGroundFix(telemetry);
        soundFx.playChirp();

        // Update pills
        preflightPills.forEach(p => p.classList.remove('active'));
        const nominalPill = document.querySelector('.preflight-pill-btn[data-preflight-scen="nominal"]');
        if (nominalPill) nominalPill.classList.add('active');

        renderPreflightModal();
      }, 1200);
    });
  }

  // =========================================================================
  // DEEP PINN NEURAL NETWORK & PROGNOSTICS MODAL CONTROLLER
  // =========================================================================
  const aiDeepModal = document.getElementById('ai-deep-modal');
  const btnCloseAiDeep = document.getElementById('btn-close-ai-deep');
  const btnHeaderDeepAi = document.getElementById('btn-header-deep-ai');
  const btnCockpitDeepAi = document.getElementById('btn-cockpit-deep-ai');
  const aiRadialBox = document.getElementById('ai-radial-box');
  const aiRulBox = document.getElementById('ai-rul-box');
  const aiFaultBadge = document.getElementById('ai-fault-badge');
  const btnPinnLaunchPreflight = document.getElementById('btn-pinn-launch-preflight');
  const btnPinnFocusSubsystem = document.getElementById('btn-pinn-focus-subsystem');

  function renderAIDeepModal() {
    if (!aiDeepModal || !aiDeepModal.classList.contains('active')) return;

    const s = telemetry.state;
    const fft = telemetry.fftBins;
    const ai = aiEngine.evaluate(s, fft);

    // 1. Loss calculations
    const maxCht = Math.max(...s.cht);
    const expectedCht = 150 + (s.rpm / 5000) * 20;
    const chtResidual = Math.max(0, maxCht - expectedCht);
    const lossThermo = Math.min(1.0, chtResidual * 0.018);

    let knockEnergy = 0;
    for (let b = 50; b <= 53; b++) knockEnergy = Math.max(knockEnergy, fft[b] || 0);
    const lossKnock = Math.min(1.0, Math.max(0, knockEnergy - 0.25) * 0.35);

    const expectedOil = 52 - ((s.oilTemp - 80) * 0.1);
    const oilResidual = Math.max(0, expectedOil - s.oilPress);
    let bearingEnergy = 0;
    for (let b = 27; b <= 30; b++) bearingEnergy = Math.max(bearingEnergy, fft[b] || 0);
    const lossHydro = Math.min(1.0, (oilResidual * 0.025) + (bearingEnergy > 0.3 ? (bearingEnergy - 0.3) * 0.3 : 0));

    const mapLoss = s.rpm > 3500 && s.map < 28 ? (28 - s.map) * 0.04 : 0.005;
    const lossBoost = Math.min(1.0, mapLoss);

    const totalLoss = Math.min(1.0, (lossThermo + lossKnock + lossHydro + lossBoost) / 4);

    // Update Top Metric Strip
    const lossValEl = document.getElementById('pinn-total-loss-val');
    if (lossValEl) {
      lossValEl.textContent = totalLoss.toFixed(4);
      lossValEl.style.color = totalLoss < 0.015 ? 'var(--emerald-safe)' : totalLoss < 0.05 ? 'var(--amber-warn)' : 'var(--crimson-crit)';
    }
    safeSetText('pinn-hi-val', `${ai.healthIndex.toFixed(1)}%`);
    safeSetText('pinn-rul-val', `${ai.rulHours} HRS`);

    // Update Loss Gauges
    safeSetWidth('pinn-bar-thermo', Math.max(5, lossThermo * 100));
    safeSetText('pinn-loss-thermo-badge', lossThermo > 0.03 ? `${lossThermo.toFixed(4)} (ELEVATED)` : `${lossThermo.toFixed(4)} (NOMINAL)`);
    const thermoBadge = document.getElementById('pinn-loss-thermo-badge');
    if (thermoBadge) thermoBadge.className = 'badge ' + (lossThermo > 0.03 ? 'badge-critical' : 'badge-nominal');

    safeSetWidth('pinn-bar-knock', Math.max(5, lossKnock * 100));
    safeSetText('pinn-loss-knock-badge', lossKnock > 0.03 ? `${lossKnock.toFixed(4)} (KNOCK SPIKE)` : `${lossKnock.toFixed(4)} (NOMINAL)`);
    const knockBadge = document.getElementById('pinn-loss-knock-badge');
    if (knockBadge) knockBadge.className = 'badge ' + (lossKnock > 0.03 ? 'badge-critical' : 'badge-nominal');

    safeSetWidth('pinn-bar-hydro', Math.max(5, lossHydro * 100));
    safeSetText('pinn-loss-hydro-badge', lossHydro > 0.03 ? `${lossHydro.toFixed(4)} (CAVITATION)` : `${lossHydro.toFixed(4)} (NOMINAL)`);
    const hydroBadge = document.getElementById('pinn-loss-hydro-badge');
    if (hydroBadge) hydroBadge.className = 'badge ' + (lossHydro > 0.03 ? 'badge-critical' : 'badge-nominal');

    safeSetWidth('pinn-bar-boost', Math.max(5, lossBoost * 100));
    safeSetText('pinn-loss-boost-badge', lossBoost > 0.03 ? `${lossBoost.toFixed(4)} (DEFICIT)` : `${lossBoost.toFixed(4)} (NOMINAL)`);
    const boostBadge = document.getElementById('pinn-loss-boost-badge');
    if (boostBadge) boostBadge.className = 'badge ' + (lossBoost > 0.03 ? 'badge-critical' : 'badge-nominal');

    // Classifier Bars
    const classifierContainer = document.getElementById('pinn-classifier-bars');
    if (classifierContainer) {
      const isCyl3 = s.cht[2] > 200;
      const isTurbo = s.map < 26;
      const isOil = s.oilPress < 35;
      const isInj = Math.abs(s.cht[1] - s.cht[0]) > 20;
      const isNom = !isCyl3 && !isTurbo && !isOil && !isInj;

      const classes = [
        { name: 'Nominal High-Altitude Loiter', prob: isNom ? 98.4 : 2.1, color: 'var(--emerald-safe)' },
        { name: 'Cylinder #3 Thermal Runaway / Knock', prob: isCyl3 ? 92.4 : 1.2, color: 'var(--crimson-crit)' },
        { name: 'Turbocharger Wastegate Jam / Boost Loss', prob: isTurbo ? 88.6 : 0.8, color: 'var(--amber-warn)' },
        { name: 'Fuel Injector #2 Micro-Clog', prob: isInj ? 82.1 : 0.6, color: '#facc15' },
        { name: 'Oil Pump Cavitation / Bearing Scoring', prob: isOil ? 96.2 : 0.4, color: 'var(--crimson-crit)' }
      ];

      classifierContainer.innerHTML = classes.map(c => `
        <div style="display:flex; flex-direction:column; gap:2px; font-family:var(--font-mono); font-size:10px;">
          <div style="display:flex; justify-content:space-between;">
            <span style="color:${c.prob > 50 ? '#fff' : 'var(--text-muted)'}; font-weight:${c.prob > 50 ? '700' : '400'}">${c.name}</span>
            <strong style="color:${c.color}">${c.prob.toFixed(1)}%</strong>
          </div>
          <div style="height:5px; background:rgba(255,255,255,0.06); border-radius:3px; overflow:hidden;">
            <div style="width:${c.prob}%; height:100%; background:${c.color}; border-radius:3px; transition:width 0.3s ease;"></div>
          </div>
        </div>
      `).join('');
    }

    // AI Insight text
    const insightEl = document.getElementById('pinn-ai-insight-text');
    if (insightEl) {
      if (ai.status === 'CRITICAL') {
        insightEl.innerHTML = `<strong style="color:var(--crimson-crit);">CRITICAL PINN RESIDUAL BREACH:</strong> Multi-sensor divergence observed. PINN physics loss is elevated (${totalLoss.toFixed(4)}). Primary SHAP driver: <strong>${ai.detectedFault}</strong>. Immediate pilot/GCS remediation recommended.`;
      } else if (ai.status === 'DEGRADED') {
        insightEl.innerHTML = `<strong style="color:var(--amber-warn);">INCIPIENT DEGRADATION DETECTED:</strong> Sub-threshold thermodynamic deviation identified before static warning boundary. Primary attribution: <strong>${ai.detectedFault}</strong>.`;
      } else {
        insightEl.innerHTML = `<strong style="color:var(--emerald-safe);">OPTIMAL THERMO-ACOUSTIC EQUILIBRIUM:</strong> Physics-Informed Neural Network confirms complete energy conservation and mechanical alignment across all 4 cylinders and turbocharger.`;
      }
    }
  }

  const openAIDeepModal = () => {
    try { soundFx.playClick(); } catch (e) {}
    if (aiDeepModal) aiDeepModal.classList.add('active');
    renderAIDeepModal();
  };

  const closeAIDeepModal = () => {
    try { soundFx.playClick(); } catch (e) {}
    if (aiDeepModal) aiDeepModal.classList.remove('active');
  };

  [btnHeaderDeepAi, btnCockpitDeepAi, aiRadialBox, aiRulBox, aiFaultBadge].forEach(btn => {
    if (btn) btn.addEventListener('click', openAIDeepModal);
  });
  if (btnCloseAiDeep) btnCloseAiDeep.addEventListener('click', closeAIDeepModal);
  if (aiDeepModal) {
    aiDeepModal.addEventListener('click', (e) => {
      if (e.target === aiDeepModal) closeAIDeepModal();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && aiDeepModal && aiDeepModal.classList.contains('active')) {
      closeAIDeepModal();
    }
  });

  if (btnPinnLaunchPreflight) {
    btnPinnLaunchPreflight.addEventListener('click', () => {
      closeAIDeepModal();
      openPreflightModal();
    });
  }

  if (btnPinnFocusSubsystem) {
    btnPinnFocusSubsystem.addEventListener('click', () => {
      closeAIDeepModal();
      const compKey = engine3D.activeComponentKey || 'cyl3';
      engine3D.focusOn(compKey);
      const inspector = document.getElementById('component-defect-inspector');
      if (inspector) {
        inspector.scrollIntoView({ behavior: 'smooth', block: 'center' });
        inspector.classList.add('highlight-pulse');
        setTimeout(() => inspector.classList.remove('highlight-pulse'), 1600);
      }
    });
  }

  // =========================================================================
  // INTERACTIVE XAI (EXPLAINABLE AI - SHAP) ATTRIBUTION ROW CLICK HANDLERS
  // =========================================================================
  const xaiCyl3Row = document.getElementById('xai-row-cht3');
  const xaiVibeRow = document.getElementById('xai-row-vibe');
  const xaiOilRow = document.getElementById('xai-row-oil');
  const xaiMapRow = document.getElementById('xai-row-map');

  if (xaiCyl3Row) {
    xaiCyl3Row.addEventListener('click', () => {
      soundFx.playChirp();
      engine3D.inspectComponent('cyl3');
      if (subsystem3D) subsystem3D.loadSubsystem('cyl3');
      updateEducationalGuideDOM('cyl3');
      updateEmergencyButtonsUI('cyl3');
      const inspector = document.getElementById('component-defect-inspector');
      if (inspector) {
        inspector.scrollIntoView({ behavior: 'smooth', block: 'center' });
        inspector.classList.add('highlight-pulse');
        setTimeout(() => inspector.classList.remove('highlight-pulse'), 1600);
      }
    });
  }

  if (xaiVibeRow) {
    xaiVibeRow.addEventListener('click', () => {
      soundFx.playChirp();
      const vibeCard = document.querySelector('.vibration-card');
      if (vibeCard) {
        vibeCard.classList.add('highlight-pulse-box');
        setTimeout(() => vibeCard.classList.remove('highlight-pulse-box'), 1600);
      }
      openVibrationModal();
    });
  }

  if (xaiOilRow) {
    xaiOilRow.addEventListener('click', () => {
      soundFx.playChirp();
      engine3D.inspectComponent('oil_system');
      if (subsystem3D) subsystem3D.loadSubsystem('oil_system');
      updateEducationalGuideDOM('oil_system');
      updateEmergencyButtonsUI('oil_system');
      const oilTile = document.getElementById('tile-card-oil');
      if (oilTile) {
        oilTile.classList.add('highlight-pulse-box');
        setTimeout(() => oilTile.classList.remove('highlight-pulse-box'), 1600);
      }
    });
  }

  if (xaiMapRow) {
    xaiMapRow.addEventListener('click', () => {
      soundFx.playChirp();
      engine3D.inspectComponent('turbo');
      if (subsystem3D) subsystem3D.loadSubsystem('turbo');
      updateEducationalGuideDOM('turbo');
      updateEmergencyButtonsUI('turbo');
      const mapTile = document.getElementById('tile-card-map');
      if (mapTile) {
        mapTile.classList.add('highlight-pulse-box');
        setTimeout(() => mapTile.classList.remove('highlight-pulse-box'), 1600);
      }
    });
  }

  // =========================================================================
  // FFT VIBRATION FREQUENCY ZONE SELECTOR & SPECTRUM MODAL CONTROLLER
  // =========================================================================
  const vibeModal = document.getElementById('vibe-modal');
  const btnOpenVibeModal = document.getElementById('btn-open-vibe-modal');
  const titleVibeHeader = document.getElementById('title-vibe-header');
  const btnCloseVibeModal = document.getElementById('btn-close-vibe-modal');
  const btnCloseVibeBottom = document.getElementById('btn-close-vibe-bottom');

  function openVibrationModal() {
    if (!vibeModal) return;
    soundFx.playClick();
    vibeModal.classList.add('active');
    renderVibeModal();
  }

  function closeVibrationModal() {
    if (!vibeModal) return;
    soundFx.playClick();
    vibeModal.classList.remove('active');
  }

  if (btnOpenVibeModal) btnOpenVibeModal.addEventListener('click', openVibrationModal);
  if (titleVibeHeader) titleVibeHeader.addEventListener('click', openVibrationModal);
  if (btnCloseVibeModal) btnCloseVibeModal.addEventListener('click', closeVibrationModal);
  if (btnCloseVibeBottom) btnCloseVibeBottom.addEventListener('click', closeVibrationModal);

  if (vibeModal) {
    vibeModal.addEventListener('click', (e) => {
      if (e.target === vibeModal) closeVibrationModal();
    });
  }

  // Modal Channels & Bands State
  let activeVibeChannel = 'composite';
  let activeVibeBand = 'all';

  const vibeChannelBtns = document.querySelectorAll('.vibe-channel-btn');
  vibeChannelBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      vibeChannelBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeVibeChannel = btn.getAttribute('data-channel') || 'composite';
      renderModalFftCanvas();
    });
  });

  const vibeBandBtns = document.querySelectorAll('.vibe-band-btn');
  vibeBandBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      vibeBandBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeVibeBand = btn.getAttribute('data-band') || 'all';
      renderModalFftCanvas();
    });
  });

  // Modal Quick Injector Test Buttons
  const btnTestVibeBearing = document.getElementById('btn-test-vibe-bearing');
  if (btnTestVibeBearing) {
    btnTestVibeBearing.addEventListener('click', () => {
      soundFx.playCaution();
      faultSim.setManualBearingDamage(0.65);
      renderVibeModal();
    });
  }

  const btnTestVibeKnock = document.getElementById('btn-test-vibe-knock');
  if (btnTestVibeKnock) {
    btnTestVibeKnock.addEventListener('click', () => {
      soundFx.playAlarm();
      faultSim.setManualCylinderHeat(2, 60);
      renderVibeModal();
    });
  }

  const btnTestVibeMisfire = document.getElementById('btn-test-vibe-misfire');
  if (btnTestVibeMisfire) {
    btnTestVibeMisfire.addEventListener('click', () => {
      soundFx.playAlarm();
      telemetry.setFault('combustionInstability', 0.85);
      renderVibeModal();
    });
  }

  const btnTestVibeNominal = document.getElementById('btn-test-vibe-nominal');
  if (btnTestVibeNominal) {
    btnTestVibeNominal.addEventListener('click', () => {
      soundFx.playChirp();
      faultSim.resetToNominalBaseline();
      renderVibeModal();
    });
  }

  // Dashboard Zone Selector Buttons
  const fftZoneBtns = document.querySelectorAll('.fft-zone-pill');
  fftZoneBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      const zone = btn.getAttribute('data-zone') || 'all';
      activeFftZone = zone;
      fftZoneBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const descEl = document.getElementById('vibe-status-desc');
      const badgeEl = document.getElementById('vibe-status-badge');
      const s = telemetry.state;
      const fft = telemetry.fftBins;

      if (zone === 'all') {
        if (descEl) descEl.textContent = `⚡ SPECTRUM: 0-4000 Hz • OVERALL RMS: ${s.vibrationRms.toFixed(2)} mm/s • ISO 10816: ZONE A`;
        if (badgeEl) { badgeEl.textContent = '✓ NOMINAL'; badgeEl.style.color = 'var(--emerald-safe)'; }
      } else if (zone === 'shaft') {
        const shaftAmp = (fft[1] || 0.88).toFixed(2);
        if (descEl) descEl.textContent = `⚡ 1X CRANKSHAFT (70 Hz): Dynamic balance nominal • Residual: ${shaftAmp} mm/s`;
        if (badgeEl) { badgeEl.textContent = '✓ BALANCED'; badgeEl.style.color = 'var(--emerald-safe)'; }
      } else if (zone === 'bearing') {
        const bAmp = (fft[29] || 0.16).toFixed(2);
        const isDamaged = fft[29] > 0.8;
        if (descEl) descEl.textContent = isDamaged ? `🚨 PRSU GEARBOX BEARING: Wear Spike Detected (${bAmp} mm/s) • Spalling Alert` : `⚡ 1800 Hz PRSU BEARING: Hydrodynamic oil film clearance nominal (${bAmp} mm/s)`;
        if (badgeEl) {
          badgeEl.textContent = isDamaged ? '⚠️ ALERT' : '✓ CLEARANCE OK';
          badgeEl.style.color = isDamaged ? 'var(--amber-warn)' : 'var(--emerald-safe)';
        }
      } else if (zone === 'knock') {
        const kAmp = (fft[51] || 0.08).toFixed(2);
        const isKnock = fft[51] > 1.0;
        if (descEl) descEl.textContent = isKnock ? `🚨 CYL #3 DETONATION: Acoustic Pressure Spike (${kAmp} mm/s) • Retard Timing!` : `⚡ 3200 Hz ACOUSTIC DETONATION: No end-gas pre-knock shockwaves (${kAmp} mm/s)`;
        if (badgeEl) {
          badgeEl.textContent = isKnock ? '🚨 DETONATION' : '✓ NOMINAL';
          badgeEl.style.color = isKnock ? 'var(--crimson-crit)' : 'var(--emerald-safe)';
        }
      }

      renderFftSpectrum(telemetry.fftBins);
    });
  });

  // =========================================================================
  // OTTO 4-STROKE CYCLE KINEMATICS ROWS CLICK INSPECTORS
  // =========================================================================
  const hudStroke1 = document.getElementById('hud-cyl-stroke-1');
  const hudStroke2 = document.getElementById('hud-cyl-stroke-2');
  const hudStroke3 = document.getElementById('hud-cyl-stroke-3');
  const hudStroke4 = document.getElementById('hud-cyl-stroke-4');

  const bindStrokeInspect = (el, compKey) => {
    if (!el) return;
    el.title = `Click to inspect ${compKey.toUpperCase()} assembly & diagnostics`;
    el.addEventListener('click', () => {
      soundFx.playClick();
      engine3D.inspectComponent(compKey);
      if (subsystem3D) subsystem3D.loadSubsystem(compKey);
      updateEducationalGuideDOM(compKey);
      updateEmergencyButtonsUI(compKey);
      scrollToInspector();
    });
  };

  bindStrokeInspect(hudStroke1, 'cyl1');
  bindStrokeInspect(hudStroke2, 'cyl2');
  bindStrokeInspect(hudStroke3, 'cyl3');
  bindStrokeInspect(hudStroke4, 'cyl4');

  // =========================================================================
  // PRIMARY TELEMETRY TILES CLICK-TO-INSPECT BINDINGS
  // =========================================================================
  const tileRpm = document.getElementById('tile-card-rpm');
  const tileMap = document.getElementById('tile-card-map');
  const tileFuel = document.getElementById('tile-card-fuel');
  const tileOil = document.getElementById('tile-card-oil');
  const tileCht = document.getElementById('tile-card-cht');

  const bindTileInspect = (el, compKey, titleHint) => {
    if (!el) return;
    el.title = `Click to inspect ${titleHint || compKey.toUpperCase()}`;
    el.style.cursor = 'pointer';
    el.addEventListener('click', (e) => {
      if (e.target.closest('button')) return; // Avoid intercepting inner buttons like fuel wall
      soundFx.playClick();
      engine3D.inspectComponent(compKey);
      if (subsystem3D) subsystem3D.loadSubsystem(compKey);
      updateEducationalGuideDOM(compKey);
      updateEmergencyButtonsUI(compKey);
      scrollToInspector();
    });
  };

  bindTileInspect(tileRpm, 'crankshaft', 'Crankshaft & RPM Sensors');
  bindTileInspect(tileMap, 'turbo', 'Turbocharger & Boost Control');
  bindTileInspect(tileFuel, 'fuel_system', 'Fuel Rail & Metering');
  bindTileInspect(tileOil, 'oil_system', 'Oil Pump & Lubrication');
  bindTileInspect(tileCht, 'cyl3', 'Cylinder Head Assemblies');

  const tileElectrical = document.getElementById('tile-card-electrical');
  const tileFadec = document.getElementById('tile-card-fadec');
  bindTileInspect(tileElectrical, 'gearbox', '28V Alternator & Electrical Bus');
  bindTileInspect(tileFadec, 'fuel_system', 'FADEC Injection & Performance Map');

  // Cylinder Columns inside CHT Tile
  const cylColumns = document.querySelectorAll('#tile-card-cht .cyl-column');
  cylColumns.forEach((col, idx) => {
    col.title = `Inspect Cylinder #${idx + 1}`;
    col.addEventListener('click', (e) => {
      e.stopPropagation();
      const cKey = `cyl${idx + 1}`;
      soundFx.playClick();
      engine3D.inspectComponent(cKey);
      if (subsystem3D) subsystem3D.loadSubsystem(cKey);
      updateEducationalGuideDOM(cKey);
      updateEmergencyButtonsUI(cKey);
      scrollToInspector();
    });
  });

  // =========================================================================
  // SIMULATION & MISSION BLACKBOX REPLAY CONTROLLER (DRDO SPEC SECTION E)
  // =========================================================================
  const btnReplayPlayPause = document.getElementById('btn-replay-play-pause');
  const replaySlider = document.getElementById('replay-progress-slider');
  const replaySpeedBtns = document.querySelectorAll('.replay-spd-btn');
  const envPresetBtns = document.querySelectorAll('.env-preset-btn');

  if (btnReplayPlayPause) {
    btnReplayPlayPause.addEventListener('click', () => {
      soundFx.playClick();
      const isReplaying = telemetry.toggleReplay();
      const icon = document.getElementById('replay-play-icon');
      const txt = document.getElementById('replay-play-txt');
      if (icon && txt) {
        icon.textContent = isReplaying ? '⏸' : '▶';
        txt.textContent = isReplaying ? 'PAUSE LOG' : 'PLAY LOG';
      }
    });
  }

  if (replaySlider) {
    replaySlider.addEventListener('input', (e) => {
      const idx = parseInt(e.target.value, 10);
      telemetry.seekReplay(idx);
    });
  }

  replaySpeedBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      const spd = parseFloat(btn.getAttribute('data-spd') || '1');
      telemetry.setReplaySpeed(spd);
      replaySpeedBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  envPresetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      soundFx.playClick();
      const env = btn.getAttribute('data-env') || 'nominal_cruise';
      telemetry.setEnvironmentalProfile(env);
      envPresetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // =========================================================================
  // DRDO SIH-26054 COMPLIANCE & REQUIREMENTS MODAL CONTROLLER
  // =========================================================================
  const complianceModal = document.getElementById('compliance-modal');
  const btnOpenCompliance = document.getElementById('btn-open-compliance');
  const btnCloseCompliance = document.getElementById('btn-close-compliance');
  const btnCompToTwin = document.getElementById('btn-comp-to-twin');
  const btnCompToMission = document.getElementById('btn-comp-to-mission');
  const btnCompToReport = document.getElementById('btn-comp-to-report');

  const openComplianceModal = () => {
    soundFx.playClick();
    if (complianceModal) complianceModal.classList.add('active');
  };

  const closeComplianceModal = () => {
    soundFx.playClick();
    if (complianceModal) complianceModal.classList.remove('active');
  };

  if (btnOpenCompliance) btnOpenCompliance.addEventListener('click', openComplianceModal);
  if (btnCloseCompliance) btnCloseCompliance.addEventListener('click', closeComplianceModal);

  if (btnCompToTwin) {
    btnCompToTwin.addEventListener('click', () => {
      closeComplianceModal();
      navigateToView('view-twin', true);
    });
  }

  if (btnCompToMission) {
    btnCompToMission.addEventListener('click', () => {
      closeComplianceModal();
      navigateToView('view-mission', true);
    });
  }

  if (btnCompToReport) {
    btnCompToReport.addEventListener('click', () => {
      closeComplianceModal();
      const rBtn = document.getElementById('btn-open-report');
      if (rBtn) {
        rBtn.click();
      } else {
        const reportModal = document.getElementById('report-modal');
        const reportContainer = document.getElementById('report-modal-content') || document.getElementById('report-paper-container');
        if (reportModal) reportModal.classList.add('active');
        if (reportContainer) reportContainer.innerHTML = reportGen.generateHtmlReport();
      }
    });
  }

  if (complianceModal) {
    complianceModal.addEventListener('click', (e) => {
      if (e.target === complianceModal) closeComplianceModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && complianceModal && complianceModal.classList.contains('active')) {
      closeComplianceModal();
    }
  });

  // Top Header Brand Logo Click -> Return to 3D Digital Twin Cockpit
  const brandTitle = document.querySelector('.header-brand');
  if (brandTitle) {
    brandTitle.style.cursor = 'pointer';
    brandTitle.title = 'Click to switch to 3D Digital Twin View';
    brandTitle.addEventListener('click', () => {
      soundFx.playClick();
      const tabTwin = document.getElementById('tab-twin');
      if (tabTwin) tabTwin.click();
    });
  }

  // Helper: Update Telemetry DOM Elements
  function updateTelemetryUI(state, ai) {
    // Sync Preflight Header Badge & live modal if open
    const pfAudit = aiEngine.getPreflightAudit(state, telemetry);
    const pfHeaderBadge = document.getElementById('header-preflight-badge');
    const pfHeaderDot = document.getElementById('header-preflight-dot');
    if (pfHeaderBadge && pfHeaderDot) {
      if (pfAudit.decision === 'GO') {
        pfHeaderBadge.textContent = 'PRE-FLIGHT AI (GO)';
        pfHeaderBadge.style.color = '#c084fc';
        pfHeaderDot.style.background = 'var(--emerald-safe)';
      } else {
        pfHeaderBadge.textContent = 'PRE-FLIGHT AI (NO-GO)';
        pfHeaderBadge.style.color = 'var(--crimson-crit)';
        pfHeaderDot.style.background = 'var(--crimson-crit)';
      }
    }

    // If preflight modal is currently open, refresh its data live
    if (preflightModal && preflightModal.classList.contains('active')) {
      renderPreflightModal(pfAudit);
    }

    // If deep AI modal is currently open, refresh its data live
    if (aiDeepModal && aiDeepModal.classList.contains('active')) {
      renderAIDeepModal();
    }

    // Top HUD Telemetry
    safeSetText('hud-rpm-val', Math.round(state.rpm));
    safeSetText('hud-map-val', state.map.toFixed(1));
    safeSetText('hud-cht3-val', `${Math.round(state.cht[2])}°C`);
    safeSetText('hud-health-val', `${ai.healthIndex.toFixed(1)}%`);

    // Primary Tiles
    safeSetText('tile-rpm-val', Math.round(state.rpm));
    safeSetWidth('gauge-fill-rpm', (state.rpm / 5800) * 100);

    safeSetText('tile-map-val', state.map.toFixed(1));
    safeSetWidth('gauge-fill-map', (state.map / 45) * 100);

    safeSetText('tile-oil-press', state.oilPress.toFixed(1));
    safeSetText('tile-oil-temp', `${Math.round(state.oilTemp)}°C`);
    safeSetWidth('gauge-fill-oil', (state.oilPress / 70) * 100);

    safeSetText('tile-fuel-flow', state.fuelFlow.toFixed(1));
    safeSetText('tile-fuel-remaining', state.fuelRemainingKg.toFixed(1));
    safeSetText('tile-fuel-afr', state.afr.toFixed(1));
    safeSetWidth('gauge-fill-fuel', (state.fuelFlow / 40) * 100);
    safeSetText('tile-vibe-rms', state.vibrationRms.toFixed(2));
    safeSetText('map-endurance-hrs', `${state.enduranceHrs} HRS`);
    safeSetText('map-fuel-remaining', `${state.fuelRemainingKg.toFixed(1)} KG`);

    // Quad Cylinder CHT & EGT Bars
    for (let i = 0; i < 4; i++) {
      safeSetText(`cyl-cht-${i + 1}`, `${Math.round(state.cht[i])}°`);
      safeSetHeight(`cyl-bar-${i + 1}`, Math.min(100, Math.max(10, (state.cht[i] / 260) * 100)));

      // Color warning / critical
      const bar = document.getElementById(`cyl-bar-${i + 1}`);
      if (bar) {
        bar.className = 'cyl-meter-fill ' + (state.cht[i] > 210 ? 'critical' : state.cht[i] > 185 ? 'warning' : '');
      }
    }

    // Tile 6: 28V Electrical Bus & Alternator Subsystem (DRDO Spec Section B)
    const battV = typeof state.batteryVolt === 'number' ? state.batteryVolt : 28.2;
    const altA = typeof state.alternatorAmps === 'number' ? state.alternatorAmps : 38.5;
    const altH = typeof state.alternatorHealth === 'number' ? state.alternatorHealth : 99.4;
    safeSetText('tile-battery-volt', battV.toFixed(1));
    safeSetWidth('gauge-fill-battery', Math.min(100, Math.max(5, ((battV - 20) / 12) * 100)));
    safeSetText('tile-alt-amps', `${altA.toFixed(1)} A`);
    safeSetText('tile-alt-status', `ALT HEALTH: ${Math.round(altH)}%`);

    const altStatusEl = document.getElementById('tile-alt-status');
    if (altStatusEl) {
      altStatusEl.style.color = altH > 85 ? 'var(--emerald-safe)' : altH > 65 ? 'var(--amber-warn)' : 'var(--crimson-crit)';
    }

    // Tile 7: FADEC Injection Timing & Performance Map (DRDO Spec Section B & D)
    const injTiming = typeof state.injectionTimingDeg === 'number' ? state.injectionTimingDeg : 24.0;
    const injPulse = typeof state.injectionPulseWidthMs === 'number' ? state.injectionPulseWidthMs : 4.25;
    const bteVal = typeof state.bte === 'number' ? state.bte : 32.8;
    const bsfcVal = typeof state.bsfc === 'number' ? state.bsfc : 236;
    safeSetText('tile-injection-timing', `${injTiming.toFixed(1)}°`);
    safeSetWidth('gauge-fill-fadec', Math.min(100, Math.max(10, (injTiming / 40) * 100)));
    safeSetText('tile-pulse-width', `${injPulse.toFixed(2)} ms`);
    safeSetText('tile-bte-val', `${bteVal.toFixed(1)}%`);
    safeSetText('tile-bsfc-val', Math.round(bsfcVal));

    // Synchronize Blackbox Replay Toolbar Status (DRDO Spec Section E)
    const replayPlayIcon = document.getElementById('replay-play-icon');
    const replayPlayTxt = document.getElementById('replay-play-txt');
    const replaySliderEl = document.getElementById('replay-progress-slider');
    const replayTimeEl = document.getElementById('replay-time-display');
    const replayPhaseEl = document.getElementById('replay-phase-badge');

    if (telemetry.replayActive) {
      if (replayPlayIcon) replayPlayIcon.textContent = '⏸';
      if (replayPlayTxt) replayPlayTxt.textContent = 'PAUSE LOG';
      const repBuf = telemetry.replayBuffer || telemetry.replayLog || [];
      if (replaySliderEl && repBuf.length > 0) {
        replaySliderEl.max = Math.max(1, repBuf.length - 1);
        replaySliderEl.value = telemetry.replayIndex;
      }
      if (replayTimeEl && repBuf.length > 0) {
        const curSec = Math.floor(telemetry.replayIndex / 10);
        const totSec = Math.floor(repBuf.length / 10);
        replayTimeEl.textContent = `${String(Math.floor(curSec / 60)).padStart(2, '0')}:${String(curSec % 60).padStart(2, '0')} / ${String(Math.floor(totSec / 60)).padStart(2, '0')}:${String(totSec % 60).padStart(2, '0')}`;
      }
      if (replayPhaseEl) {
        replayPhaseEl.textContent = `REPLAY (${telemetry.replaySpeed}X)`;
        replayPhaseEl.style.background = 'rgba(192, 132, 252, 0.2)';
        replayPhaseEl.style.color = '#c084fc';
        replayPhaseEl.style.borderColor = 'rgba(192, 132, 252, 0.4)';
      }
    } else {
      if (replayPlayIcon) replayPlayIcon.textContent = '▶';
      if (replayPlayTxt) replayPlayTxt.textContent = 'PLAY LOG';
      const histBuf = telemetry.historyBuffer || telemetry.replayLog || [];
      if (replaySliderEl && histBuf.length > 0) {
        replaySliderEl.max = Math.max(1, histBuf.length - 1);
        replaySliderEl.value = histBuf.length - 1;
      }
      if (replayTimeEl && histBuf.length > 0) {
        const totSec = Math.floor(histBuf.length / 10);
        replayTimeEl.textContent = `LIVE • ${String(Math.floor(totSec / 60)).padStart(2, '0')}:${String(totSec % 60).padStart(2, '0')} LOGGED`;
      }
      if (replayPhaseEl) {
        replayPhaseEl.textContent = 'LIVE STREAM';
        replayPhaseEl.style.background = 'rgba(0, 240, 255, 0.12)';
        replayPhaseEl.style.color = 'var(--cyan-hud)';
        replayPhaseEl.style.borderColor = 'rgba(0, 240, 255, 0.3)';
      }
    }

    // AI Health Indicators
    safeSetText('ai-health-num', Math.round(ai.healthIndex));
    safeSetText('ai-rul-hours', `${ai.rulHours} HRS`);
    safeSetText('ai-fault-badge', ai.detectedFault);

    // Radial Gauge
    const circle = document.getElementById('health-gauge-circle');
    if (circle) {
      // Circumference = 2 * PI * 45 = ~283
      const offset = 283 - (ai.healthIndex / 100) * 283;
      circle.style.strokeDashoffset = offset;
      circle.style.stroke = ai.healthIndex > 85 ? 'var(--emerald-safe)' : ai.healthIndex > 60 ? 'var(--amber-warn)' : 'var(--crimson-crit)';
    }

    // SHAP Feature Attribution Bars
    safeSetWidth('shap-cht3-bar', ai.shapValues.cht3);
    safeSetText('shap-cht3-pct', `${ai.shapValues.cht3}%`);

    safeSetWidth('shap-vibe-bar', ai.shapValues.vibration);
    safeSetText('shap-vibe-pct', `${ai.shapValues.vibration}%`);

    safeSetWidth('shap-oil-bar', ai.shapValues.oilPress);
    safeSetText('shap-oil-pct', `${ai.shapValues.oilPress}%`);

    safeSetWidth('shap-map-bar', ai.shapValues.mapBoost);
    safeSetText('shap-map-pct', `${ai.shapValues.mapBoost}%`);

    // Bottom Status Bar
    safeSetText('status-engine-rpm', `${Math.round(state.rpm)} RPM`);
    safeSetText('status-health-val', `${ai.healthIndex.toFixed(1)}%`);
    safeSetText('status-mode-val', ai.status);
    const statusElem = document.getElementById('status-mode-val');
    if (statusElem) {
      statusElem.className = 'status-val ' + (ai.status === 'NOMINAL' ? 'nominal' : ai.status === 'DEGRADED' ? 'warning' : 'critical');
    }

    // Hardware Ingestion Counter
    safeSetText('hw-packets-count', telemetry.hardwarePacketsCount);

    // 8. Low / Out-of-Bounds Reading Warning & Master Annunciator Evaluation
    updateTelemetryWarnings(state, ai);
  }

  // Master Annunciator State Tracker
  let lastMasterCautionState = 'nominal';
  let lastAudioAlertTime = 0;

  // Helper: Low Reading Warnings & Master Annunciator Evaluator
  function updateTelemetryWarnings(state, ai) {
    const activeWarnings = [];

    // 1. Engine Speed (RPM)
    // Required Envelope: >= 3000 RPM (up to 5500 RPM)
    const rpmCard = document.getElementById('tile-card-rpm');
    const rpmBadge = document.getElementById('badge-rpm-alert');
    const rpmVal = document.getElementById('tile-rpm-val');
    const rpmSub = document.getElementById('tile-rpm-sub');
    const hudRpm = document.getElementById('hud-rpm-val');

    if (state.rpm < 1800) {
      if (rpmCard) rpmCard.className = 'telemetry-tile critical-state';
      if (rpmBadge) { rpmBadge.className = 'tile-alert-badge critical'; rpmBadge.textContent = '🚨 STALL (<1800)'; }
      if (rpmVal) rpmVal.className = 'val-critical';
      if (rpmSub) rpmSub.textContent = 'CRITICAL STALL';
      if (hudRpm) hudRpm.className = 'val-critical';
      activeWarnings.push({ id: 'rpm', label: `LOW RPM / STALL: ${Math.round(state.rpm)} RPM (REQ: >3000)`, level: 'critical' });
    } else if (state.rpm < 3000) {
      if (rpmCard) rpmCard.className = 'telemetry-tile warning-state';
      if (rpmBadge) { rpmBadge.className = 'tile-alert-badge warning'; rpmBadge.textContent = '⚠️ LOW RPM (<3000)'; }
      if (rpmVal) rpmVal.className = 'val-warning';
      if (rpmSub) rpmSub.textContent = 'UNDERSPEED DECAY';
      if (hudRpm) hudRpm.className = 'val-warning';
      activeWarnings.push({ id: 'rpm', label: `LOW RPM WARNING: ${Math.round(state.rpm)} RPM (REQ: >3000)`, level: 'warning' });
    } else if (state.rpm > 5500) {
      if (rpmCard) rpmCard.className = 'telemetry-tile warning-state';
      if (rpmBadge) { rpmBadge.className = 'tile-alert-badge warning'; rpmBadge.textContent = '⚠️ REDLINE (>5500)'; }
      if (rpmVal) rpmVal.className = 'val-warning';
      if (rpmSub) rpmSub.textContent = 'OVERSPEED';
      if (hudRpm) hudRpm.className = 'val-warning';
      activeWarnings.push({ id: 'rpm', label: `OVERSPEED WARNING: ${Math.round(state.rpm)} RPM`, level: 'warning' });
    } else {
      if (rpmCard) rpmCard.className = 'telemetry-tile';
      if (rpmBadge) { rpmBadge.className = 'tile-alert-badge nominal'; rpmBadge.textContent = '✓ NOMINAL'; }
      if (rpmVal) rpmVal.className = '';
      if (rpmSub) rpmSub.textContent = 'RPM (REQ: >3000)';
      if (hudRpm) hudRpm.className = '';
    }

    // 2. Manifold Absolute Pressure (MAP / Boost)
    // Required Envelope: >= 28.0 inHg
    const mapCard = document.getElementById('tile-card-map');
    const mapBadge = document.getElementById('badge-map-alert');
    const mapVal = document.getElementById('tile-map-val');
    const mapSub = document.getElementById('tile-map-sub');
    const hudMap = document.getElementById('hud-map-val');

    if (state.map < 22.0) {
      if (mapCard) mapCard.className = 'telemetry-tile critical-state';
      if (mapBadge) { mapBadge.className = 'tile-alert-badge critical'; mapBadge.textContent = '🚨 UNDERBOOST (<22)'; }
      if (mapVal) mapVal.className = 'val-critical';
      if (mapSub) mapSub.textContent = 'CRITICAL BOOST LOSS';
      if (hudMap) hudMap.className = 'val-critical';
      activeWarnings.push({ id: 'map', label: `CRITICAL UNDERBOOST: ${state.map.toFixed(1)} inHg (REQ: >28)`, level: 'critical' });
    } else if (state.map < 28.0) {
      if (mapCard) mapCard.className = 'telemetry-tile warning-state';
      if (mapBadge) { mapBadge.className = 'tile-alert-badge warning'; mapBadge.textContent = '⚠️ LOW BOOST (<28)'; }
      if (mapVal) mapVal.className = 'val-warning';
      if (mapSub) mapSub.textContent = 'BOOST DEFICIT';
      if (hudMap) hudMap.className = 'val-warning';
      activeWarnings.push({ id: 'map', label: `LOW BOOST: ${state.map.toFixed(1)} inHg (REQ: >28)`, level: 'warning' });
    } else if (state.map > 40.0) {
      if (mapCard) mapCard.className = 'telemetry-tile warning-state';
      if (mapBadge) { mapBadge.className = 'tile-alert-badge warning'; mapBadge.textContent = '⚠️ OVERBOOST (>40)'; }
      if (mapVal) mapVal.className = 'val-warning';
      if (mapSub) mapSub.textContent = 'OVERPRESSURE';
      if (hudMap) hudMap.className = 'val-warning';
      activeWarnings.push({ id: 'map', label: `OVERBOOST WARNING: ${state.map.toFixed(1)} inHg`, level: 'warning' });
    } else {
      if (mapCard) mapCard.className = 'telemetry-tile';
      if (mapBadge) { mapBadge.className = 'tile-alert-badge nominal'; mapBadge.textContent = '✓ NOMINAL'; }
      if (mapVal) mapVal.className = '';
      if (mapSub) mapSub.textContent = 'inHg (REQ: >28)';
      if (hudMap) hudMap.className = '';
    }

    // 3. Fuel Subsystem & Emergency Fuel Wall
    const fuelCard = document.getElementById('tile-card-fuel');
    const fuelBadge = document.getElementById('badge-fuel-alert');
    const fuelFlowVal = document.getElementById('tile-fuel-flow');
    const fuelSub = document.getElementById('tile-fuel-sub');

    if (!state.fuelWallOpen) {
      if (fuelCard) fuelCard.className = 'telemetry-tile critical-state';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge critical'; fuelBadge.textContent = '🚨 CUTOFF'; }
      if (fuelFlowVal) fuelFlowVal.className = 'val-critical';
      if (fuelSub) fuelSub.textContent = 'VALVE CLOSED';
      activeWarnings.push({ id: 'fuel_wall', label: 'FIREWALL CUTOFF: FUEL ISOLATED (STARVATION)', level: 'critical' });
    } else if (state.fuelRemainingKg < 20.0) {
      if (fuelCard) fuelCard.className = 'telemetry-tile critical-state';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge critical'; fuelBadge.textContent = '🚨 LOW FUEL (<20kg)'; }
      if (fuelFlowVal) fuelFlowVal.className = 'val-critical';
      if (fuelSub) fuelSub.textContent = 'RESERVE EXHAUSTION';
      activeWarnings.push({ id: 'fuel_low', label: `EMERGENCY FUEL RESERVE: ${state.fuelRemainingKg.toFixed(1)} KG`, level: 'critical' });
    } else if (state.fuelRemainingKg < 45.0) {
      if (fuelCard) fuelCard.className = 'telemetry-tile warning-state';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge warning'; fuelBadge.textContent = '⚠️ BINGO FUEL (<45kg)'; }
      if (fuelFlowVal) fuelFlowVal.className = 'val-warning';
      if (fuelSub) fuelSub.textContent = 'BINGO FUEL';
      activeWarnings.push({ id: 'fuel_low', label: `BINGO FUEL: ${state.fuelRemainingKg.toFixed(1)} KG (REQ: >45)`, level: 'warning' });
    } else if (state.afr > 15.8) {
      if (fuelCard) fuelCard.className = 'telemetry-tile warning-state';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge warning'; fuelBadge.textContent = '⚠️ LEAN AFR (>15.8)'; }
      if (fuelSub) fuelSub.textContent = 'PRE-KNOCK RISK';
      activeWarnings.push({ id: 'afr_lean', label: `LEAN MIXTURE: ${state.afr.toFixed(1)} AFR (PRE-KNOCK RISK)`, level: 'warning' });
    } else if (state.fuelFlow < 8.0 && state.rpm > 2000) {
      if (fuelCard) fuelCard.className = 'telemetry-tile warning-state';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge warning'; fuelBadge.textContent = '⚠️ LOW FLOW (<8)'; }
      if (fuelSub) fuelSub.textContent = 'FEED RESTRICTION';
      activeWarnings.push({ id: 'fuel_flow', label: `LOW FUEL FLOW: ${state.fuelFlow.toFixed(1)} L/HR`, level: 'warning' });
    } else {
      if (fuelCard) fuelCard.className = 'telemetry-tile';
      if (fuelBadge) { fuelBadge.className = 'tile-alert-badge nominal'; fuelBadge.textContent = '✓ NOMINAL'; }
      if (fuelFlowVal) fuelFlowVal.className = '';
      if (fuelSub) fuelSub.textContent = 'L/HR';
    }

    // 4. Lubrication System (Oil Pressure & Temperature)
    // Required Envelope: >= 42.0 PSI
    const oilCard = document.getElementById('tile-card-oil');
    const oilBadge = document.getElementById('badge-oil-alert');
    const oilPressVal = document.getElementById('tile-oil-press');
    const oilSub = document.getElementById('tile-oil-sub');
    const oilTempSub = document.getElementById('tile-oil-temp-sub');

    if (state.oilPress < 25.0) {
      if (oilCard) oilCard.className = 'telemetry-tile critical-state';
      if (oilBadge) { oilBadge.className = 'tile-alert-badge critical'; oilBadge.textContent = '🚨 SEIZURE RISK (<25)'; }
      if (oilPressVal) oilPressVal.className = 'val-critical';
      if (oilSub) oilSub.textContent = 'CRITICAL LUBE LOSS';
      activeWarnings.push({ id: 'oil_press', label: `CRITICAL OIL PRESSURE: ${state.oilPress.toFixed(1)} PSI (REQ: >42)`, level: 'critical' });
    } else if (state.oilPress < 42.0) {
      if (oilCard) oilCard.className = 'telemetry-tile warning-state';
      if (oilBadge) { oilBadge.className = 'tile-alert-badge warning'; oilBadge.textContent = '⚠️ LOW OIL (<42)'; }
      if (oilPressVal) oilPressVal.className = 'val-warning';
      if (oilSub) oilSub.textContent = 'CAVITATION / LOSS';
      activeWarnings.push({ id: 'oil_press', label: `LOW OIL PRESSURE: ${state.oilPress.toFixed(1)} PSI (REQ: >42)`, level: 'warning' });
    } else {
      if (oilCard) oilCard.className = 'telemetry-tile';
      if (oilBadge) { oilBadge.className = 'tile-alert-badge nominal'; oilBadge.textContent = '✓ NOMINAL'; }
      if (oilPressVal) oilPressVal.className = '';
      if (oilSub) oilSub.textContent = 'PSI (REQ: >42)';
    }

    // Oil Temperature
    if (state.oilTemp > 105.0) {
      if (oilTempSub) { oilTempSub.textContent = 'HIGH TEMP (>105°)'; oilTempSub.style.color = 'var(--crimson-crit)'; }
      activeWarnings.push({ id: 'oil_temp', label: `HIGH OIL TEMP: ${Math.round(state.oilTemp)}°C (LIMIT: 105°C)`, level: 'warning' });
    } else if (state.oilTemp < 60.0 && state.rpm > 2000) {
      if (oilTempSub) { oilTempSub.textContent = 'COLD OIL (<60°)'; oilTempSub.style.color = 'var(--amber-warn)'; }
      activeWarnings.push({ id: 'oil_temp', label: `COLD OIL: ${Math.round(state.oilTemp)}°C (REQ: >65°C)`, level: 'warning' });
    } else {
      if (oilTempSub) { oilTempSub.textContent = 'SAFE (<105°)'; oilTempSub.style.color = 'var(--emerald-safe)'; }
    }

    // 5. Cylinder Head Temperatures (CHT 1-4)
    const chtCard = document.getElementById('tile-card-cht');
    const chtBadge = document.getElementById('badge-cht-alert');
    const maxCht = Math.max(...state.cht);
    const minCht = Math.min(...state.cht);
    const hudCht3 = document.getElementById('hud-cht3-val');

    if (maxCht > 215.0) {
      if (chtCard) chtCard.className = 'telemetry-tile critical-state';
      if (chtBadge) { chtBadge.className = 'tile-alert-badge critical'; chtBadge.textContent = '🚨 OVERHEAT (>215°)'; }
      if (hudCht3) hudCht3.className = 'val-critical';
      activeWarnings.push({ id: 'cht_high', label: `THERMAL RUNAWAY: CHT ${Math.round(maxCht)}°C (LIMIT: 215°C)`, level: 'critical' });
    } else if (maxCht > 185.0) {
      if (chtCard) chtCard.className = 'telemetry-tile warning-state';
      if (chtBadge) { chtBadge.className = 'tile-alert-badge warning'; chtBadge.textContent = '⚠️ HIGH CHT (>185°)'; }
      if (hudCht3) hudCht3.className = 'val-warning';
      activeWarnings.push({ id: 'cht_high', label: `ELEVATED CHT: ${Math.round(maxCht)}°C (REQ: <185°C)`, level: 'warning' });
    } else if (minCht < 90.0 && state.rpm > 2500) {
      if (chtCard) chtCard.className = 'telemetry-tile warning-state';
      if (chtBadge) { chtBadge.className = 'tile-alert-badge warning'; chtBadge.textContent = '⚠️ COLD CYL (<90°)'; }
      activeWarnings.push({ id: 'cht_cold', label: `COLD CYLINDER MISFIRE: ${Math.round(minCht)}°C (REQ: >90°C)`, level: 'warning' });
    } else {
      if (chtCard) chtCard.className = 'telemetry-tile';
      if (chtBadge) { chtBadge.className = 'tile-alert-badge nominal'; chtBadge.textContent = '✓ NOMINAL'; }
      if (hudCht3) hudCht3.className = '';
    }

    // 6. 28V Electrical Bus & Alternator (DRDO Spec Section B)
    const eleCard = document.getElementById('tile-card-electrical');
    const eleBadge = document.getElementById('badge-electrical-alert');
    const battV = typeof state.batteryVolt === 'number' ? state.batteryVolt : 28.2;
    const altH = typeof state.alternatorHealth === 'number' ? state.alternatorHealth : 99.4;

    if (battV < 24.0 || altH < 50.0) {
      if (eleCard) eleCard.className = 'telemetry-tile critical-state';
      if (eleBadge) { eleBadge.className = 'tile-alert-badge critical'; eleBadge.textContent = '🚨 BUS FAULT'; }
      activeWarnings.push({ id: 'electrical_bus', label: `28V BUS UNDERVOLT: ${battV.toFixed(1)}V (LIMIT: >24V)`, level: 'critical' });
    } else if (battV < 26.0 || altH < 80.0) {
      if (eleCard) eleCard.className = 'telemetry-tile warning-state';
      if (eleBadge) { eleBadge.className = 'tile-alert-badge warning'; eleBadge.textContent = '⚠️ LOW BUS'; }
      activeWarnings.push({ id: 'electrical_bus', label: `LOW ELECTRICAL BUS: ${battV.toFixed(1)}V (REQ: >26V)`, level: 'warning' });
    } else {
      if (eleCard) eleCard.className = 'telemetry-tile';
      if (eleBadge) { eleBadge.className = 'tile-alert-badge nominal'; eleBadge.textContent = '✓ CHARGING'; }
    }

    // 7. Combustion Stability & FADEC Timing (DRDO Spec Section B & C)
    const fadecCard = document.getElementById('tile-card-fadec');
    const fadecBadge = document.getElementById('badge-fadec-alert');
    const combStab = typeof state.combustionStability === 'number' ? state.combustionStability : 1.0;
    const bte = typeof state.bte === 'number' ? state.bte : 32.8;

    if (combStab < 0.70 || state.misfireDetected) {
      if (fadecCard) fadecCard.className = 'telemetry-tile critical-state';
      if (fadecBadge) { fadecBadge.className = 'tile-alert-badge critical'; fadecBadge.textContent = '🚨 MISFIRE'; }
      activeWarnings.push({ id: 'combustion', label: `COMBUSTION FLUTTER / CYCLIC MISFIRE DETECTED`, level: 'critical' });
    } else if (combStab < 0.88 || bte < 28.0) {
      if (fadecCard) fadecCard.className = 'telemetry-tile warning-state';
      if (fadecBadge) { fadecBadge.className = 'tile-alert-badge warning'; fadecBadge.textContent = '⚠️ FLUTTER'; }
      activeWarnings.push({ id: 'combustion', label: `COMBUSTION INSTABILITY / LOW BTE (${bte.toFixed(1)}%)`, level: 'warning' });
    } else {
      if (fadecCard) fadecCard.className = 'telemetry-tile';
      if (fadecBadge) { fadecBadge.className = 'tile-alert-badge nominal'; fadecBadge.textContent = '✓ OPTIMAL'; }
    }

    if (state.sensorDriftActive) {
      activeWarnings.push({ id: 'sensor_drift', label: `AI SENSOR DRIFT: CHT #4 THERMISTOR CALIBRATION DECAY`, level: 'warning' });
    }

    // 8. Master Caution & Annunciator Panel DOM Update
    const banner = document.getElementById('master-caution-banner');
    const mainTitle = document.getElementById('caution-main-title');
    const chipsRow = document.getElementById('caution-chips-row');

    const hasCritical = activeWarnings.some(w => w.level === 'critical');
    const hasWarning = activeWarnings.length > 0;
    const currentLevel = hasCritical ? 'critical' : (hasWarning ? 'warning' : 'nominal');

    if (banner) {
      banner.className = `master-caution-banner ${currentLevel}`;
    }

    if (mainTitle) {
      if (hasCritical) {
        mainTitle.textContent = `🚨 MASTER WARNING: ${activeWarnings.length} CRITICAL DEFICIENCIES DETECTED`;
      } else if (hasWarning) {
        mainTitle.textContent = `⚠️ MASTER CAUTION: ${activeWarnings.length} SENSOR READING(S) BELOW REQUIRED SAFE ENVELOPE`;
      } else {
        mainTitle.textContent = `MASTER ANNUNCIATOR: ALL PROPULSION ENVELOPES NOMINAL`;
      }
    }

    if (chipsRow) {
      if (activeWarnings.length === 0) {
        chipsRow.innerHTML = `<span class="annunciator-chip nominal">✓ ALL 7 ENGINE SUBSYSTEMS WITHIN SAFE CEMILAC LIMITS</span>`;
      } else {
        chipsRow.innerHTML = activeWarnings.map(w => `
          <span class="annunciator-chip ${w.level}">
            ${w.level === 'critical' ? '🚨' : '⚠️'} ${w.label}
          </span>
        `).join('');
      }
    }

    // 7. Tactical Sound Synthesizer Chimes (Throttled)
    const now = Date.now();
    if (currentLevel !== lastMasterCautionState && (now - lastAudioAlertTime > 2000)) {
      if (currentLevel === 'critical') {
        soundFx.playAlarm();
        lastAudioAlertTime = now;
      } else if (currentLevel === 'warning') {
        soundFx.playCaution();
        lastAudioAlertTime = now;
      }
      lastMasterCautionState = currentLevel;
    }
  }

  // Helper: Update Tactical Mission Advisory
  function updateMissionAdvisory(state, ai) {
    const advBox = document.getElementById('contingency-card-box');
    const advTitle = document.getElementById('contingency-title-text');
    const advDesc = document.getElementById('contingency-desc-text');
    const advSteps = document.getElementById('contingency-steps-list');

    if (!advBox || !advTitle || !advDesc) return;

    if (!state.fuelWallOpen) {
      advBox.className = 'glass-card contingency-card critical-state';
      advTitle.className = 'contingency-title crit';
      advTitle.textContent = 'EMERGENCY: FUEL FIREWALL VALVE CLOSED';
      advDesc.textContent = 'Emergency fuel shutoff valve has isolated all fuel feed to engine. Engine has starved and flamed out. Immediate gliding recovery required.';
      if (advSteps) {
        advSteps.innerHTML = `
          <li>AIRSPEED CONTROL: GLIDE AT BEST L/D SPEED (104 KTS)</li>
          <li>DIVERT IMMEDIATELY TO STRIP BRAVO (DEESA FLS)</li>
          <li>EMERGENCY BEACON: SQUAWK 7700</li>
          <li>PREPARE DEAD-STICK LANDING ON RUNWAY 14/32</li>
        `;
      }
      return;
    }

    if (ai.status === 'CRITICAL' || state.cht[2] > 210) {
      advBox.className = 'glass-card contingency-card critical-state';
      advTitle.className = 'contingency-title crit';
      advTitle.textContent = 'CRITICAL ADVISORY: IN-FLIGHT THERMAL RUNAWAY';
      advDesc.textContent = `Severe thermo-mechanical anomaly detected on Cylinder #3 (CHT ${Math.round(state.cht[2])}°C) with pre-knock vibration. Gliding/powered range contracted.`;
      if (advSteps) {
        advSteps.innerHTML = `
          <li>DERATE THROTTLE COMMAND: 62% POWER</li>
          <li>INITIATE STEPPED DESCENT TO 10,000 FT (COOLER AIR DENSITY)</li>
          <li>DIVERT HEADING 235° TO STRIP BRAVO (DEESA FLS)</li>
          <li>SAFE RECOVERY PROBABILITY: 97.4%</li>
        `;
      }
    } else if (ai.status === 'DEGRADED' || state.map < 26) {
      advBox.className = 'glass-card contingency-card warning-state';
      advTitle.className = 'contingency-title warn';
      advTitle.textContent = 'CAUTION: TURBO BOOST DEGRADATION DETECTED';
      advDesc.textContent = `Wastegate leakage at 18,000 ft causing manifold pressure drop. High altitude loiter ceiling reduced.`;
      if (advSteps) {
        advSteps.innerHTML = `
          <li>RESTRICT FLIGHT CEILING TO 14,000 FT</li>
          <li>MONITOR AFR / MIXTURE ENRICHMENT</li>
          <li>RE-CALCULATE MISSION FUEL MARGIN (+18 MIN RESERVE)</li>
        `;
      }
    } else {
      advBox.className = 'glass-card contingency-card';
      advTitle.className = 'contingency-title safe';
      advTitle.textContent = 'ALL PROPULSION SYSTEMS NOMINAL';
      advDesc.textContent = `Digital twin telemetry is fully synchronized with airborne CANaerospace bus. Mission endurance intact.`;
      if (advSteps) {
        advSteps.innerHTML = `
          <li>CONTINUE PLANNED ISR SECTOR LOITER (WAYPOINT PATROL)</li>
          <li>RECOVERY ENVELOPE: BASE ALPHA (UTTARLAI AFS) READY</li>
          <li>PROJECTED MISSION ENDURANCE: 16.2 HRS REMAINING</li>
        `;
      }
    }
  }

  // Helper: Render FFT Canvas
  const fftCanvas = document.getElementById('fft-canvas');
  let fftCtx = fftCanvas ? fftCanvas.getContext('2d') : null;
  const fftTooltip = document.getElementById('fft-tooltip');

  let activeFftZone = 'all'; // 'all' | 'shaft' | 'bearing' | 'knock'

  function renderFftSpectrum(fftBins) {
    if (!fftCtx || !fftCanvas) return;
    const w = fftCanvas.clientWidth || 300;
    const h = fftCanvas.clientHeight || 95;
    if (fftCanvas.width !== w || fftCanvas.height !== h) {
      fftCanvas.width = w;
      fftCanvas.height = h;
    }
    fftCtx.clearRect(0, 0, w, h);

    // 1. Background Grid & Threshold Reference Lines
    fftCtx.lineWidth = 1;
    const y1 = h - (1.0 * (h / 2.5));
    const y2 = h - (2.0 * (h / 2.5));
    fftCtx.strokeStyle = 'rgba(0, 240, 255, 0.08)';
    fftCtx.beginPath();
    fftCtx.moveTo(0, y1); fftCtx.lineTo(w, y1);
    fftCtx.moveTo(0, y2); fftCtx.lineTo(w, y2);
    fftCtx.stroke();

    // Vertical frequency grid ticks (1k, 2k, 3k Hz)
    const x1k = (16 / 64) * w;
    const x2k = (32 / 64) * w;
    const x3k = (48 / 64) * w;
    fftCtx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    fftCtx.beginPath();
    fftCtx.moveTo(x1k, 0); fftCtx.lineTo(x1k, h);
    fftCtx.moveTo(x2k, 0); fftCtx.lineTo(x2k, h);
    fftCtx.moveTo(x3k, 0); fftCtx.lineTo(x3k, h);
    fftCtx.stroke();

    // 2. Highlight active selected zone with illuminated background band
    if (activeFftZone === 'shaft') {
      const zX = (0 / 64) * w;
      const zW = (4 / 64) * w;
      fftCtx.fillStyle = 'rgba(0, 240, 255, 0.14)';
      fftCtx.fillRect(zX, 0, zW, h);
      fftCtx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
      fftCtx.strokeRect(zX, 0, zW, h);
    } else if (activeFftZone === 'bearing') {
      const zX = (27 / 64) * w;
      const zW = (5 / 64) * w;
      fftCtx.fillStyle = 'rgba(245, 158, 11, 0.14)';
      fftCtx.fillRect(zX, 0, zW, h);
      fftCtx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
      fftCtx.strokeRect(zX, 0, zW, h);
    } else if (activeFftZone === 'knock') {
      const zX = (49 / 64) * w;
      const zW = (5 / 64) * w;
      fftCtx.fillStyle = 'rgba(239, 68, 68, 0.14)';
      fftCtx.fillRect(zX, 0, zW, h);
      fftCtx.strokeStyle = 'rgba(239, 68, 68, 0.5)';
      fftCtx.strokeRect(zX, 0, zW, h);
    }

    // 3. Render Spectrum Bars
    const barW = w / fftBins.length;
    let peakVal = 0;
    let peakIdx = 0;

    for (let i = 0; i < fftBins.length; i++) {
      const val = fftBins[i];
      if (val > peakVal) {
        peakVal = val;
        peakIdx = i;
      }
      const barH = Math.max(3, Math.min(h - 2, val * (h / 2.5)));
      const x = i * barW;
      const y = h - barH;

      let inZone = true;
      if (activeFftZone === 'shaft' && i > 3) inZone = false;
      if (activeFftZone === 'bearing' && (i < 27 || i > 31)) inZone = false;
      if (activeFftZone === 'knock' && (i < 49 || i > 53)) inZone = false;

      const alpha = inZone ? 1.0 : 0.28;

      if (i >= 49 && i <= 53 && val > 1.0) {
        fftCtx.fillStyle = `rgba(239, 68, 68, ${alpha})`; // Knock spike
      } else if (i >= 27 && i <= 31 && val > 0.8) {
        fftCtx.fillStyle = `rgba(245, 158, 11, ${alpha})`; // Bearing wear
      } else if (i <= 3) {
        fftCtx.fillStyle = `rgba(0, 240, 255, ${alpha * 0.95})`; // 1X/2X shaft
      } else {
        fftCtx.fillStyle = `rgba(56, 189, 248, ${alpha * 0.7})`; // Baseline
      }

      fftCtx.fillRect(x, y, Math.max(1, barW - 1), barH);
    }

    // 4. Peak Frequency Marker
    const peakX = peakIdx * barW + barW / 2;
    const peakFreq = Math.round(peakIdx * 62.5);
    const peakH = Math.min(h - 10, peakVal * (h / 2.5));
    const peakY = h - peakH;

    fftCtx.fillStyle = '#fff';
    fftCtx.beginPath();
    fftCtx.arc(peakX, peakY - 3, 2, 0, Math.PI * 2);
    fftCtx.fill();

    // Top-right Live Frequency Legend
    fftCtx.fillStyle = 'rgba(255, 255, 255, 0.75)';
    fftCtx.font = '8px "JetBrains Mono", monospace';
    fftCtx.textAlign = 'right';
    fftCtx.fillText(`PEAK: ${peakFreq}Hz • ${peakVal.toFixed(2)}mm/s`, w - 6, 12);
  }

  // Mouse hover on dashboard FFT canvas
  if (fftCanvas && fftTooltip) {
    fftCanvas.addEventListener('mousemove', (e) => {
      const rect = fftCanvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const binIdx = Math.max(0, Math.min(63, Math.floor((mouseX / rect.width) * 64)));
      const freq = Math.round(binIdx * 62.5);
      const amp = (telemetry.fftBins[binIdx] || 0).toFixed(2);
      
      let harmonicTag = '';
      if (binIdx <= 1) harmonicTag = ' (1X SHAFT)';
      else if (binIdx === 2) harmonicTag = ' (2X RECIP)';
      else if (binIdx >= 27 && binIdx <= 30) harmonicTag = ' (BEARING)';
      else if (binIdx >= 50 && binIdx <= 52) harmonicTag = ' (KNOCK)';

      fftTooltip.style.display = 'block';
      fftTooltip.style.left = `${mouseX}px`;
      fftTooltip.style.top = `${e.clientY - rect.top}px`;
      fftTooltip.textContent = `${freq} Hz: ${amp} mm/s${harmonicTag}`;
    });

    fftCanvas.addEventListener('mouseleave', () => {
      fftTooltip.style.display = 'none';
    });
  }

  // Modal FFT Canvas & Controller
  const modalFftCanvas = document.getElementById('modal-fft-canvas');
  let modalFftCtx = modalFftCanvas ? modalFftCanvas.getContext('2d') : null;
  const modalFftTooltip = document.getElementById('modal-fft-tooltip');

  function renderModalFftCanvas() {
    if (!modalFftCtx || !modalFftCanvas) return;
    const w = modalFftCanvas.clientWidth || 600;
    const h = modalFftCanvas.clientHeight || 160;
    if (modalFftCanvas.width !== w || modalFftCanvas.height !== h) {
      modalFftCanvas.width = w;
      modalFftCanvas.height = h;
    }
    modalFftCtx.clearRect(0, 0, w, h);

    // Get active channel data
    let bins = telemetry.fftBins;
    if (telemetry.vibeAxes) {
      if (activeVibeChannel === 'radial') bins = telemetry.vibeAxes.radial;
      else if (activeVibeChannel === 'vertical') bins = telemetry.vibeAxes.vertical;
      else if (activeVibeChannel === 'axial') bins = telemetry.vibeAxes.axial;
    }

    // Draw ISO 10816-3 Threshold Horizontal Lines
    const maxScale = 5.0; // mm/s
    const yZoneA = h - (1.8 * (h / maxScale));
    const yZoneB = h - (2.8 * (h / maxScale));
    const yZoneC = h - (4.5 * (h / maxScale));

    // Zone A threshold (1.8 mm/s - Green)
    modalFftCtx.lineWidth = 1;
    modalFftCtx.setLineDash([4, 4]);
    modalFftCtx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
    modalFftCtx.beginPath(); modalFftCtx.moveTo(0, yZoneA); modalFftCtx.lineTo(w, yZoneA); modalFftCtx.stroke();

    // Zone B/C alert threshold (2.8 mm/s - Amber)
    modalFftCtx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
    modalFftCtx.beginPath(); modalFftCtx.moveTo(0, yZoneB); modalFftCtx.lineTo(w, yZoneB); modalFftCtx.stroke();

    // Zone D trip threshold (4.5 mm/s - Crimson)
    modalFftCtx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    modalFftCtx.beginPath(); modalFftCtx.moveTo(0, yZoneC); modalFftCtx.lineTo(w, yZoneC); modalFftCtx.stroke();
    modalFftCtx.setLineDash([]);

    // Vertical Frequency Gridlines (every 500 Hz: 8 sections)
    modalFftCtx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    for (let f = 500; f < 4000; f += 500) {
      const x = (f / 4000) * w;
      modalFftCtx.beginPath(); modalFftCtx.moveTo(x, 0); modalFftCtx.lineTo(x, h); modalFftCtx.stroke();
    }

    // Spectrum Bars
    const barW = w / 64;
    let peakVal = 0, peakIdx = 0;

    for (let i = 0; i < 64; i++) {
      const val = bins[i] || 0;
      if (val > peakVal) { peakVal = val; peakIdx = i; }
      const barH = Math.max(2, Math.min(h - 4, val * (h / maxScale)));
      const x = i * barW;
      const y = h - barH;

      let inBand = true;
      if (activeVibeBand === 'shaft' && i > 3) inBand = false;
      if (activeVibeBand === 'bearing' && (i < 27 || i > 31)) inBand = false;
      if (activeVibeBand === 'knock' && (i < 49 || i > 53)) inBand = false;

      const alpha = inBand ? 1.0 : 0.25;

      if (i >= 49 && i <= 53 && val > 1.0) {
        modalFftCtx.fillStyle = `rgba(239, 68, 68, ${alpha})`;
      } else if (i >= 27 && i <= 31 && val > 0.8) {
        modalFftCtx.fillStyle = `rgba(245, 158, 11, ${alpha})`;
      } else if (i <= 3) {
        modalFftCtx.fillStyle = `rgba(0, 240, 255, ${alpha * 0.95})`;
      } else {
        modalFftCtx.fillStyle = `rgba(56, 189, 248, ${alpha * 0.75})`;
      }

      modalFftCtx.fillRect(x, y, Math.max(2, barW - 1), barH);
    }

    // Legend on canvas
    modalFftCtx.fillStyle = '#00f0ff';
    modalFftCtx.font = 'bold 9.5px "Orbitron", monospace';
    modalFftCtx.textAlign = 'right';
    const peakHz = Math.round(peakIdx * 62.5);
    modalFftCtx.fillText(`PEAK HARMONIC: ${peakHz} Hz (${peakVal.toFixed(2)} mm/s)`, w - 10, 16);

    modalFftCtx.fillStyle = '#94a3b8';
    modalFftCtx.font = '8px "JetBrains Mono", monospace';
    modalFftCtx.fillText(`ISO 10816 LIMITS: ZONE A <1.8 | ZONE B <2.8 | ZONE C <4.5 mm/s`, w - 10, 28);
  }

  // Mouse hover on modal FFT canvas
  if (modalFftCanvas && modalFftTooltip) {
    modalFftCanvas.addEventListener('mousemove', (e) => {
      const rect = modalFftCanvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const binIdx = Math.max(0, Math.min(63, Math.floor((mouseX / rect.width) * 64)));
      const freq = Math.round(binIdx * 62.5);
      const amp = (telemetry.fftBins[binIdx] || 0).toFixed(2);
      
      let harmonicTag = '';
      if (binIdx <= 1) harmonicTag = ' (1X SHAFT)';
      else if (binIdx === 2) harmonicTag = ' (2X RECIP)';
      else if (binIdx === 4) harmonicTag = ' (4X FIRING)';
      else if (binIdx >= 27 && binIdx <= 30) harmonicTag = ' (PRSU BEARING)';
      else if (binIdx >= 50 && binIdx <= 52) harmonicTag = ' (KNOCK DETONATION)';

      modalFftTooltip.style.display = 'block';
      modalFftTooltip.style.left = `${mouseX}px`;
      modalFftTooltip.style.top = `${e.clientY - rect.top}px`;
      modalFftTooltip.textContent = `${freq} Hz: ${amp} mm/s${harmonicTag}`;
    });

    modalFftCanvas.addEventListener('mouseleave', () => {
      modalFftTooltip.style.display = 'none';
    });
  }

  function renderVibeModal() {
    if (!vibeModal || !vibeModal.classList.contains('active')) return;

    const s = telemetry.state;
    const fft = telemetry.fftBins;
    const rms = s.vibrationRms || 1.82;

    safeSetText('vibe-modal-rms-val', `${rms.toFixed(2)} mm/s`);
    const isoBadge = document.getElementById('vibe-modal-iso-badge');
    if (isoBadge) {
      if (rms < 1.8) {
        isoBadge.textContent = 'ISO 10816: ZONE A (GOOD)';
        isoBadge.style.color = 'var(--emerald-safe)';
      } else if (rms < 2.8) {
        isoBadge.textContent = 'ISO 10816: ZONE B (ACCEPTABLE)';
        isoBadge.style.color = 'var(--cyan-hud)';
      } else if (rms < 4.5) {
        isoBadge.textContent = 'ISO 10816: ZONE C (ALERT)';
        isoBadge.style.color = 'var(--amber-warn)';
      } else {
        isoBadge.textContent = 'ISO 10816: ZONE D (DANGER/TRIP)';
        isoBadge.style.color = 'var(--crimson-crit)';
      }
    }

    const peakFreq = telemetry.dominantFreq || 70;
    const peakAmp = telemetry.dominantAmp || 0.95;
    safeSetText('vibe-modal-peak-val', `${peakFreq}.0 Hz (${peakFreq < 100 ? '1X' : peakFreq < 200 ? '2X' : peakFreq < 2000 ? 'GEAR' : 'KNOCK'})`);
    safeSetText('vibe-modal-peak-amp', `Peak Amplitude: ${peakAmp.toFixed(2)} mm/s`);

    // Bearing Wear
    const bearingAmp = fft[29] || 0.16;
    const bearingValEl = document.getElementById('vibe-modal-bearing-val');
    const bearingStatusEl = document.getElementById('vibe-modal-bearing-status');
    if (bearingValEl) {
      bearingValEl.textContent = `${bearingAmp.toFixed(2)} mm/s`;
      bearingValEl.style.color = bearingAmp > 0.8 ? 'var(--amber-warn)' : 'var(--emerald-safe)';
    }
    if (bearingStatusEl) {
      bearingStatusEl.textContent = bearingAmp > 0.8 ? '⚠️ PRSU Tooth Spalling / Wear Detected' : 'Hydrodynamic Film Nominal';
      bearingStatusEl.style.color = bearingAmp > 0.8 ? 'var(--amber-warn)' : 'var(--text-secondary)';
    }

    // Knock Detonation
    const knockAmp = fft[51] || 0.08;
    const knockValEl = document.getElementById('vibe-modal-knock-val');
    const knockStatusEl = document.getElementById('vibe-modal-knock-status');
    if (knockValEl) {
      knockValEl.textContent = `${knockAmp.toFixed(2)} mm/s`;
      knockValEl.style.color = knockAmp > 1.0 ? 'var(--crimson-crit)' : 'var(--emerald-safe)';
    }
    if (knockStatusEl) {
      knockStatusEl.textContent = knockAmp > 1.0 ? '🚨 Acoustic Detonation Shockwaves Active' : 'No Acoustic Shockwaves';
      knockStatusEl.style.color = knockAmp > 1.0 ? 'var(--crimson-crit)' : 'var(--text-secondary)';
    }

    // Harmonics table badges
    const b1x = document.getElementById('vibe-card-1x-badge');
    if (b1x) b1x.textContent = `${(fft[1] || 0.88).toFixed(2)} mm/s`;
    const b2x = document.getElementById('vibe-card-2x-badge');
    if (b2x) b2x.textContent = `${(fft[2] || 0.44).toFixed(2)} mm/s`;
    const b05x = document.getElementById('vibe-card-05x-badge');
    if (b05x) {
      const v05 = fft[0] || 0.12;
      b05x.textContent = `${v05.toFixed(2)} mm/s`;
      b05x.className = v05 > 0.6 ? 'badge badge-critical' : 'badge badge-nominal';
    }
    const bGear = document.getElementById('vibe-card-gear-badge');
    if (bGear) {
      bGear.textContent = `${bearingAmp.toFixed(2)} mm/s`;
      bGear.className = bearingAmp > 0.8 ? 'badge badge-warning' : 'badge badge-nominal';
    }
    const bKnock = document.getElementById('vibe-card-knock-badge');
    if (bKnock) {
      bKnock.textContent = `${knockAmp.toFixed(2)} mm/s`;
      bKnock.className = knockAmp > 1.0 ? 'badge badge-critical' : 'badge badge-nominal';
    }
    const bIso = document.getElementById('vibe-card-iso-rating');
    if (bIso) {
      bIso.textContent = rms < 1.8 ? 'ZONE A (GOOD)' : rms < 2.8 ? 'ZONE B (PERMISSIBLE)' : rms < 4.5 ? 'ZONE C (ALERT)' : 'ZONE D (TRIP)';
      bIso.className = rms < 1.8 ? 'badge badge-nominal' : rms < 2.8 ? 'badge' : rms < 4.5 ? 'badge badge-warning' : 'badge badge-critical';
    }

    renderModalFftCanvas();
  }

  // Helper: Render CAN-Bus Terminal
  const canWindow = document.getElementById('can-bus-terminal-content');
  function renderCanBusTerminal(frames) {
    if (!canWindow) return;
    if (frames.length === 0) return;
    canWindow.innerHTML = frames.slice(-7).map(f => `
      <div class="can-line">
        <span class="can-time">[${f.time}]</span>
        <span class="can-id">${f.id}</span>
        <span class="can-raw">${f.raw}</span>
        <span class="can-eng">&gt; ${f.eng}</span>
      </div>
    `).join('');
  }

  function safeSetText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  function safeSetWidth(id, pct) {
    const el = document.getElementById(id);
    if (el) el.style.width = `${Math.min(100, Math.max(0, pct))}%`;
  }

  function safeSetHeight(id, pct) {
    const el = document.getElementById(id);
    if (el) el.style.height = `${Math.min(100, Math.max(0, pct))}%`;
  }
});
