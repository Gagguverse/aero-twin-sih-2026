/* ==========================================================================
AERO-TWIN: HIGH-PERFORMANCE 3D CANVAS DIGITAL TWIN ENGINE RENDERER
Horizontally Opposed 4-Cylinder Turbocharged Aero Piston Engine
Operating on Otto 4-Stroke Cycle with Dynamic Heatmap & Component Diagnostics
SIH 2026 Problem Statement ID: 26054 (DRDO / iDEX MALE UAV Aero Piston Engine)
========================================================================== */

class AeroEngine3D {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');

    // Camera & View Parameters
    this.cam = {
      rotX: 0.40,       // Pitch
      rotY: -0.65,      // Yaw
      zoom: 1.35,       // Default aero engine viewing zoom (balanced framing)
      panX: 0,
      panY: 10,
      targetRotX: 0.40,
      targetRotY: -0.65,
      targetZoom: 1.35,
      targetPanX: 0,
      targetPanY: 10,
      isDragging: false,
      lastMouseX: 0,
      lastMouseY: 0
    };

    // Engine Visual Modes
    this.viewMode = 'solid'; // 'solid', 'cutaway', 'thermal', 'wireframe'
    this.showFlows = true;
    this.showLabels = true;
    this.showDefectCard = true;

    // Active Inspected Component Key
    this.activeComponentKey = 'cyl3';

    // 3D Engine Component Anchor Coordinates
    this.components = {
      cyl1: { id: 'cyl1', name: 'Cylinder #1', sub: 'Left Front Bank A', x: -80, y: 0, z: -45, radius: 36 },
      cyl2: { id: 'cyl2', name: 'Cylinder #2', sub: 'Right Front Bank B', x: 80, y: 0, z: -45, radius: 36 },
      cyl3: { id: 'cyl3', name: 'Cylinder #3', sub: 'Left Rear Bank A', x: -80, y: 0, z: 45, radius: 36 },
      cyl4: { id: 'cyl4', name: 'Cylinder #4', sub: 'Right Rear Bank B', x: 80, y: 0, z: 45, radius: 36 },
      turbo: { id: 'turbo', name: 'Turbocharger', sub: 'Compressor & Wastegate', x: 0, y: -72, z: 65, radius: 42 },
      crankshaft: { id: 'crankshaft', name: 'Crankshaft', sub: 'Journal Bearings', x: 0, y: 0, z: 0, radius: 42 },
      oil_system: { id: 'oil_system', name: 'Oil Pump & Sump', sub: 'Lube System & Filter', x: 0, y: 55, z: -10, radius: 38 },
      fuel_system: { id: 'fuel_system', name: 'Fuel Rail', sub: 'Injectors 1-4', x: 0, y: -42, z: 0, radius: 35 },
      gearbox: { id: 'gearbox', name: 'PRSU Gearbox', sub: 'Prop Reduction Unit', x: 0, y: 0, z: -105, radius: 30 },
      uav_airframe: { id: 'uav_airframe', name: 'DRDO Tapas MALE UAV', sub: 'Airframe & Nacelle', x: 0, y: 0, z: 0, radius: 120 }
    };

    // Kinematic & Thermodynamic State
    this.crankAngle = 0; // Radians
    this.propAngle = 0;  // Continuous Propeller Radians (Independent Accumulator)
    this.rpm = 4200;
    this.throttle = 0.75;
    this.turboSpoolAngle = 0;
    this.particles = [];
    this.leakParticles = [];

    // Component Telemetry Binding
    this.telemetry = {
      cht: [168, 165, 172, 166], // Cylinder 1 to 4 Head Temp °C
      egt: [780, 775, 792, 778], // Exhaust Gas Temp °C
      map: 34.5,                 // Manifold Absolute Pressure (inHg)
      oilPress: 52.4,            // PSI
      oilTemp: 88.5,             // °C
      fuelFlow: 24.8,            // L/hr
      fuelRemainingKg: 184.2,    // KG
      fuelPressure: 43.5,        // PSI
      fuelWallOpen: true,        // Firewall Fuel Cutoff Valve
      afr: 14.7,                 // Air-Fuel Ratio
      vibrationRms: 1.8,         // mm/s RMS
      wastegateLeak: 0,
      bearingDamage: 0
    };

    this.mouseDownPos = { x: 0, y: 0 };

    this.initCanvasSize();
    this.bindEvents();
    this.initParticles();
    this.startLoop();
  }

  initCanvasSize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const rect = parent.getBoundingClientRect();
    this.dpr = window.devicePixelRatio || 1;

    let targetW = 800;
    let targetH = 520;

    // Prevent resetting to fallback if parent is currently hidden (e.g. while on another tab)
    if (rect.width === 0 && parent.clientWidth === 0) {
      if (!this.width) {
        targetW = 800;
        targetH = 520;
      } else {
        return; // Retain existing valid dimensions while in hidden tab
      }
    } else {
      targetW = Math.round(rect.width > 0 ? rect.width : (parent.clientWidth || 800));
      targetH = Math.round(rect.height > 0 ? rect.height : (parent.clientHeight || 520));
    }

    if (this.width === targetW && this.height === targetH && this.canvas.width > 0) {
      return; // Already correct dimensions! Prevent resetting canvas state & flickering!
    }

    this.width = targetW;
    this.height = targetH;
    this.canvas.width = Math.round(this.width * this.dpr);
    this.canvas.height = Math.round(this.height * this.dpr);
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ctx.scale(this.dpr, this.dpr);
  }

  bindEvents() {
    window.addEventListener('resize', () => this.initCanvasSize());

    this.canvas.addEventListener('mousedown', (e) => {
      this.cam.isDragging = true;
      this.cam.lastMouseX = e.clientX;
      this.cam.lastMouseY = e.clientY;
      this.mouseDownPos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.cam.isDragging) return;
      const dx = e.clientX - this.cam.lastMouseX;
      const dy = e.clientY - this.cam.lastMouseY;
      this.cam.targetRotY -= dx * 0.008;
      this.cam.targetRotX -= dy * 0.008;
      // Clamp pitch to prevent gimbal flip
      this.cam.targetRotX = Math.max(-1.2, Math.min(1.2, this.cam.targetRotX));
      this.cam.lastMouseX = e.clientX;
      this.cam.lastMouseY = e.clientY;
    });

    window.addEventListener('mouseup', (e) => {
      if (this.cam.isDragging) {
        this.cam.isDragging = false;
        // If mouse barely moved, treat as component click/pick
        const distMoved = Math.hypot(e.clientX - this.mouseDownPos.x, e.clientY - this.mouseDownPos.y);
        if (distMoved < 6) {
          this.handleCanvasClick(e);
        }
      }
    });

    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomDelta = -e.deltaY * 0.001;
      this.cam.targetZoom = Math.max(0.55, Math.min(2.4, this.cam.targetZoom + zoomDelta));
    }, { passive: false });

    // Touch support for tablets & laptops
    let touchStartX = 0, touchStartY = 0;
    this.canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
    });

    this.canvas.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1) {
        const dx = e.touches[0].clientX - touchStartX;
        const dy = e.touches[0].clientY - touchStartY;
        this.cam.targetRotY -= dx * 0.01;
        this.cam.targetRotX -= dy * 0.01;
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
    });
  }

  handleCanvasClick(e) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.width / (rect.width || 1);
    const scaleY = this.height / (rect.height || 1);
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    let closestKey = null;
    let minDistance = 50; // Picking radius in pixels

    for (const [key, comp] of Object.entries(this.components)) {
      const pt = this.project(comp.x, comp.y, comp.z);
      const d = Math.hypot(clickX - pt.x, clickY - pt.y);
      if (d < minDistance) {
        minDistance = d;
        closestKey = key;
      }
    }

    if (closestKey) {
      this.inspectComponent(closestKey);
    }
  }

  setViewMode(mode) {
    this.viewMode = mode;
  }

  setCameraPreset(preset) {
    if (preset === 'iso') {
      this.cam.targetRotX = 0.40;
      this.cam.targetRotY = -0.65;
      this.cam.targetZoom = 1.35;
      this.cam.targetPanX = 0;
      this.cam.targetPanY = 10;
    } else if (preset === 'top') {
      this.cam.targetRotX = 1.45;
      this.cam.targetRotY = 0;
      this.cam.targetZoom = 1.30;
      this.cam.targetPanX = 0;
      this.cam.targetPanY = 15;
    } else if (preset === 'cylinders') {
      this.cam.targetRotX = 0.15;
      this.cam.targetRotY = -1.55;
      this.cam.targetZoom = 1.45;
      this.cam.targetPanX = 0;
      this.cam.targetPanY = 5;
    } else if (preset === 'turbo') {
      this.cam.targetRotX = 0.55;
      this.cam.targetRotY = 1.25;
      this.cam.targetZoom = 1.50;
      this.cam.targetPanX = -10;
      this.cam.targetPanY = -25;
    }
  }

  focusOn(compKey) {
    const angles = {
      cyl1: { rotX: 0.30, rotY: -1.25, zoom: 1.65 },
      cyl2: { rotX: 0.30, rotY: -1.95, zoom: 1.65 },
      cyl3: { rotX: 0.35, rotY: -0.75, zoom: 1.65 },
      cyl4: { rotX: 0.35, rotY: -2.40, zoom: 1.65 },
      turbo: { rotX: 0.60, rotY: 1.25, zoom: 1.65 },
      crankshaft: { rotX: 1.15, rotY: -0.50, zoom: 1.50 },
      oil_system: { rotX: -0.30, rotY: -0.65, zoom: 1.55 },
      fuel_system: { rotX: 0.80, rotY: -0.65, zoom: 1.60 },
      gearbox: { rotX: 0.25, rotY: -1.30, zoom: 1.55 },
      uav_airframe: { rotX: 0.35, rotY: -0.65, zoom: 0.85 }
    };
    const cfg = angles[compKey] || { rotX: 0.40, rotY: -0.65, zoom: 1.35 };
    this.cam.targetRotX = cfg.rotX;
    this.cam.targetRotY = cfg.rotY;
    this.cam.targetZoom = cfg.zoom;

    const comp = this.components[compKey];
    if (comp) {
      // Compute target pan so the component is perfectly centered in viewport
      const cosY = Math.cos(cfg.rotY), sinY = Math.sin(cfg.rotY);
      const x1 = comp.x * cosY + comp.z * sinY;
      const z1 = -comp.x * sinY + comp.z * cosY;
      const cosX = Math.cos(cfg.rotX), sinX = Math.sin(cfg.rotX);
      const y2 = comp.y * cosX - z1 * sinX;
      const z2 = comp.y * sinX + z1 * cosX;
      const scale = (450 / Math.max(z2 + 500, 100)) * cfg.zoom;
      this.cam.targetPanX = -x1 * scale;
      this.cam.targetPanY = -y2 * scale;
    } else {
      this.cam.targetPanX = 0;
      this.cam.targetPanY = 10;
    }
  }

  inspectComponent(compKey) {
    if (!this.components[compKey]) return;
    this.activeComponentKey = compKey;
    this.focusOn(compKey);
    this.updateComponentInspectorDOM(compKey);

    // Deactivate toolbar preset buttons to reflect focused inspection mode
    const presetBtns = document.querySelectorAll('.cam-btn[data-preset]');
    presetBtns.forEach(b => b.classList.remove('active'));
  }

  updateTelemetry(telem) {
    this.telemetry = { ...this.telemetry, ...telem };
    this.rpm = telem.rpm !== undefined ? telem.rpm : this.rpm;
    this.throttle = telem.throttle !== undefined ? telem.throttle : this.throttle;
    this.updateComponentInspectorDOM(this.activeComponentKey);
  }

  initParticles() {
    this.particles = [];
    for (let i = 0; i < 45; i++) {
      this.particles.push({
        x: (Math.random() - 0.5) * 60,
        y: (Math.random() - 0.5) * 60,
        z: (Math.random() - 0.5) * 60,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        vz: (Math.random() - 0.5) * 0.5,
        life: Math.random()
      });
    }

    this.leakParticles = [];
    for (let i = 0; i < 20; i++) {
      this.leakParticles.push({
        x: 22, y: -90, z: 75,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -Math.random() * 2 - 1,
        vz: (Math.random() - 0.5) * 1.5,
        life: Math.random()
      });
    }
  }

  // 3D Projection Matrix Transformation
  project(x, y, z) {
    // Rotation Y (Yaw)
    const cosY = Math.cos(this.cam.rotY);
    const sinY = Math.sin(this.cam.rotY);
    const x1 = x * cosY + z * sinY;
    const z1 = -x * sinY + z * cosY;

    // Rotation X (Pitch)
    const cosX = Math.cos(this.cam.rotX);
    const sinX = Math.sin(this.cam.rotX);
    const y2 = y * cosX - z1 * sinX;
    const z2 = y * sinX + z1 * cosX;

    // Perspective Projection
    const fov = 450;
    const depth = z2 + 500;
    const scale = (fov / Math.max(depth, 100)) * this.cam.zoom;

    const screenX = this.width / 2 + x1 * scale + this.cam.panX;
    const screenY = this.height / 2 + y2 * scale + this.cam.panY;

    return { x: screenX, y: screenY, scale, z: z2 };
  }

  startLoop() {
    const loop = () => {
      // Dynamic auto-detection: when returning from another tab or when viewport size changes
      const parent = this.canvas.parentElement;
      if (parent && parent.clientWidth > 0) {
        if (Math.abs(parent.clientWidth - this.width) > 6 || Math.abs(parent.clientHeight - this.height) > 6) {
          this.initCanvasSize();
        }
      }

      try {
        this.updatePhysics();
        this.render();
      } catch (err) {
        console.warn('AeroEngine3D render error:', err);
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  updatePhysics() {
    // Smooth camera interpolation
    this.cam.rotX += (this.cam.targetRotX - this.cam.rotX) * 0.1;
    this.cam.rotY += (this.cam.targetRotY - this.cam.rotY) * 0.1;
    this.cam.zoom += (this.cam.targetZoom - this.cam.zoom) * 0.1;
    this.cam.panX += (this.cam.targetPanX - this.cam.panX) * 0.1;
    this.cam.panY += (this.cam.targetPanY - this.cam.panY) * 0.1;

    // Rotate crankshaft based on live RPM (smooth, continuous cadence)
    const crankSpeed = (this.rpm / 60) * 2 * Math.PI * 0.016 * 0.018;
    this.crankAngle = (this.crankAngle + crankSpeed) % (Math.PI * 4); // 720 deg for 4-stroke cycle

    // Continuous unbroken propeller rotation (wraps at exact 360° with ZERO visual jump)
    this.propAngle = (this.propAngle + (crankSpeed / 2.43)) % (Math.PI * 2);

    // Turbocharger spins continuously
    this.turboSpoolAngle = (this.turboSpoolAngle + crankSpeed * 3.5) % (Math.PI * 2);

    // Update combustion particles & thermal smoke only if genuine thermal defect or thermal view mode
    const isCyl3Hot = this.telemetry.cht[2] > 205;
    this.particles.forEach(p => {
      p.life += 0.03;
      if (p.life > 1) {
        p.life = 0;
        p.x = isCyl3Hot ? -75 + (Math.random() - 0.5) * 22 : (Math.random() - 0.5) * 40;
        p.y = isCyl3Hot ? -25 + (Math.random() - 0.5) * 15 : (Math.random() - 0.5) * 30;
        p.z = isCyl3Hot ? 45 + (Math.random() - 0.5) * 22 : (Math.random() - 0.5) * 40;
      }
      p.y -= 0.8;
      p.x += (Math.random() - 0.5) * 0.6;
    });

    // Update Wastegate Leak Particles ONLY if actual turbo wastegate fault is active
    const isWgLeaking = Boolean(
      (this.telemetry.faults && this.telemetry.faults.turboWastegateLeak > 0.3) ||
      (this.telemetry.wastegatePos && this.telemetry.wastegatePos > 0.75)
    );
    if (isWgLeaking) {
      this.leakParticles.forEach(p => {
        p.life += 0.04;
        if (p.life > 1) {
          p.life = 0;
          p.x = 22; p.y = -90; p.z = 75;
          p.vx = (Math.random() - 0.5) * 1.5;
          p.vy = -Math.random() * 2.5 - 0.8;
          p.vz = (Math.random() - 0.5) * 1.5;
        }
        p.x += p.vx; p.y += p.vy; p.z += p.vz;
      });
    }
  }

  render() {
    this.ctx.clearRect(0, 0, this.width, this.height);

    // 1. Realistic Soft Ground Ambient Shadow
    this.renderGroundShadow();

    // 2. Tactical Ground Cyber Grid
    this.renderGroundGrid();

    // 3. Dynamic Depth Sorting for all Engine Subsystems (Painter's Algorithm)
    // Farthest in camera Z rendered first, closest rendered last
    const assemblies = [
      {
        name: 'crankcase',
        z: this.project(0, 0, 0).z,
        render: () => this.renderCrankcase()
      },
      {
        name: 'oil_system',
        z: this.project(0, 52, -10).z,
        render: () => this.renderOilSystem()
      },
      {
        name: 'crankshaft',
        z: this.project(0, 0, 0).z - 1, // Render inside block
        render: () => this.renderCrankshaft()
      },
      {
        name: 'propeller',
        z: this.project(0, 0, -125).z,
        render: () => this.renderPropeller()
      },
      {
        name: 'cyl1',
        z: this.project(-80, 0, -45).z,
        render: () => this.renderCylinder(1, -1, -45, this.telemetry.cht[0], 0)
      },
      {
        name: 'cyl2',
        z: this.project(80, 0, -45).z,
        render: () => this.renderCylinder(2, 1, -45, this.telemetry.cht[1], 2)
      },
      {
        name: 'cyl3',
        z: this.project(-80, 0, 45).z,
        render: () => this.renderCylinder(3, -1, 45, this.telemetry.cht[2], 1)
      },
      {
        name: 'cyl4',
        z: this.project(80, 0, 45).z,
        render: () => this.renderCylinder(4, 1, 45, this.telemetry.cht[3], 3)
      },
      {
        name: 'intake_exhaust',
        z: this.project(0, -20, 20).z,
        render: () => this.renderIntakeAndExhaust()
      },
      {
        name: 'turbo',
        z: this.project(0, -72, 65).z,
        render: () => this.renderTurbocharger()
      },
      {
        name: 'fuel_system',
        z: this.project(0, -42, 0).z,
        render: () => { if (this.showFlows) this.renderFuelSystemAndInjectors(); }
      }
    ];

    // Sort descending by camera Z (farthest first -> nearest last)
    assemblies.sort((a, b) => b.z - a.z);

    // Draw all sorted assemblies
    assemblies.forEach(a => a.render());

    // 5. Dynamic Defect VFX (Thermal Runaway Smoke, Wastegate Gas Leak, Bearing Friction Sparks)
    if (this.telemetry.cht[2] > 208 || this.viewMode === 'thermal') {
      this.renderThermalOverheatSparks();
    }
    const isWgPlumeActive = Boolean(
      (this.telemetry.faults && this.telemetry.faults.turboWastegateLeak > 0.3) ||
      (this.telemetry.wastegatePos && this.telemetry.wastegatePos > 0.75)
    );
    if (isWgPlumeActive) {
      this.renderWastegateLeakPlume();
    }
    if (this.telemetry.oilPress < 30 || (this.telemetry.vibrationRms && this.telemetry.vibrationRms > 3.0)) {
      this.renderBearingWearSparks();
    }

    // 6. Tactical HUD Targeting Reticle on Active Inspected Subsystem
    this.renderActiveFocusReticle();

    // 7. Floating 3D Component Labels with Defect Callouts
    if (this.showLabels) {
      this.render3DComponentLabels();
    }

    // 8. HUD Orientation Gizmo
    this.renderOrientationGizmo();

    // 9. Real-Time Otto 4-Stroke Kinematics & Subsystem HUD Sync
    this.renderOttoCycleIndicator();
  }

  renderGroundShadow() {
    const ctx = this.ctx;
    ctx.save();
    const gPt = this.project(0, 68, 0);
    const rx = Math.max(10, 160 * gPt.scale);
    const ry = Math.max(5, 55 * gPt.scale);

    const grad = ctx.createRadialGradient(gPt.x, gPt.y, 2, gPt.x, gPt.y, rx);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    grad.addColorStop(0.45, 'rgba(0, 15, 30, 0.35)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(gPt.x, gPt.y, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  renderGroundGrid() {
    this.ctx.save();
    this.ctx.lineWidth = 1;

    const gridSize = 180;
    const step = 45;
    for (let x = -gridSize; x <= gridSize; x += step) {
      const pStart = this.project(x, 68, -gridSize);
      const pEnd = this.project(x, 68, gridSize);
      const grad = this.ctx.createLinearGradient(pStart.x, pStart.y, pEnd.x, pEnd.y);
      grad.addColorStop(0, 'rgba(0, 240, 255, 0.01)');
      grad.addColorStop(0.5, 'rgba(0, 240, 255, 0.07)');
      grad.addColorStop(1, 'rgba(0, 240, 255, 0.01)');
      this.ctx.strokeStyle = grad;
      this.ctx.beginPath();
      this.ctx.moveTo(pStart.x, pStart.y);
      this.ctx.lineTo(pEnd.x, pEnd.y);
      this.ctx.stroke();
    }
    for (let z = -gridSize; z <= gridSize; z += step) {
      const pStart = this.project(-gridSize, 68, z);
      const pEnd = this.project(gridSize, 68, z);
      const grad = this.ctx.createLinearGradient(pStart.x, pStart.y, pEnd.x, pEnd.y);
      grad.addColorStop(0, 'rgba(0, 240, 255, 0.01)');
      grad.addColorStop(0.5, 'rgba(0, 240, 255, 0.07)');
      grad.addColorStop(1, 'rgba(0, 240, 255, 0.01)');
      this.ctx.strokeStyle = grad;
      this.ctx.beginPath();
      this.ctx.moveTo(pStart.x, pStart.y);
      this.ctx.lineTo(pEnd.x, pEnd.y);
      this.ctx.stroke();
    }
    this.ctx.restore();
  }

  renderCrankcase() {
    const ctx = this.ctx;
    ctx.save();

    // Main Engine Crankcase (Boxer Engine Block)
    const w = 45, h = 42, d = 85;
    const corners = [
      [-w, -h, -d], [w, -h, -d], [w, h, -d], [-w, h, -d], // Front: 0, 1, 2, 3
      [-w, -h, d], [w, -h, d], [w, h, d], [-w, h, d]   // Rear:  4, 5, 6, 7
    ];
    const proj = corners.map(c => this.project(c[0], c[1], c[2]));

    if (this.viewMode === 'wireframe') {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
      ctx.lineWidth = 1.2;
      this.drawBoxEdges(proj);
    } else {
      const alpha = this.viewMode === 'cutaway' ? 0.22 : 0.85;

      // 6 faces with sleek aerospace titanium/obsidian shading & depth sorting
      const faces = [
        // Front face (z = -d)
        { indices: [0, 1, 2, 3], z: (proj[0].z + proj[1].z + proj[2].z + proj[3].z) / 4, color: `rgba(12, 22, 38, ${alpha})` },
        // Rear face (z = +d)
        { indices: [5, 4, 7, 6], z: (proj[5].z + proj[4].z + proj[7].z + proj[6].z) / 4, color: `rgba(10, 18, 32, ${alpha})` },
        // Top face (y = -h)
        { indices: [4, 5, 1, 0], z: (proj[4].z + proj[5].z + proj[1].z + proj[0].z) / 4, color: `rgba(18, 32, 54, ${alpha})` },
        // Bottom face (y = +h)
        { indices: [3, 2, 6, 7], z: (proj[3].z + proj[2].z + proj[6].z + proj[7].z) / 4, color: `rgba(8, 14, 26, ${alpha})` },
        // Left face (x = -w)
        { indices: [4, 0, 3, 7], z: (proj[4].z + proj[0].z + proj[3].z + proj[7].z) / 4, color: `rgba(14, 24, 42, ${alpha})` },
        // Right face (x = +w)
        { indices: [1, 5, 6, 2], z: (proj[1].z + proj[5].z + proj[6].z + proj[2].z) / 4, color: `rgba(15, 26, 44, ${alpha})` }
      ];

      // Sort faces farthest to nearest (Painter's Algorithm)
      faces.sort((a, b) => b.z - a.z);

      ctx.strokeStyle = this.viewMode === 'cutaway' ? 'rgba(56, 189, 248, 0.22)' : 'rgba(56, 189, 248, 0.42)';
      ctx.lineWidth = 1.2;

      faces.forEach(face => {
        const [i0, i1, i2, i3] = face.indices;
        this.drawQuad(proj[i0], proj[i1], proj[i2], proj[i3], face.color);
      });

      // Structural Stiffening Ribs on Top Face
      const ribZ = [-45, 0, 45];
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.22)';
      ctx.lineWidth = 1;
      ribZ.forEach(rz => {
        const r1 = this.project(-w + 4, -h, rz);
        const r2 = this.project(w - 4, -h, rz);
        ctx.beginPath();
        ctx.moveTo(r1.x, r1.y);
        ctx.lineTo(r2.x, r2.y);
        ctx.stroke();
      });

      // Front Mounting Flange Bolt Studs
      const studOffsets = [
        [-w + 7, -h + 7, -d], [w - 7, -h + 7, -d],
        [-w + 7, h - 7, -d], [w - 7, h - 7, -d]
      ];
      studOffsets.forEach(st => {
        const pt = this.project(st[0], st[1], st[2]);
        ctx.fillStyle = '#64748b';
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, Math.max(1, 2.8 * pt.scale), 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      });
    }

    ctx.restore();
  }

  renderOilSystem() {
    const ctx = this.ctx;
    ctx.save();

    const isOilLow = this.telemetry.oilPress < 40;
    const isOilCrit = this.telemetry.oilPress < 25;

    // 1. Oil Sump Pan at bottom of crankcase
    const sumpCorners = [
      [-36, 42, -60], [36, 42, -60], [36, 62, -60], [-36, 62, -60],
      [-36, 42, 60], [36, 42, 60], [36, 62, 60], [-36, 62, 60]
    ];
    const sumpProj = sumpCorners.map(c => this.project(c[0], c[1], c[2]));
    const oilHeatColor = this.telemetry.oilTemp > 105 ? '#ef4444' : (this.telemetry.oilTemp > 95 ? '#f59e0b' : '#10b981');
    const alpha = this.viewMode === 'cutaway' ? 0.32 : 0.88;

    if (this.viewMode === 'wireframe') {
      ctx.strokeStyle = isOilCrit ? '#ef4444' : '#00f0ff';
      ctx.lineWidth = 1.2;
      this.drawBoxEdges(sumpProj);
    } else {
      const panColor = this.viewMode === 'thermal'
        ? oilHeatColor
        : (isOilCrit ? 'rgba(239, 68, 68, 0.65)' : (isOilLow ? 'rgba(245, 158, 11, 0.55)' : `rgba(18, 28, 48, ${alpha})`));

      const panFaces = [
        { indices: [0, 1, 2, 3], z: (sumpProj[0].z + sumpProj[1].z + sumpProj[2].z + sumpProj[3].z) / 4 },
        { indices: [5, 4, 7, 6], z: (sumpProj[5].z + sumpProj[4].z + sumpProj[7].z + sumpProj[6].z) / 4 },
        { indices: [3, 2, 6, 7], z: (sumpProj[3].z + sumpProj[2].z + sumpProj[6].z + sumpProj[7].z) / 4 },
        { indices: [4, 0, 3, 7], z: (sumpProj[4].z + sumpProj[0].z + sumpProj[3].z + sumpProj[7].z) / 4 },
        { indices: [1, 5, 6, 2], z: (sumpProj[1].z + sumpProj[5].z + sumpProj[6].z + sumpProj[2].z) / 4 }
      ];
      panFaces.sort((a, b) => b.z - a.z);

      ctx.strokeStyle = isOilCrit ? '#ef4444' : (isOilLow ? '#f59e0b' : 'rgba(16, 185, 129, 0.5)');
      ctx.lineWidth = isOilLow ? 1.8 : 1;

      panFaces.forEach(f => {
        this.drawQuad(sumpProj[f.indices[0]], sumpProj[f.indices[1]], sumpProj[f.indices[2]], sumpProj[f.indices[3]], panColor);
      });
    }

    // 2. Oil Pump Housing at Front-Lower
    const pumpCenter = this.project(-18, 52, -65);
    ctx.fillStyle = this.viewMode === 'wireframe'
      ? 'rgba(0, 240, 255, 0.05)'
      : (this.viewMode === 'thermal' ? oilHeatColor : (isOilCrit ? 'rgba(239, 68, 68, 0.8)' : '#334155'));
    ctx.strokeStyle = isOilLow ? '#ef4444' : '#00f0ff';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(pumpCenter.x, pumpCenter.y, Math.max(2, 11 * pumpCenter.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 3. Spin-on Cylindrical Oil Filter
    const filterCenter = this.project(22, 52, -65);
    ctx.fillStyle = this.viewMode === 'wireframe' ? 'rgba(0, 240, 255, 0.05)' : '#0284c7';
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(filterCenter.x, filterCenter.y, Math.max(2, 9 * filterCenter.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  renderCrankshaft() {
    const ctx = this.ctx;
    ctx.save();

    // Center Crankshaft Axis (Machined Polished Steel Core)
    const frontShaft = this.project(0, 0, -115);
    const rearShaft = this.project(0, 0, 95);

    const isBearingDamaged = (this.telemetry.faults && this.telemetry.faults.bearingDamage > 0.3) ||
                             (this.telemetry.vibrationRms > 3.2 || this.telemetry.oilPress < 30);

    // Outer Journal Line
    ctx.strokeStyle = isBearingDamaged ? '#ef4444' : '#38bdf8';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(frontShaft.x, frontShaft.y);
    ctx.lineTo(rearShaft.x, rearShaft.y);
    ctx.stroke();

    // Inner Polished Specular Highlight
    ctx.strokeStyle = isBearingDamaged ? '#fca5a5' : '#e2e8f0';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(frontShaft.x, frontShaft.y);
    ctx.lineTo(rearShaft.x, rearShaft.y);
    ctx.stroke();

    // Main Hydrodynamic Journal Bearing Collars (3 positions: z = -45, 0, 45)
    // Precision machined split-shell aerospace bearings (clean polished steel & cyan oil film)
    const bearingZ = [-45, 0, 45];
    bearingZ.forEach(z => {
      const bPt = this.project(0, 0, z);
      const bScale = Math.max(0.2, bPt.scale);

      // Outer Machined Shell Ring
      ctx.fillStyle = isBearingDamaged ? 'rgba(239, 68, 68, 0.4)' : '#1e293b';
      ctx.strokeStyle = isBearingDamaged ? '#ef4444' : '#64748b';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(bPt.x, bPt.y, 8 * bScale, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Precision Hydrodynamic Oil Film Clearance Ring
      ctx.strokeStyle = isBearingDamaged ? '#fca5a5' : '#38bdf8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(bPt.x, bPt.y, 5 * bScale, 0, Math.PI * 2);
      ctx.stroke();

      // Center Shaft Journal
      ctx.fillStyle = isBearingDamaged ? '#fca5a5' : '#cbd5e1';
      ctx.beginPath();
      ctx.arc(bPt.x, bPt.y, 2.5 * bScale, 0, Math.PI * 2);
      ctx.fill();
    });

    // PRSU (Propeller Reduction Gearbox) at Front
    const gearboxCorners = [
      [-24, -24, -115], [24, -24, -115], [24, 24, -115], [-24, 24, -115],
      [-24, -24, -90], [24, -24, -90], [24, 24, -90], [-24, 24, -90]
    ];
    const gbProj = gearboxCorners.map(c => this.project(c[0], c[1], c[2]));
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
    this.drawBoxEdges(gbProj);

    // Propeller Mounting Flange & Hub
    const propHub = this.project(0, 0, -125);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(propHub.x, propHub.y, 16 * propHub.scale, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  renderPropeller() {
    const ctx = this.ctx;
    ctx.save();

    const hubCenter = this.project(0, 0, -125);
    const spinnerTip = this.project(0, 0, -165);
    const propAngle = this.propAngle;

    // 1. High-Speed Rotational Blur Disc (Dynamic aerodynamic propulsion glow)
    if (this.rpm > 400) {
      const blurRadius = 94 * hubCenter.scale;
      const rotAlpha = Math.min(0.25, (this.rpm / 5000) * 0.22);
      
      const propBlurGrad = ctx.createRadialGradient(hubCenter.x, hubCenter.y, 18 * hubCenter.scale, hubCenter.x, hubCenter.y, blurRadius);
      propBlurGrad.addColorStop(0, `rgba(56, 189, 248, ${rotAlpha * 0.2})`);
      propBlurGrad.addColorStop(0.75, `rgba(56, 189, 248, ${rotAlpha})`);
      propBlurGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');

      ctx.fillStyle = propBlurGrad;
      ctx.beginPath();
      ctx.arc(hubCenter.x, hubCenter.y, blurRadius, 0, Math.PI * 2);
      ctx.fill();

      // Thin tip circumference track
      ctx.strokeStyle = `rgba(56, 189, 248, ${rotAlpha * 1.5})`;
      ctx.lineWidth = Math.max(1, 1.5 * hubCenter.scale);
      ctx.beginPath();
      ctx.arc(hubCenter.x, hubCenter.y, blurRadius * 0.98, 0, Math.PI * 2);
      ctx.stroke();
    }

    // 2. Twin Scimitar Carbon-Fiber Propeller Blades
    const bladeLength = 92;
    for (let b = 0; b < 2; b++) {
      const bAngle = propAngle + (b * Math.PI);
      const cosA = Math.cos(bAngle);
      const sinA = Math.sin(bAngle);

      const tip3D = { x: cosA * bladeLength, y: sinA * bladeLength, z: -128 };
      const root3D = { x: cosA * 16, y: sinA * 16, z: -125 };
      const midLead3D = {
        x: cosA * 55 - sinA * 12,
        y: sinA * 55 + cosA * 12,
        z: -126
      };
      const midTrail3D = {
        x: cosA * 50 + sinA * 10,
        y: sinA * 50 - cosA * 10,
        z: -126
      };

      const tipP = this.project(tip3D.x, tip3D.y, tip3D.z);
      const rootP = this.project(root3D.x, root3D.y, root3D.z);
      const leadP = this.project(midLead3D.x, midLead3D.y, midLead3D.z);
      const trailP = this.project(midTrail3D.x, midTrail3D.y, midTrail3D.z);

      // Main Blade Body (High-modulus carbon fiber composite)
      ctx.fillStyle = this.viewMode === 'wireframe' ? 'rgba(56, 189, 248, 0.08)' : 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(rootP.x, rootP.y);
      ctx.quadraticCurveTo(leadP.x, leadP.y, tipP.x, tipP.y);
      ctx.quadraticCurveTo(trailP.x, trailP.y, rootP.x, rootP.y);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Silver Leading Edge Titanium Erosion Shield
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = Math.max(1, 1.5 * tipP.scale);
      ctx.beginPath();
      ctx.moveTo(rootP.x, rootP.y);
      ctx.quadraticCurveTo(leadP.x, leadP.y, tipP.x, tipP.y);
      ctx.stroke();

      // High-Visibility Defense Safety Yellow Blade Tip (Outer 18%)
      const tipBaseX = root3D.x + (tip3D.x - root3D.x) * 0.82;
      const tipBaseY = root3D.y + (tip3D.y - root3D.y) * 0.82;
      const tipBaseP = this.project(tipBaseX, tipBaseY, -127);
      ctx.fillStyle = '#eab308'; // Aviation Warning Yellow
      ctx.beginPath();
      ctx.moveTo(tipBaseP.x, tipBaseP.y);
      ctx.lineTo(tipP.x, tipP.y);
      ctx.lineTo(tipBaseP.x + (cosA * 3), tipBaseP.y + (sinA * 3));
      ctx.closePath();
      ctx.fill();
    }

    // 3. Polished Aerodynamic Spinner Nose Cone (Parabolic Profile)
    const baseR = 17 * hubCenter.scale;
    const coneGrad = ctx.createLinearGradient(hubCenter.x - baseR, hubCenter.y, spinnerTip.x, spinnerTip.y);
    coneGrad.addColorStop(0, '#1e293b');
    coneGrad.addColorStop(0.4, '#475569');
    coneGrad.addColorStop(0.7, '#94a3b8');
    coneGrad.addColorStop(1, '#cbd5e1');

    ctx.fillStyle = this.viewMode === 'wireframe' ? 'rgba(56, 189, 248, 0.1)' : coneGrad;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(hubCenter.x - baseR, hubCenter.y);
    ctx.quadraticCurveTo((hubCenter.x - baseR + spinnerTip.x) / 2, spinnerTip.y - 2, spinnerTip.x, spinnerTip.y);
    ctx.quadraticCurveTo((hubCenter.x + baseR + spinnerTip.x) / 2, spinnerTip.y + 2, hubCenter.x + baseR, hubCenter.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Center Hub Retaining Collar
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(hubCenter.x, hubCenter.y, Math.max(2, 6 * hubCenter.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  renderCylinder(cylNum, side, zPos, chtTemp, phaseOffset) {
    const ctx = this.ctx;
    ctx.save();

    const bankSign = side;
    const cylLength = 80;
    const boreRadius = 26;
    const startX = bankSign * 45;
    const endX = bankSign * (45 + cylLength);

    const isOverheating = chtTemp > 210;
    let thermalColor = this.getThermalColor(chtTemp);

    // 1. Contoured Cylinder Cooling Fin Barrels (Precision Machined Ribs)
    const steps = 7;
    for (let i = 0; i < steps; i++) {
      const fx = startX + (endX - startX) * (i / steps);
      const finRadius = boreRadius + (i === steps - 1 ? 5 : 3);
      const finP1 = this.project(fx, -finRadius, zPos);
      const finP2 = this.project(fx, finRadius, zPos);
      const fScale = Math.max(0.2, finP1.scale);

      // Machined Fin Barrel Body
      ctx.strokeStyle = this.viewMode === 'thermal'
        ? thermalColor
        : (isOverheating ? 'rgba(239, 68, 68, 0.85)' : `rgba(28, 48, 76, ${this.viewMode === 'cutaway' ? 0.35 : 0.85})`);
      ctx.lineWidth = Math.max(2, 3.8 * fScale);
      ctx.beginPath();
      ctx.moveTo(finP1.x, finP1.y);
      ctx.lineTo(finP2.x, finP2.y);
      ctx.stroke();

      // Outer Fin Rim Specular Highlight
      ctx.strokeStyle = this.viewMode === 'thermal' ? thermalColor : (isOverheating ? '#ef4444' : 'rgba(148, 163, 184, 0.55)');
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(finP1.x, finP1.y);
      ctx.lineTo(finP2.x, finP2.y);
      ctx.stroke();
    }

    // 2. Cylinder Head (Billet Aluminum CNC Dome Cap)
    const headPt = this.project(endX, 0, zPos);
    const hScale = Math.max(0.2, headPt.scale);
    ctx.fillStyle = this.viewMode === 'wireframe'
      ? 'rgba(56, 189, 248, 0.05)'
      : (this.viewMode === 'thermal'
        ? thermalColor
        : (isOverheating ? 'rgba(239, 68, 68, 0.8)' : 'rgba(20, 36, 62, 0.95)'));
    ctx.strokeStyle = isOverheating ? '#ef4444' : 'rgba(56, 189, 248, 0.65)';
    ctx.lineWidth = isOverheating ? 2.5 : 1.8;
    ctx.beginPath();
    ctx.arc(headPt.x, headPt.y, Math.max(2, boreRadius * 1.05 * hScale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Subtle Outer Flange Rim
    ctx.strokeStyle = isOverheating ? '#fca5a5' : 'rgba(148, 163, 184, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(headPt.x, headPt.y, Math.max(3, (boreRadius * 1.05 + 3) * hScale), 0, Math.PI * 2);
    ctx.stroke();

    // 3. Cylinder Badge Label (C1, C2, C3, C4)
    ctx.fillStyle = '#fff';
    ctx.font = `bold ${Math.max(8, Math.round(11 * hScale))}px "Orbitron", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`C${cylNum}`, headPt.x, headPt.y - 2);

    // 4. Live Temperature pill badge overlay
    ctx.fillStyle = isOverheating ? '#ef4444' : '#38bdf8';
    ctx.font = `${Math.max(7, Math.round(9 * hScale))}px "JetBrains Mono", monospace`;
    ctx.fillText(`${Math.round(chtTemp)}°`, headPt.x, headPt.y + 11 * hScale);

    // 5. Crank Pin Throw & Articulating H-Beam Connecting Rod
    const crankAngleForCyl = this.crankAngle + phaseOffset * Math.PI;
    const crankThrowX = Math.cos(crankAngleForCyl) * 16;
    const crankThrowY = Math.sin(crankAngleForCyl) * 16;
    const crankPinPt = this.project(crankThrowX, crankThrowY, zPos);

    // Dynamic Reciprocating Piston (100% mechanical lockstep with crank throw)
    const normDisp = bankSign * Math.cos(crankAngleForCyl);
    const pistonProgress = 0.525 + (normDisp * 0.325);
    const pistonX = startX + (endX - startX) * pistonProgress;
    const pCenter = this.project(pistonX, 0, zPos);
    const pScale = Math.max(0.2, pCenter.scale);
    const pRadius = Math.max(2, boreRadius * 0.85 * pScale);

    // Piston Crown
    ctx.fillStyle = this.viewMode === 'wireframe' ? 'rgba(56, 189, 248, 0.05)' : (isOverheating ? 'rgba(239, 68, 68, 0.7)' : 'rgba(71, 85, 105, 0.92)');
    ctx.strokeStyle = isOverheating ? '#ef4444' : '#94a3b8';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(pCenter.x, pCenter.y, pRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Dual Machined Compression Rings (Top Ring & Scraper Ring)
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(pCenter.x, pCenter.y, Math.max(1, pRadius - 2), 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#94a3b8';
    ctx.beginPath();
    ctx.arc(pCenter.x, pCenter.y, Math.max(1, pRadius - 4), 0, Math.PI * 2);
    ctx.stroke();

    // Wrist Pin inside Piston
    ctx.fillStyle = '#cbd5e1';
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.arc(pCenter.x, pCenter.y, Math.max(1, 3.5 * pScale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 6. H-Beam Connecting Rod Shank
    ctx.strokeStyle = isOverheating ? '#ef4444' : 'rgba(148, 163, 184, 0.85)';
    ctx.lineWidth = Math.max(1.5, 3 * pScale);
    ctx.beginPath();
    ctx.moveTo(pCenter.x, pCenter.y);
    ctx.lineTo(crankPinPt.x, crankPinPt.y);
    ctx.stroke();

    // Big-End Journal Bearing Collar at Crank Pin
    ctx.fillStyle = isOverheating ? '#ef4444' : '#e2e8f0';
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(crankPinPt.x, crankPinPt.y, Math.max(1.5, 4 * crankPinPt.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 7. 4-Stroke Combustion Radiant Flame on Power Stroke (360° to 540°)
    const strokePhase = (this.crankAngle + phaseOffset * Math.PI) % (Math.PI * 4);
    let flameAlpha = 0;
    if (strokePhase >= Math.PI * 2 && strokePhase < Math.PI * 3 && !isOverheating) {
      const pNorm = (strokePhase - Math.PI * 2) / Math.PI; // 0 to 1 across power stroke
      flameAlpha = Math.sin(pNorm * Math.PI); // Organic bell curve 0 -> 1 -> 0
    }
    if (flameAlpha > 0.05) {
      const flashPt = this.project(endX - bankSign * 8, 0, zPos);
      const rad = ctx.createRadialGradient(flashPt.x, flashPt.y, 1, flashPt.x, flashPt.y, 22 * flashPt.scale);
      rad.addColorStop(0, `rgba(255, 200, 50, ${flameAlpha * 0.85})`);
      rad.addColorStop(0.4, `rgba(255, 120, 20, ${flameAlpha * 0.45})`);
      rad.addColorStop(1, 'rgba(255, 60, 0, 0)');
      ctx.fillStyle = rad;
      ctx.beginPath();
      ctx.arc(flashPt.x, flashPt.y, 22 * flashPt.scale, 0, Math.PI * 2);
      ctx.fill();
    }

    // 8. Contoured Aerospace Rocker Box (Valve Cover)
    const rockerH = 24, rockerD = 22;
    const rBoxCorners = [
      [endX, -rockerH / 2, zPos - rockerD / 2],
      [endX + bankSign * 14, -rockerH / 2, zPos - rockerD / 2],
      [endX + bankSign * 14, rockerH / 2, zPos - rockerD / 2],
      [endX, rockerH / 2, zPos - rockerD / 2],
      [endX, -rockerH / 2, zPos + rockerD / 2],
      [endX + bankSign * 14, -rockerH / 2, zPos + rockerD / 2],
      [endX + bankSign * 14, rockerH / 2, zPos + rockerD / 2],
      [endX, rockerH / 2, zPos + rockerD / 2]
    ];
    const rBoxProj = rBoxCorners.map(c => this.project(c[0], c[1], c[2]));
    ctx.fillStyle = this.viewMode === 'wireframe'
      ? 'rgba(0, 240, 255, 0.06)'
      : (this.viewMode === 'thermal' ? thermalColor : (isOverheating ? 'rgba(239, 68, 68, 0.75)' : 'rgba(24, 38, 64, 0.92)'));
    ctx.strokeStyle = isOverheating ? '#ef4444' : 'rgba(0, 240, 255, 0.4)';
    ctx.lineWidth = 1;
    this.drawBoxEdges(rBoxProj);

    // 9. Dual Chrome Pushrod Shrouds
    const rod1Start = this.project(startX, -11, zPos - 8);
    const rod1End = this.project(endX - bankSign * 4, -11, zPos - 8);
    const rod2Start = this.project(startX, 11, zPos + 8);
    const rod2End = this.project(endX - bankSign * 4, 11, zPos + 8);
    ctx.strokeStyle = '#cbd5e1'; // Chrome
    ctx.lineWidth = Math.max(1, 2 * headPt.scale);
    ctx.beginPath();
    ctx.moveTo(rod1Start.x, rod1Start.y); ctx.lineTo(rod1End.x, rod1End.y);
    ctx.moveTo(rod2Start.x, rod2Start.y); ctx.lineTo(rod2End.x, rod2End.y);
    ctx.stroke();

    // 10. Aviation Dual-Spark Plugs & High-Tension Red Ignition Leads
    const plugUpper = this.project(endX - bankSign * 4, -boreRadius * 0.7, zPos);
    const plugLower = this.project(endX - bankSign * 4, boreRadius * 0.7, zPos);
    const ignitionHarnessPt = this.project(startX, -38, zPos);

    [plugUpper, plugLower].forEach((plug) => {
      // Brass Hex Collar
      ctx.fillStyle = '#b45309';
      ctx.fillRect(plug.x - 2, plug.y - 2, 4, 4);
      // White Ceramic Insulator
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(plug.x, plug.y, Math.max(1.5, 3 * plug.scale), 0, Math.PI * 2);
      ctx.fill();
      // Red Silicone Boot
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.arc(plug.x, plug.y - 2, Math.max(1, 2.2 * plug.scale), 0, Math.PI * 2);
      ctx.fill();

      // High-Tension Red Ignition Cable Routing to Engine Top Harness
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.75)';
      ctx.lineWidth = Math.max(1, 1.6 * plug.scale);
      ctx.beginPath();
      ctx.moveTo(plug.x, plug.y - 2);
      const midX = (plug.x + ignitionHarnessPt.x) / 2;
      const midY = Math.min(plug.y, ignitionHarnessPt.y) - 8 * plug.scale;
      ctx.quadraticCurveTo(midX, midY, ignitionHarnessPt.x, ignitionHarnessPt.y);
      ctx.stroke();

      // Spark Flash Halo when Firing
      if (strokePhase < 0.35 && !isOverheating) {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(plug.x, plug.y, Math.max(2, 5 * plug.scale), 0, Math.PI * 2);
        ctx.fill();
      }
    });

    ctx.restore();
  }

  renderTurbocharger() {
    const ctx = this.ctx;
    ctx.save();

    const compCenter = this.project(-30, -72, 65);
    const turbCenter = this.project(30, -72, 65);
    const isWgLeaking = Boolean(
      (this.telemetry.faults && this.telemetry.faults.turboWastegateLeak > 0.3) ||
      (this.telemetry.wastegatePos && this.telemetry.wastegatePos > 0.75)
    );

    // Exhaust crossover headers from cylinder banks to turbine housing (Polished Stainless Steel)
    const leftExhaust = this.project(-42, 10, 20);
    const rightExhaust = this.project(42, 10, 20);
    ctx.strokeStyle = 'rgba(100, 116, 139, 0.65)';
    ctx.lineWidth = Math.max(1.5, 2.5 * turbCenter.scale);
    ctx.beginPath();
    ctx.moveTo(leftExhaust.x, leftExhaust.y);
    ctx.lineTo(turbCenter.x - 5, turbCenter.y + 10);
    ctx.moveTo(rightExhaust.x, rightExhaust.y);
    ctx.lineTo(turbCenter.x + 5, turbCenter.y + 10);
    ctx.stroke();

    // Center Bearing Housing connecting compressor and turbine
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = Math.max(3, 5 * compCenter.scale);
    ctx.beginPath();
    ctx.moveTo(compCenter.x, compCenter.y);
    ctx.lineTo(turbCenter.x, turbCenter.y);
    ctx.stroke();

    // 1. Cold-Side Compressor Scroll (Left, CNC Billet Anodized Cyan)
    ctx.fillStyle = this.viewMode === 'wireframe'
      ? 'rgba(56, 189, 248, 0.05)'
      : (this.viewMode === 'thermal' ? '#065f46' : 'rgba(18, 30, 52, 0.92)');
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.75)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(compCenter.x, compCenter.y, Math.max(2, 22 * compCenter.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 2. Hot-Side Turbine Scroll (Right, High-Temp Ceramic Coating)
    const turbHeatColor = this.telemetry.egt[0] > 860 ? '#ef4444' : (this.telemetry.egt[0] > 820 ? '#f59e0b' : '#64748b');
    ctx.fillStyle = this.viewMode === 'wireframe'
      ? 'rgba(239, 68, 68, 0.05)'
      : (this.viewMode === 'thermal' ? turbHeatColor : 'rgba(28, 24, 26, 0.92)');
    ctx.strokeStyle = turbHeatColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(turbCenter.x, turbCenter.y, Math.max(2, 20 * turbCenter.scale), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 3. High-Speed Spinning Compressor Wheel Blades
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = Math.max(1, 1.8 * compCenter.scale);
    const blades = 6;
    for (let b = 0; b < blades; b++) {
      const angle = this.turboSpoolAngle + (b * (Math.PI * 2 / blades));
      const bx = compCenter.x + Math.cos(angle) * (16 * compCenter.scale);
      const by = compCenter.y + Math.sin(angle) * (16 * compCenter.scale);
      ctx.beginPath();
      ctx.moveTo(compCenter.x, compCenter.y);
      ctx.lineTo(bx, by);
      ctx.stroke();
    }

    // 4. Wastegate Actuator Canister (Anodized Aerospace Gold Cylinder)
    const wgPt = this.project(22, -90, 75);
    const wgScale = Math.max(0.2, wgPt.scale);
    ctx.fillStyle = isWgLeaking ? '#ef4444' : '#d97706';
    ctx.strokeStyle = isWgLeaking ? '#fca5a5' : '#fbbf24';
    ctx.lineWidth = isWgLeaking ? 2 : 1.2;
    ctx.beginPath();
    ctx.rect(wgPt.x - 7 * wgScale, wgPt.y - 12 * wgScale, 14 * wgScale, 24 * wgScale);
    ctx.fill();
    ctx.stroke();

    // Actuator pushrod linkage to turbine wastegate valve
    ctx.strokeStyle = isWgLeaking ? '#ef4444' : '#cbd5e1';
    ctx.lineWidth = Math.max(1, 2 * wgScale);
    ctx.beginPath();
    ctx.moveTo(wgPt.x, wgPt.y + 12 * wgScale);
    ctx.lineTo(turbCenter.x + 8 * turbCenter.scale, turbCenter.y - 8 * turbCenter.scale);
    ctx.stroke();

    // Turbo Title Badge
    ctx.fillStyle = '#fff';
    ctx.font = `bold ${Math.max(7, Math.round(8.5 * wgScale))}px "Orbitron", monospace`;
    ctx.fillText('TURBO', compCenter.x, compCenter.y - 26 * compCenter.scale);

    ctx.restore();
  }

  renderFuelSystemAndInjectors() {
    const ctx = this.ctx;
    ctx.save();

    const isCutoff = !this.telemetry.fuelWallOpen;

    // Fuel Distribution Rail (Along top of engine)
    const railStart = this.project(0, -42, -55);
    const railEnd = this.project(0, -42, 55);

    ctx.strokeStyle = isCutoff ? '#64748b' : 'rgba(0, 240, 255, 0.7)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(railStart.x, railStart.y);
    ctx.lineTo(railEnd.x, railEnd.y);
    ctx.stroke();

    // 4 Individual Fuel Injectors (Over each cylinder bank)
    const injectorLocs = [
      { cyl: 1, x: -65, y: -38, z: -45 },
      { cyl: 2, x: 65, y: -38, z: -45, clog: Boolean(this.telemetry.faults && this.telemetry.faults.injectorClog && this.telemetry.faults.injectorClog[1] > 0) },
      { cyl: 3, x: -65, y: -38, z: 45 },
      { cyl: 4, x: 65, y: -38, z: 45 }
    ];

    injectorLocs.forEach(inj => {
      const pt = this.project(inj.x, inj.y, inj.z);
      const isClog = inj.clog;

      ctx.fillStyle = isCutoff ? '#475569' : (isClog ? '#f59e0b' : '#10b981');
      ctx.strokeStyle = isClog ? '#ef4444' : '#fff';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4.5 * pt.scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Feeder line from rail to injector
      const railFeed = this.project(0, -42, inj.z);
      ctx.strokeStyle = isCutoff ? '#475569' : (isClog ? '#f59e0b' : 'rgba(56, 189, 248, 0.55)');
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(railFeed.x, railFeed.y);
      ctx.lineTo(pt.x, pt.y);
      ctx.stroke();
    });

    ctx.restore();
  }

  renderIntakeAndExhaust() {
    const ctx = this.ctx;
    ctx.save();

    const egtMax = Math.max(...this.telemetry.egt);
    const headerColor = egtMax > 860 ? '#ef4444' : (egtMax > 830 ? '#f59e0b' : 'rgba(100, 116, 139, 0.85)');
    const compCold = this.project(-30, -72, 65);
    const turbHot = this.project(30, -72, 65);
    const intakePlenum = this.project(0, -42, 0);

    // 1. Cold Intercooler Boost Duct (Compressor -> Intake Plenum - Anodized Cyan)
    ctx.strokeStyle = this.viewMode === 'wireframe' ? 'rgba(56, 189, 248, 0.2)' : 'rgba(56, 189, 248, 0.85)';
    ctx.lineWidth = Math.max(2, 3.8 * compCold.scale);
    ctx.beginPath();
    ctx.moveTo(compCold.x, compCold.y);
    ctx.quadraticCurveTo(compCold.x, intakePlenum.y - 15, intakePlenum.x, intakePlenum.y);
    ctx.stroke();

    // 4 Branching Intake Runners (Plenum -> Cylinder Heads)
    const cylIntakes = [
      { x: -65, y: -22, z: -45 },
      { x: 65, y: -22, z: -45 },
      { x: -65, y: -22, z: 45 },
      { x: 65, y: -22, z: 45 }
    ];
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
    ctx.lineWidth = Math.max(1.5, 2.5 * intakePlenum.scale);
    cylIntakes.forEach(pt3d => {
      const p = this.project(pt3d.x, pt3d.y, pt3d.z);
      ctx.beginPath();
      ctx.moveTo(intakePlenum.x, intakePlenum.y);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    });

    // 2. Tuned Stainless Steel Exhaust Headers (Polished Inconel Curvature)
    const cylExhausts = [
      { x: -65, y: 22, z: -45 },
      { x: 65, y: 22, z: -45 },
      { x: -65, y: 22, z: 45 },
      { x: 65, y: 22, z: 45 }
    ];
    ctx.strokeStyle = this.viewMode === 'wireframe' ? 'rgba(245, 158, 11, 0.25)' : headerColor;
    ctx.lineWidth = Math.max(1.5, 2.8 * turbHot.scale);
    cylExhausts.forEach(pt3d => {
      const p = this.project(pt3d.x, pt3d.y, pt3d.z);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.quadraticCurveTo(p.x * 0.4, p.y + 15, turbHot.x, turbHot.y + 10);
      ctx.stroke();
    });

    ctx.restore();
  }

  renderActiveFocusReticle() {
    const comp = this.components[this.activeComponentKey];
    if (!comp) return;
    const pt = this.project(comp.x, comp.y, comp.z);
    const defect = this.getComponentDefectInfo(this.activeComponentKey);
    const isCrit = defect.level === 'critical';
    const isWarn = defect.level === 'warning';
    const hudColor = isCrit ? '#ef4444' : (isWarn ? '#f59e0b' : '#00f0ff');
    const glowColor = isCrit ? 'rgba(239, 68, 68, 0.35)' : (isWarn ? 'rgba(245, 158, 11, 0.3)' : 'rgba(0, 240, 255, 0.3)');

    const ctx = this.ctx;
    ctx.save();

    const t = Date.now() * 0.003;
    const r = Math.max(20, (comp.radius || 35) * pt.scale * 0.85);

    // 1. Outer Pulsing Glow Ring
    const pulseR = r + Math.sin(t * 3.5) * 3;
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, pulseR, 0, Math.PI * 2);
    ctx.stroke();

    // 2. Rotating Segmented HUD Reticle
    ctx.strokeStyle = hudColor;
    ctx.lineWidth = 1.8;
    const segments = 4;
    for (let i = 0; i < segments; i++) {
      const startAngle = t + (i * (Math.PI * 2 / segments));
      const endAngle = startAngle + (Math.PI / (segments * 1.5));
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, r, startAngle, endAngle);
      ctx.stroke();
    }

    // 3. Precision Crosshair Ticks
    const tickLen = 6 * pt.scale;
    ctx.lineWidth = 1.2;
    // Top
    ctx.beginPath(); ctx.moveTo(pt.x, pt.y - r - tickLen); ctx.lineTo(pt.x, pt.y - r + 2); ctx.stroke();
    // Bottom
    ctx.beginPath(); ctx.moveTo(pt.x, pt.y + r - 2); ctx.lineTo(pt.x, pt.y + r + tickLen); ctx.stroke();
    // Left
    ctx.beginPath(); ctx.moveTo(pt.x - r - tickLen, pt.y); ctx.lineTo(pt.x - r + 2, pt.y); ctx.stroke();
    // Right
    ctx.beginPath(); ctx.moveTo(pt.x + r - 2, pt.y); ctx.lineTo(pt.x + r + tickLen); ctx.stroke();

    // 4. Center Micro Reticle Dot
    ctx.fillStyle = hudColor;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 2.5, 0, Math.PI * 2);
    ctx.fill();

    // 5. Tactical Subsystem Callout Tag
    const tagX = pt.x + r + 10;
    const tagY = pt.y - r - 4;
    ctx.font = 'bold 9px "Orbitron", monospace';
    ctx.fillStyle = hudColor;
    ctx.fillText(`TARGET: ${comp.name.toUpperCase()}`, tagX, tagY);
    ctx.font = '8px "JetBrains Mono", monospace';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(`${defect.badgeText}`, tagX, tagY + 11);

    ctx.restore();
  }

  renderWastegateLeakPlume() {
    const ctx = this.ctx;
    ctx.save();
    this.leakParticles.forEach(p => {
      const pt = this.project(p.x, p.y, p.z);
      const alpha = 1 - p.life;
      ctx.fillStyle = `rgba(245, 158, 11, ${alpha * 0.7})`;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, (2.5 + p.life * 4) * pt.scale, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  renderBearingWearSparks() {
    const ctx = this.ctx;
    ctx.save();
    const bearingPt = this.project(0, 0, 0);
    for (let i = 0; i < 4; i++) {
      const angle = Math.random() * Math.PI * 2;
      const r = 10 + Math.random() * 15;
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(bearingPt.x + Math.cos(angle) * r, bearingPt.y + Math.sin(angle) * r, 2, 2);
    }
    ctx.restore();
  }

  renderThermalOverheatSparks() {
    const ctx = this.ctx;
    ctx.save();
    this.particles.forEach(p => {
      const pt = this.project(p.x, p.y, p.z);
      const alpha = 1 - p.life;
      ctx.fillStyle = `rgba(255, ${Math.floor(80 + Math.random() * 100)}, 20, ${alpha})`;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, (2 + Math.random() * 3) * pt.scale, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  render3DComponentLabels() {
    const ctx = this.ctx;
    ctx.save();

    for (const [key, comp] of Object.entries(this.components)) {
      const pt = this.project(comp.x, comp.y, comp.z);
      const isSelected = key === this.activeComponentKey;
      const defect = this.getComponentDefectInfo(key);

      const isCritical = defect.level === 'critical';
      const isWarning = defect.level === 'warning';
      const hasDefect = isCritical || isWarning;

      const isLeft = comp.x < 0;
      const leaderColor = isCritical ? '#ef4444' : (isWarning ? '#f59e0b' : (isSelected ? '#38bdf8' : 'rgba(56, 189, 248, 0.35)'));

      // 1. Clean Dog-Leg Leader Line Anchor
      ctx.strokeStyle = leaderColor;
      ctx.lineWidth = isSelected || hasDefect ? 1.2 : 0.8;
      ctx.setLineDash(isSelected ? [] : [2, 2]);

      const dogLegX = pt.x + (isLeft ? -16 : 16);
      const dogLegY = pt.y - 14;
      const tagX = pt.x + (isLeft ? -36 : 36);
      const tagY = pt.y - 14;

      ctx.beginPath();
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(dogLegX, dogLegY);
      ctx.lineTo(tagX, tagY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Precision Anchor Dot
      ctx.fillStyle = leaderColor;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, (isSelected ? 3.5 : 2) * Math.max(0.4, pt.scale), 0, Math.PI * 2);
      ctx.fill();

      // 2. HUD Label Card (Aerospace Glassmorphic Badge)
      const labelText = comp.name;
      ctx.font = 'bold 8px "Orbitron", monospace';
      const textWidth = Math.max(68, ctx.measureText(labelText).width + 20);

      const cardX = isLeft ? tagX - textWidth : tagX;
      const cardY = tagY - 8;

      ctx.fillStyle = isCritical
        ? 'rgba(239, 68, 68, 0.22)'
        : (isWarning ? 'rgba(245, 158, 11, 0.2)' : (isSelected ? 'rgba(14, 165, 233, 0.22)' : 'rgba(10, 18, 34, 0.88)'));
      ctx.strokeStyle = isCritical ? '#ef4444' : (isWarning ? '#f59e0b' : (isSelected ? '#38bdf8' : 'rgba(56, 189, 248, 0.35)'));
      ctx.lineWidth = isSelected || hasDefect ? 1.4 : 0.9;

      ctx.beginPath();
      if (ctx.roundRect) {
        ctx.roundRect(cardX, cardY, textWidth, 16, 3);
      } else {
        ctx.rect(cardX, cardY, textWidth, 16);
      }
      ctx.fill();
      ctx.stroke();

      // Status Micro-Dot
      ctx.fillStyle = isCritical ? '#ef4444' : (isWarning ? '#f59e0b' : '#10b981');
      ctx.beginPath();
      ctx.arc(cardX + 7, cardY + 8, 2.2, 0, Math.PI * 2);
      ctx.fill();

      // Label Text
      ctx.fillStyle = isCritical ? '#fca5a5' : (isWarning ? '#fbbf24' : '#f8fafc');
      ctx.fillText(labelText, cardX + 13, cardY + 11);

      // Selected Reticle Brackets
      if (isSelected) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.4;
        const brLen = 6;
        const pad = 16 * pt.scale;
        // Top-left
        ctx.beginPath(); ctx.moveTo(pt.x - pad, pt.y - pad + brLen); ctx.lineTo(pt.x - pad, pt.y - pad); ctx.lineTo(pt.x - pad + brLen, pt.y - pad); ctx.stroke();
        // Top-right
        ctx.beginPath(); ctx.moveTo(pt.x + pad - brLen, pt.y - pad); ctx.lineTo(pt.x + pad, pt.y - pad); ctx.lineTo(pt.x + pad, pt.y - pad + brLen); ctx.stroke();
        // Bottom-left
        ctx.beginPath(); ctx.moveTo(pt.x - pad, pt.y + pad - brLen); ctx.lineTo(pt.x - pad, pt.y + pad); ctx.lineTo(pt.x - pad + brLen, pt.y + pad); ctx.stroke();
        // Bottom-right
        ctx.beginPath(); ctx.moveTo(pt.x + pad - brLen, pt.y + pad); ctx.lineTo(pt.x + pad, pt.y + pad); ctx.lineTo(pt.x + pad, pt.y + pad - brLen); ctx.stroke();
      }
    }

    ctx.restore();
  }

  getComponentDefectInfo(compKey) {
    const t = this.telemetry;

    switch (compKey) {
      case 'uav_airframe':
        return {
          name: 'DRDO TAPAS-BH-201 MALE UAV PLATFORM',
          partMeta: 'DRDO / ADE • TACTICAL MALE UAV • PUSHER PROPULSION',
          level: (t.cht[2] > 205 || !t.fuelWallOpen) ? 'critical' : ((t.faults && t.faults.turboWastegateLeak > 0.3) ? 'warning' : 'nominal'),
          badgeText: (!t.fuelWallOpen) ? '🚨 DEADSTICK GLIDE' : (t.cht[2] > 205 ? '⚠️ AUTONOMOUS DIVERT' : ((t.faults && t.faults.turboWastegateLeak > 0.3) ? '⚠️ BOOST DEGRADATION' : '✓ PLATFORM AIRWORTHY')),
          reading: `${Math.round(t.altitude || 18000)} FT • 118 KTS`,
          limit: 'SERVICE CEILING: 30,000 FT',
          rul: '1,420 FLIGHT HRS',
          defectTitle: (!t.fuelWallOpen) ? '🚨 ENGINE OUT - BEST GLIDE DESCENT' : (t.cht[2] > 205 ? '⚠️ PROPULSION THERMAL ENVELOPE REDUCTION' : '✓ ALL AIRFRAME & PROPULSION SYSTEMS AIRWORTHY'),
          defectDesc: 'Composite twin-boom airframe with rear-mounted 115 HP turbocharged aero piston engine. Wingspan 20.6m, MTOW 1,800 kg, safe loiter reach intact.',
          remedy: (!t.fuelWallOpen) ? 'DIRECTIVE: Maintain 104 KTS glide speed, vector to Deesa FLS Runway 14/32.' : 'DIRECTIVE: Maintain border patrol loiter sector.'
        };

      case 'cyl3':
        if (t.cht[2] > 200) {
          return {
            name: 'CYLINDER HEAD #3 (LEFT REAR)',
            partMeta: 'CEMILAC PART: AERO-CYL-304 • BANK A (AFT)',
            level: 'critical',
            badgeText: '🔥 CRITICAL DEFECT',
            reading: `${Math.round(t.cht[2])}°C CHT (LIMIT: 185°C)`,
            limit: '< 185°C CONTINUOUS',
            rul: '42 HRS (RAPID DECAY)',
            defectTitle: '🔥 THERMAL RUNAWAY & ACOUSTIC KNOCK',
            defectDesc: 'High-altitude lean-burn detonation. Cylinder #3 CHT exceeding 224°C with 3200 Hz pre-ignition knock shockwaves. Severe thermo-mechanical fatigue on cylinder dome and exhaust valve seat erosion.',
            remedy: 'DIRECTIVE: Derate throttle to 62%, cool cylinder, divert to Deesa FLS, borescope inspect valve seats upon landing.'
          };
        }
        return {
          name: 'CYLINDER HEAD #3 (LEFT REAR)',
          partMeta: 'CEMILAC PART: AERO-CYL-304 • BANK A (AFT)',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${Math.round(t.cht[2])}°C CHT`,
          limit: '< 185°C CONTINUOUS',
          rul: '850 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Thermal dissipation balanced across cylinder fins. Compression ring seal and spark timing nominal.',
          remedy: 'DIRECTIVE: Continue planned ISR loiter mission profile.'
        };

      case 'cyl2':
        if (t.cht[1] > 190) {
          return {
            name: 'CYLINDER HEAD #2 (RIGHT FRONT)',
            partMeta: 'CEMILAC PART: AERO-CYL-202 • BANK B (FWD)',
            level: 'warning',
            badgeText: '⚠️ INJECTOR CLOG',
            reading: `${Math.round(t.cht[1])}°C CHT / 850°C EGT`,
            limit: '< 185°C CHT',
            rul: '280 HRS',
            defectTitle: '⚠️ INJECTOR #2 ORIFICE CLOG & MISFIRE',
            defectDesc: 'Micro-varnish restriction in Injector #2 nozzle orifice. Fuel flow starved by 70%, creating lean combustion spike and intermittent cylinder misfire.',
            remedy: 'DIRECTIVE: Enrich fuel mixture bias, clean/replace injector nozzle assembly during post-flight turnaround.'
          };
        }
        return {
          name: 'CYLINDER HEAD #2 (RIGHT FRONT)',
          partMeta: 'CEMILAC PART: AERO-CYL-202 • BANK B (FWD)',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${Math.round(t.cht[1])}°C CHT`,
          limit: '< 185°C CHT',
          rul: '890 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Fuel atomization spray pattern symmetric. Cylinder CHT and EGT readings within normal envelope.',
          remedy: 'DIRECTIVE: Continue normal operation.'
        };

      case 'cyl1':
        if (t.cht[0] > 190) {
          return {
            name: 'CYLINDER HEAD #1 (LEFT FRONT)',
            partMeta: 'CEMILAC PART: AERO-CYL-101 • BANK A (FWD)',
            level: 'critical',
            badgeText: '🚨 THERMAL OVERHEAT',
            reading: `${Math.round(t.cht[0])}°C CHT (LIMIT: 185°C)`,
            limit: '< 185°C CHT',
            rul: '45 HRS',
            defectTitle: '🚨 CYLINDER #1 THERMAL RUNAWAY & VALVE MARGIN EROSION',
            defectDesc: 'Cylinder #1 head temperature exceeded 215°C critical threshold. Stellite exhaust valve seat micro-cracking and pre-ignition combustion spike.',
            remedy: 'DIRECTIVE: Immediate power derate to 60%, enrich mixture, descend to cooler ambient air density.'
          };
        }
        return {
          name: 'CYLINDER HEAD #1 (LEFT FRONT)',
          partMeta: 'CEMILAC PART: AERO-CYL-101 • BANK A (FWD)',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${Math.round(t.cht[0])}°C CHT`,
          limit: '< 185°C CHT',
          rul: '910 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Combustion pressure profile nominal. Cooling airflow across front left baffle fully efficient.',
          remedy: 'DIRECTIVE: Normal operational monitoring.'
        };

      case 'cyl4':
        if (t.cht[3] > 190) {
          return {
            name: 'CYLINDER HEAD #4 (RIGHT REAR)',
            partMeta: 'CEMILAC PART: AERO-CYL-404 • BANK B (AFT)',
            level: 'critical',
            badgeText: '🚨 RING FLUTTER',
            reading: `${Math.round(t.cht[3])}°C CHT`,
            limit: '< 185°C CHT',
            rul: '60 HRS',
            defectTitle: '🚨 CYLINDER #4 PISTON RING FLUTTER & BLOWBY OVERPRESSURE',
            defectDesc: 'Severe combustion blowby leaking past piston ring pack. Crankcase overpressure exceeds 0.22 Bar with oil misting and thermal scuffing.',
            remedy: 'DIRECTIVE: Derate throttle, reduce manifold pressure below 26 inHg, vector to recovery base.'
          };
        }
        return {
          name: 'CYLINDER HEAD #4 (RIGHT REAR)',
          partMeta: 'CEMILAC PART: AERO-CYL-404 • BANK B (AFT)',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${Math.round(t.cht[3])}°C CHT`,
          limit: '< 185°C CHT',
          rul: '880 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Cylinder head integrity sound. Dual ignition spark discharge balanced.',
          remedy: 'DIRECTIVE: Normal operational monitoring.'
        };

      case 'turbo':
        const isTurboFault = Boolean(
          (t.faults && t.faults.turboWastegateLeak > 0.3) ||
          (t.wastegatePos && t.wastegatePos > 0.75)
        );
        if (isTurboFault) {
          return {
            name: 'TURBOCHARGER & WASTEGATE ACTUATOR',
            partMeta: 'CEMILAC PART: AERO-TC-914 • ROTAX/DRDO',
            level: 'warning',
            badgeText: '⚠️ WASTEGATE JAMMED',
            reading: `${t.map.toFixed(1)} inHg MAP (DEFICIT: -11 inHg)`,
            limit: '> 28.0 inHg AT FULL BOOST',
            rul: '340 HRS',
            defectTitle: '⚠️ WASTEGATE VALVE STUCK OPEN (85%)',
            defectDesc: 'Pneumatic actuator bleed diaphragm leak. Wastegate valve jammed 85% open, allowing high-altitude exhaust gas to bypass the turbine wheel. Turbo boost collapsed.',
            remedy: 'DIRECTIVE: Restrict UAV ceiling to 14,000 ft, verify pneumatic reference hose and wastegate pivot linkage upon recovery.'
          };
        }
        return {
          name: 'TURBOCHARGER & WASTEGATE ACTUATOR',
          partMeta: 'CEMILAC PART: AERO-TC-914 • ROTAX/DRDO',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${t.map.toFixed(1)} inHg BOOST`,
          limit: '> 20.0 inHg CONTINUOUS',
          rul: '780 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Turbine and compressor wheels spinning synchronously. Wastegate duty cycle responsive.',
          remedy: 'DIRECTIVE: Altitude power loiter intact.'
        };

      case 'oil_system':
        if (t.oilPress < 30.0) {
          return {
            name: 'LUBRICATION PUMP & SUMP',
            partMeta: 'CEMILAC PART: AERO-OIL-500 • DUAL SCAVENGE',
            level: 'critical',
            badgeText: '🚨 CAVITATION LOSS',
            reading: `${t.oilPress.toFixed(1)} PSI (REQ: >42 PSI)`,
            limit: '> 42.0 PSI MINIMUM',
            rul: '18 HRS (HIGH RISK)',
            defectTitle: '🚨 OIL PUMP CAVITATION & BEARING SHEAR',
            defectDesc: 'Lube pump volumetric efficiency collapse. Oil pressure plunged to 18.5 PSI. Hydrodynamic oil wedge thickness collapsed below safety limits with severe journal bearing friction and imminent seizure risk.',
            remedy: 'DIRECTIVE: Immediate precautionary diversion required. Ground inspect oil pickup screen, flush aeration bubbles.'
          };
        } else if (t.oilPress < 42.0) {
          return {
            name: 'LUBRICATION PUMP & SUMP',
            partMeta: 'CEMILAC PART: AERO-OIL-500 • DUAL SCAVENGE',
            level: 'warning',
            badgeText: '⚠️ LOW LUBE PRESSURE',
            reading: `${t.oilPress.toFixed(1)} PSI`,
            limit: '> 42.0 PSI MINIMUM',
            rul: '220 HRS',
            defectTitle: '⚠️ LUBRICATION CAVITATION WARNING',
            defectDesc: 'Oil pressure below recommended 42 PSI threshold. High oil temperature thinning lube viscosity.',
            remedy: 'DIRECTIVE: Reduce power command, monitor oil temp trend.'
          };
        }
        return {
          name: 'LUBRICATION PUMP & SUMP',
          partMeta: 'CEMILAC PART: AERO-OIL-500 • DUAL SCAVENGE',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${t.oilPress.toFixed(1)} PSI / ${Math.round(t.oilTemp)}°C`,
          limit: '> 42.0 PSI CONTINUOUS',
          rul: '820 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Oil pressure stable at 52 PSI. Dual scavenge pump maintaining positive oil delivery to all 4 journal bearings.',
          remedy: 'DIRECTIVE: Lubrication system nominal.'
        };

      case 'crankshaft':
        if (t.vibrationRms > 3.0 || t.oilPress < 30.0) {
          return {
            name: 'CRANKSHAFT & JOURNAL BEARINGS',
            partMeta: 'CEMILAC PART: AERO-CRK-414 • FORGED ALLOY',
            level: 'critical',
            badgeText: '🚨 JOURNAL WEAR',
            reading: `${t.vibrationRms.toFixed(2)} mm/s RMS`,
            limit: '< 2.5 mm/s RMS',
            rul: '35 HRS',
            defectTitle: '🚨 1800 HZ HYDRODYNAMIC BEARING HARMONICS',
            defectDesc: 'Excessive radial clearance on main journal bearings. Oil starvation causing metal-on-metal micro-scuffing and torsional crankshaft vibration.',
            remedy: 'DIRECTIVE: Derate engine power, replace bronze split sleeve bearings at next scheduled maintenance.'
          };
        }
        return {
          name: 'CRANKSHAFT & JOURNAL BEARINGS',
          partMeta: 'CEMILAC PART: AERO-CRK-414 • FORGED ALLOY',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: `${t.vibrationRms.toFixed(2)} mm/s RMS`,
          limit: '< 2.5 mm/s RMS',
          rul: '950 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Crankshaft dynamic balance within 0.2 g-mm. All 4 con-rod big-end journals operating with nominal oil film cushion.',
          remedy: 'DIRECTIVE: Kinematic assembly healthy.'
        };

      case 'fuel_system':
        if (!t.fuelWallOpen) {
          return {
            name: 'FUEL RAIL & EMERGENCY FIREWALL VALVE',
            partMeta: 'CEMILAC PART: AERO-FW-100 • FIREWALL CUTOFF',
            level: 'critical',
            badgeText: '🚨 FIREWALL CUTOFF',
            reading: `0.0 L/HR • 0 PSI RAIL`,
            limit: '> 40.0 PSI RAIL',
            rul: '0 HRS (FLAMEOUT)',
            defectTitle: '🚨 EMERGENCY FIREWALL FUEL VALVE ISOLATED',
            defectDesc: 'Emergency fuel firewall shutoff valve has mechanically closed. Fuel line delivery severed to all 4 cylinder injectors. Engine starved, RPM decaying to dead-stick windmilling.',
            remedy: 'DIRECTIVE: Maintain best glide airspeed (104 kts), execute dead-stick landing on Deesa FLS runway 14/32.'
          };
        } else if (t.fuelRemainingKg < 45.0) {
          return {
            name: 'FUEL RAIL & EMERGENCY FIREWALL VALVE',
            partMeta: 'CEMILAC PART: AERO-FW-100 • FIREWALL CUTOFF',
            level: 'warning',
            badgeText: '⚠️ BINGO FUEL',
            reading: `${t.fuelRemainingKg.toFixed(1)} KG TANK REMAINING`,
            limit: '> 45.0 KG TACTICAL RESERVE',
            rul: '1.8 HRS REMAINING',
            defectTitle: '⚠️ BINGO FUEL RESERVE EXHAUSTION',
            defectDesc: 'Fuel mass in wings below 45 kg minimum operational reserve margin. Loiter time depleted.',
            remedy: 'DIRECTIVE: Terminate loiter orbit, vector home to Base Alpha (Uttarlai AFS).'
          };
        }
        return {
          name: 'FUEL RAIL & EMERGENCY FIREWALL VALVE',
          partMeta: 'CEMILAC PART: AERO-FW-100 • FIREWALL CUTOFF',
          level: 'nominal',
          badgeText: '✓ ARMED (OPEN)',
          reading: `${t.fuelFlow.toFixed(1)} L/HR • ${t.fuelPressure.toFixed(1)} PSI`,
          limit: '40 - 46 PSI RAIL',
          rul: '850 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Firewall shutoff valve open. Fuel rail pressure nominal at 43.5 PSI with stoichiometric 14.7 AFR metering.',
          remedy: 'DIRECTIVE: Fuel delivery nominal.'
        };

      case 'gearbox':
        if (t.vibrationRms > 3.0) {
          return {
            name: 'PROPELLER REDUCTION GEARBOX (PRSU)',
            partMeta: 'CEMILAC PART: AERO-GB-243 • RATIO 2.43:1',
            level: 'critical',
            badgeText: '🚨 TORSIONAL VIBE',
            reading: `${t.vibrationRms.toFixed(2)} mm/s RMS`,
            limit: '< 2.5 mm/s RMS',
            rul: '55 HRS',
            defectTitle: '🚨 PRSU HELICAL BACKLASH & DAMPER DELAMINATION',
            defectDesc: 'Rubber-in-shear torsional isolator delamination. Shock torque pulses propagating to propeller hub with abnormal gearbox backlash vibration.',
            remedy: 'DIRECTIVE: Restrict engine RPM to 3600 max, avoid aggressive throttle transients, divert immediately.'
          };
        }
        return {
          name: 'PROPELLER REDUCTION GEARBOX (PRSU)',
          partMeta: 'CEMILAC PART: AERO-GB-243 • RATIO 2.43:1',
          level: 'nominal',
          badgeText: '✓ HEALTHY',
          reading: '2.43:1 REDUCTION (1728 PROP RPM)',
          limit: '< 2000 PROP RPM',
          rul: '1200 HRS',
          defectTitle: '✓ NO ACTIVE DEFECTS (NOMINAL)',
          defectDesc: 'Helical gear mesh backlash and torsional vibration damper fully synchronized with variable-pitch propeller hub.',
          remedy: 'DIRECTIVE: Transmission assembly nominal.'
        };

      case 'uav_airframe':
        if (!t.fuelWallOpen || t.rpm < 2000) {
          return {
            name: 'DRDO TAPAS-BH-201 MALE UAV AIRFRAME & ENGINE BAY',
            partMeta: 'DRDO / ADE • MEDIUM ALTITUDE LONG ENDURANCE (MALE) UAV',
            level: 'critical',
            badgeText: '🚨 DEAD-STICK GLIDE',
            reading: '0 HP OUTPUT • GLIDE DESCENT (104 KTS)',
            limit: 'GLIDE RATIO: 14.8 : 1',
            rul: '0 HRS (FLAMEOUT)',
            defectTitle: '🚨 IN-FLIGHT PROPULSION LOSS (DEAD-STICK GLIDE)',
            defectDesc: 'Pusher propulsion terminated. Tapas-BH-201 MALE UAV entering autonomous dead-stick gliding recovery envelope (14.8:1 L/D ratio).',
            remedy: 'DIRECTIVE: Squawk 7700 emergency, steer optimal heading 194° to Deesa FLS runway 14/32.'
          };
        }
        return {
          name: 'DRDO TAPAS-BH-201 MALE UAV AIRFRAME & ENGINE BAY',
          partMeta: 'DRDO / ADE • MEDIUM ALTITUDE LONG ENDURANCE (MALE) UAV',
          level: 'nominal',
          badgeText: '✓ CERTIFIED MALE PLATFORM',
          reading: '20.6M WINGSPAN • 115 HP PUSHER',
          limit: 'SERVICE CEILING: 30,000 FT',
          rul: '3,200 FLIGHT HRS',
          defectTitle: '✓ AIRFRAME & PROPULSION INTEGRITY NOMINAL',
          defectDesc: 'Carbon-fiber composite airframe, twin tail booms, and pusher engine nacelle operating within certified aero-elastic flutter limits.',
          remedy: 'DIRECTIVE: Airframe within certified flight envelope.'
        };

      default:
        return {
          name: 'AERO ENGINE COMPONENT',
          partMeta: 'CEMILAC DRDO TAPAS ENGINE',
          level: 'nominal',
          badgeText: '✓ NOMINAL',
          reading: 'NORMAL',
          limit: 'NORMAL',
          rul: '800+ HRS',
          defectTitle: '✓ SYSTEM OPERATIONAL',
          defectDesc: 'Component operating within certified defense flight envelope.',
          remedy: 'DIRECTIVE: Routine mission monitoring.'
        };
    }
  }

  updateComponentInspectorDOM(compKey) {
    const info = this.getComponentDefectInfo(compKey);

    const titleEl = document.getElementById('inspect-comp-title');
    const badgeEl = document.getElementById('inspect-comp-badge');
    const metaEl = document.getElementById('inspect-part-meta');
    const readingEl = document.getElementById('inspect-stat-reading');
    const limitEl = document.getElementById('inspect-stat-limit');
    const rulEl = document.getElementById('inspect-stat-rul');
    const boxEl = document.getElementById('inspect-defect-box');
    const defectTitleEl = document.getElementById('inspect-defect-title');
    const defectDescEl = document.getElementById('inspect-defect-desc');
    const remedyEl = document.getElementById('inspect-defect-remedy');

    if (titleEl) titleEl.textContent = info.name;
    if (badgeEl) {
      badgeEl.textContent = info.badgeText;
      badgeEl.className = 'badge ' + (info.level === 'critical' ? 'badge-critical' : (info.level === 'warning' ? 'badge-warning' : 'badge-nominal'));
    }
    if (metaEl) metaEl.textContent = info.partMeta;
    if (readingEl) readingEl.textContent = info.reading;
    if (limitEl) limitEl.textContent = info.limit;
    if (rulEl) rulEl.textContent = info.rul;

    if (boxEl) {
      boxEl.className = 'defect-diagnostic-box ' + (info.level === 'critical' ? 'critical-defect' : (info.level === 'warning' ? 'warning-defect' : ''));
    }
    if (defectTitleEl) defectTitleEl.textContent = info.defectTitle;
    if (defectDescEl) defectDescEl.textContent = info.defectDesc;
    if (remedyEl) remedyEl.innerHTML = `<strong>REMEDIATION:</strong> ${info.remedy.replace('DIRECTIVE: ', '')}`;

    // Highlight active quick pill
    const pills = document.querySelectorAll('#component-quick-pills .comp-pill');
    pills.forEach(p => {
      const pKey = p.getAttribute('data-comp');
      p.classList.toggle('active', pKey === compKey);
      const pDefect = this.getComponentDefectInfo(pKey);
      p.classList.toggle('has-critical', pDefect.level === 'critical');
      p.classList.toggle('has-defect', pDefect.level === 'warning');
    });
  }

  renderOttoCycleIndicator() {
    // 1. Calculate Crankshaft Angle in Degrees across 720° 4-Stroke Cycle
    const cycleRad = (this.crankAngle % (Math.PI * 4) + Math.PI * 4) % (Math.PI * 4);
    const crankDeg = Math.round((cycleRad / (Math.PI * 4)) * 720);

    const crankEl = document.getElementById('hud-crank-deg');
    if (crankEl) {
      crankEl.textContent = `CRANK: ${crankDeg}° / 720°`;
    }

    // 2. Cylinder phase offsets matching 1-3-2-4 firing sequence
    const cylOffsets = [0, 2, 1, 3];
    const strokeDescriptions = {
      INTAKE: 'Induction: Intake valve open • Piston descending • Fuel-air charge inflow',
      COMPRESSION: 'Compression: Both valves sealed • Piston rising • Charge pressure & temp rising',
      POWER: 'Combustion: Spark plug fired • High-pressure flame expansion forcing piston down',
      EXHAUST: 'Scavenge: Exhaust valve open • Piston rising • Hot burnt gas evacuated'
    };

    cylOffsets.forEach((phaseOff, idx) => {
      const cylNum = idx + 1;
      const strokePhase = (this.crankAngle + phaseOff * Math.PI) % (Math.PI * 4);
      let strokeName = 'INTAKE';
      let badgeClass = 'stroke-intake';
      let strokeColor = '#38bdf8';
      let pct = 0;

      if (strokePhase < Math.PI) {
        strokeName = 'INTAKE 💨';
        badgeClass = 'stroke-intake';
        strokeColor = '#38bdf8';
        pct = Math.round((strokePhase / Math.PI) * 100);
      } else if (strokePhase < Math.PI * 2) {
        strokeName = 'COMPRESSION ⚡';
        badgeClass = 'stroke-comp';
        strokeColor = '#a855f7';
        pct = Math.round(((strokePhase - Math.PI) / Math.PI) * 100);
      } else if (strokePhase < Math.PI * 3) {
        strokeName = 'POWER 🔥';
        badgeClass = 'stroke-power';
        strokeColor = '#f59e0b';
        pct = Math.round(((strokePhase - Math.PI * 2) / Math.PI) * 100);
      } else {
        strokeName = 'EXHAUST 💨';
        badgeClass = 'stroke-exhaust';
        strokeColor = '#ef4444';
        pct = Math.round(((strokePhase - Math.PI * 3) / Math.PI) * 100);
      }

      // Synchronize with DOM HUD if present
      const rowEl = document.getElementById(`hud-cyl-stroke-${cylNum}`);
      if (rowEl) {
        const rawKey = strokeName.split(' ')[0];
        rowEl.title = `Cylinder #${cylNum} ${strokeDescriptions[rawKey] || ''}`;
        const badge = rowEl.querySelector('.cyl-stroke-badge');
        const bar = rowEl.querySelector('.cyl-progress-bar');
        if (badge) {
          badge.textContent = strokeName;
          badge.className = `cyl-stroke-badge ${badgeClass}`;
        }
        if (bar) {
          bar.style.width = `${Math.max(6, pct)}%`;
          bar.style.background = strokeColor;
        }
      }
    });
  }

  renderOrientationGizmo() {
    const ctx = this.ctx;
    ctx.save();
    const gx = 45;
    const gy = this.height - 45;
    const gLen = 26;

    const cosY = Math.cos(this.cam.rotY), sinY = Math.sin(this.cam.rotY);
    const cosX = Math.cos(this.cam.rotX), sinX = Math.sin(this.cam.rotX);

    const xEnd = { x: gx + gLen * cosY, y: gy + gLen * sinX * sinY };
    const yEnd = { x: gx, y: gy - gLen * cosX };
    const zEnd = { x: gx + gLen * sinY, y: gy - gLen * sinX * cosY };

    ctx.lineWidth = 2;
    // X
    ctx.strokeStyle = '#ef4444';
    ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(xEnd.x, xEnd.y); ctx.stroke();
    // Y
    ctx.strokeStyle = '#10b981';
    ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(yEnd.x, yEnd.y); ctx.stroke();
    // Z
    ctx.strokeStyle = '#00f0ff';
    ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(zEnd.x, zEnd.y); ctx.stroke();

    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px "JetBrains Mono", monospace';
    ctx.fillText('X', xEnd.x + 3, xEnd.y);
    ctx.fillText('Y', yEnd.x + 3, yEnd.y);
    ctx.fillText('Z', zEnd.x + 3, zEnd.y);

    ctx.restore();
  }

  getThermalColor(tempC) {
    if (tempC < 160) return '#10b981';
    if (tempC < 195) return '#f59e0b';
    return '#ef4444';
  }

  drawBoxEdges(p) {
    const ctx = this.ctx;
    ctx.beginPath();
    ctx.moveTo(p[0].x, p[0].y); ctx.lineTo(p[1].x, p[1].y);
    ctx.lineTo(p[2].x, p[2].y); ctx.lineTo(p[3].x, p[3].y); ctx.closePath();
    ctx.moveTo(p[4].x, p[4].y); ctx.lineTo(p[5].x, p[5].y);
    ctx.lineTo(p[6].x, p[6].y); ctx.lineTo(p[7].x, p[7].y); ctx.closePath();
    ctx.moveTo(p[0].x, p[0].y); ctx.lineTo(p[4].x, p[4].y);
    ctx.moveTo(p[1].x, p[1].y); ctx.lineTo(p[5].x, p[5].y);
    ctx.moveTo(p[2].x, p[2].y); ctx.lineTo(p[6].x, p[6].y);
    ctx.moveTo(p[3].x, p[3].y); ctx.lineTo(p[7].x, p[7].y);
    ctx.stroke();
  }

  drawQuad(p1, p2, p3, p4, fillStyle) {
    const ctx = this.ctx;
    ctx.fillStyle = fillStyle;
    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.lineTo(p3.x, p3.y);
    ctx.lineTo(p4.x, p4.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
}

window.AeroEngine3D = AeroEngine3D;
