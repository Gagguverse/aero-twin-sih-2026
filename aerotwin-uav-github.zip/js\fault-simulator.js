/* ==========================================================================
   AERO-TWIN: INTERACTIVE FAULT INJECTION SANDBOX & SCENARIO MANAGER
   Pre-configured SIH Evaluator Scenarios & Dynamic Manual Injector
   ========================================================================== */

class FaultSimulator {
  constructor(telemetryEngine, soundFx) {
    this.telemetryEngine = telemetryEngine;
    this.soundFx = soundFx;
    this.currentScenario = 'nominal';
  }

  resetToNominalBaseline() {
    this.telemetryEngine.resetFaults();
    const state = this.telemetryEngine.state;
    this.telemetryEngine.setAltitude(18000);
    this.telemetryEngine.setThrottle(0.75);
    state.cht = [168, 165, 172, 166];
    state.egt = [782, 778, 795, 781];
    state.oilPress = 52.4;
    state.oilTemp = 88.5;
    state.map = 34.5;
    state.rpm = 4200;
    state.fuelRemainingKg = 184.2;
    state.fuelWallOpen = true;
    state.afr = 14.7;
    state.vibrationRms = 1.65;
  }

  loadScenario(scenarioKey) {
    this.currentScenario = scenarioKey;
    this.resetToNominalBaseline();

    const state = this.telemetryEngine.state;

    switch (scenarioKey) {
      case 'nominal':
        if (this.soundFx) this.soundFx.playChirp();
        break;

      case 'cyl3_thermal':
        // Cylinder 3 overheating + knock detonation
        this.telemetryEngine.setAltitude(18000);
        this.telemetryEngine.setThrottle(0.82);
        this.telemetryEngine.setFault('cylHeatBias', [0, 0, 72, 0]); // Spikes CHT 3 > 235°C
        state.cht[2] = 224;
        state.egt[2] = 865;
        state.vibrationRms = 3.6;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'turbo_wastegate':
        // Wastegate jammed open -> loss of boost
        this.telemetryEngine.setAltitude(22000);
        this.telemetryEngine.setThrottle(0.85);
        this.telemetryEngine.setFault('turboWastegateLeak', 0.85);
        state.map = 23.2;
        state.rpm = 3750;
        if (this.soundFx) this.soundFx.playCaution();
        break;

      case 'injector_clog':
        // Injector 2 clogging
        this.telemetryEngine.setAltitude(18000);
        this.telemetryEngine.setThrottle(0.72);
        this.telemetryEngine.setFault('injectorClog', [0, 0.70, 0, 0]);
        state.cht[1] = 205;
        state.egt[1] = 850;
        state.afr = 17.5;
        if (this.soundFx) this.soundFx.playCaution();
        break;

      case 'oil_cavitation':
        // Oil pump cavitation & bearing wear
        this.telemetryEngine.setAltitude(16000);
        this.telemetryEngine.setThrottle(0.78);
        this.telemetryEngine.setFault('oilPumpWear', 0.80);
        this.telemetryEngine.setFault('bearingDamage', 0.65);
        state.oilPress = 18.5;
        state.oilTemp = 112.0;
        state.vibrationRms = 4.2;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'sensor_drift':
        // Sensor Drift / Calibration Failure: CHT #4 thermistor sensor drifts +65°C artificially
        this.telemetryEngine.setAltitude(18000);
        this.telemetryEngine.setThrottle(0.75);
        this.telemetryEngine.setFault('sensorDrift', 68);
        state.cht[3] = 236; // CHT #4 reads high, but EGT and vibration remain nominal!
        state.egt[3] = 780; // Physics residual proves sensor drift rather than real combustion anomaly
        if (this.soundFx) this.soundFx.playCaution();
        break;

      case 'combustion_instability':
        // Combustion Instability & Cycle-to-Cycle Misfire
        this.telemetryEngine.setAltitude(18000);
        this.telemetryEngine.setThrottle(0.76);
        this.telemetryEngine.setFault('combustionInstability', 0.85);
        this.telemetryEngine.setFault('timingBias', -4.5); // Retarded ignition timing
        state.afr = 16.8;
        state.vibrationRms = 3.4;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'alternator_failure':
        // Electrical bus fault / Alternator failure
        this.telemetryEngine.setFault('alternatorFault', true);
        state.batteryVolt = 23.8;
        state.alternatorAmps = 0;
        state.alternatorHealth = 12.0;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'env_high_altitude':
        this.telemetryEngine.setEnvironmentalProfile('high_altitude');
        if (this.soundFx) this.soundFx.playChirp();
        break;

      case 'env_hot_weather':
        this.telemetryEngine.setEnvironmentalProfile('hot_weather');
        if (this.soundFx) this.soundFx.playChirp();
        break;

      case 'env_endurance':
        this.telemetryEngine.setEnvironmentalProfile('endurance');
        if (this.soundFx) this.soundFx.playChirp();
        break;

      case 'env_throttle_burst':
        this.telemetryEngine.setEnvironmentalProfile('throttle_burst');
        if (this.soundFx) this.soundFx.playChirp();
        break;

      default:
        break;
    }
  }

  setManualCylinderHeat(cylIdx, tempAdd) {
    const current = [...this.telemetryEngine.faults.cylHeatBias];
    current[cylIdx] = tempAdd;
    this.telemetryEngine.setFault('cylHeatBias', current);
    if (tempAdd > 0) {
      this.telemetryEngine.state.cht[cylIdx] = Math.max(this.telemetryEngine.state.cht[cylIdx], 165 + tempAdd * 0.8);
    }
  }

  setManualWastegateLeak(val) {
    this.telemetryEngine.setFault('turboWastegateLeak', val);
  }

  setManualOilPumpWear(val) {
    this.telemetryEngine.setFault('oilPumpWear', val);
    if (val > 0.5) {
      this.telemetryEngine.state.oilPress = Math.min(this.telemetryEngine.state.oilPress, 52 - val * 32);
    }
  }

  setManualBearingDamage(val) {
    this.telemetryEngine.setFault('bearingDamage', val);
  }

  triggerComponentEmergency(compKey) {
    this.resetToNominalBaseline();
    const state = this.telemetryEngine.state;
    this.currentScenario = `emergency_${compKey}`;

    switch (compKey) {
      case 'cyl1':
        this.telemetryEngine.setFault('cylHeatBias', [75, 0, 0, 0]);
        state.cht[0] = 238;
        state.egt[0] = 882;
        state.vibrationRms = 3.2;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'cyl2':
        this.telemetryEngine.setFault('injectorClog', [0, 0.85, 0, 0]);
        state.cht[1] = 216;
        state.egt[1] = 862;
        state.afr = 17.8;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'cyl3':
        this.telemetryEngine.setFault('cylHeatBias', [0, 0, 80, 0]);
        state.cht[2] = 244;
        state.egt[2] = 894;
        state.vibrationRms = 3.9;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'cyl4':
        this.telemetryEngine.setFault('cylHeatBias', [0, 0, 0, 74]);
        state.cht[3] = 234;
        state.egt[3] = 872;
        state.vibrationRms = 3.1;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'turbo':
        this.telemetryEngine.setFault('turboWastegateLeak', 0.90);
        state.map = 19.5;
        state.rpm = 3580;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'crankshaft':
        this.telemetryEngine.setFault('bearingDamage', 0.85);
        this.telemetryEngine.setFault('oilPumpWear', 0.45);
        state.vibrationRms = 4.85;
        state.oilPress = 26.2;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'oil_system':
        this.telemetryEngine.setFault('oilPumpWear', 0.90);
        this.telemetryEngine.setFault('bearingDamage', 0.60);
        state.oilPress = 15.8;
        state.oilTemp = 118.5;
        state.vibrationRms = 3.9;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'fuel_system':
        this.telemetryEngine.toggleFuelWall(true);
        state.fuelWallOpen = false;
        state.fuelFlow = 0.0;
        state.fuelPressure = 0.0;
        state.rpm = 1450;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'gearbox':
        this.telemetryEngine.setFault('bearingDamage', 0.70);
        state.vibrationRms = 4.3;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      case 'uav_airframe':
        this.telemetryEngine.toggleFuelWall(true);
        state.fuelWallOpen = false;
        state.fuelFlow = 0.0;
        state.fuelPressure = 0.0;
        state.rpm = 1200;
        state.map = 14.7;
        if (this.soundFx) this.soundFx.playAlarm();
        break;

      default:
        this.loadScenario('cyl3_thermal');
        break;
    }
  }

  clearComponentEmergency() {
    this.loadScenario('nominal');
    if (this.soundFx) this.soundFx.playChirp();
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FaultSimulator;
}
if (typeof window !== 'undefined') {
  window.FaultSimulator = FaultSimulator;
}
