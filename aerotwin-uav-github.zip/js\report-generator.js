/* ==========================================================================
   AERO-TWIN: DRDO & CEMILAC AIRWORTHINESS REPORT GENERATOR
   Military Work-Order Dispatcher, Incident Log & Telemetry CSV Exporter
   ========================================================================== */

class ReportGenerator {
  constructor(telemetryEngine, aiEngine) {
    this.telemetry = telemetryEngine;
    this.ai = aiEngine;
  }

  generateMissionReport() {
    return this.generateHtmlReport();
  }

  generateHtmlReport() {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0];
    const state = this.telemetry.state;
    const ai = this.ai;

    return `
      <div class="report-document" id="printable-report">
        <div class="report-header-crest">
          <div class="report-crest-title">
            <h2>DEFENCE RESEARCH & DEVELOPMENT ORGANISATION (DRDO)</h2>
            <p>DIRECTORATE OF AERONAUTICS & CEMILAC AIRWORTHINESS AUDIT</p>
          </div>
          <div style="text-align: right;">
            <div style="font-family: var(--font-hud); font-size: 13px; color: var(--cyan-hud);">FORM DD-AERO-26054</div>
            <div style="font-size: 10px; color: var(--text-muted);">SECURITY LEVEL: RESTRICTED / DEFENCE USE</div>
          </div>
        </div>

        <div class="report-meta-grid">
          <div><strong style="color:var(--text-muted)">UAV PLATFORM:</strong><br><span style="color:#fff">TAPAS-BH-201 MALE UAV</span></div>
          <div><strong style="color:var(--text-muted)">TAIL NUMBER:</strong><br><span style="color:var(--cyan-hud)">DRDO-TAPAS-004</span></div>
          <div><strong style="color:var(--text-muted)">ENGINE TYPE:</strong><br><span style="color:#fff">4-CYL TURBOCHARGED BOXER</span></div>
          <div><strong style="color:var(--text-muted)">ENG SERIAL NO:</strong><br><span style="color:#fff">AE-914-IND-0824</span></div>
          <div><strong style="color:var(--text-muted)">DATE & TIME:</strong><br><span style="color:#fff">${dateStr} ${timeStr} IST</span></div>
          <div><strong style="color:var(--text-muted)">TOTAL FLIGHT HRS:</strong><br><span style="color:#fff">482.6 HRS</span></div>
          <div><strong style="color:var(--text-muted)">DIGITAL TWIN STATUS:</strong><br><span style="color:${ai.status === 'NOMINAL' ? 'var(--emerald-safe)' : 'var(--crimson-crit)'}">${ai.status}</span></div>
          <div><strong style="color:var(--text-muted)">HEALTH INDEX (HI):</strong><br><span style="color:var(--cyan-hud); font-weight:700;">${ai.healthIndex.toFixed(1)}%</span></div>
        </div>

        <h3 style="font-family: var(--font-hud); font-size: 12px; color: var(--cyan-hud); margin-top: 20px; border-bottom: 1px solid rgba(0,240,255,0.2); padding-bottom: 4px;">
          1. REAL-TIME AI DIAGNOSTIC INFERENCE & ANOMALY ATTRIBUTION
        </h3>
        <table class="report-table">
          <thead>
            <tr>
              <th>Diagnostic Parameter</th>
              <th>Monitored Reading</th>
              <th>Baseline Norm</th>
              <th>Status / AI Impact</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Engine Speed (RPM)</td>
              <td>${Math.round(state.rpm)} RPM</td>
              <td>4000 - 4400 RPM</td>
              <td style="color:var(--emerald-safe)">NOMINAL</td>
            </tr>
            <tr>
              <td>Manifold Absolute Pressure (MAP)</td>
              <td>${state.map.toFixed(1)} inHg</td>
              <td>32.0 - 36.0 inHg</td>
              <td style="color:${state.map < 26 ? 'var(--crimson-crit)' : 'var(--emerald-safe)'}">${state.map < 26 ? 'BOOST DEFICIT' : 'NOMINAL'}</td>
            </tr>
            <tr>
              <td>Peak Cylinder Head Temp (CHT)</td>
              <td>Cyl #3: ${Math.round(state.cht[2])}°C (Avg: ${Math.round(state.cht[0])}°C)</td>
              <td>&lt; 180°C</td>
              <td style="color:${state.cht[2] > 200 ? 'var(--crimson-crit)' : 'var(--emerald-safe)'}">${state.cht[2] > 200 ? 'THERMAL RUNAWAY' : 'NORMAL'}</td>
            </tr>
            <tr>
              <td>Lubrication Pressure / Temp</td>
              <td>${state.oilPress.toFixed(1)} PSI / ${Math.round(state.oilTemp)}°C</td>
              <td>45 - 60 PSI / &lt; 95°C</td>
              <td style="color:${state.oilPress < 30 ? 'var(--crimson-crit)' : 'var(--emerald-safe)'}">${state.oilPress < 30 ? 'CAVITATION' : 'NOMINAL'}</td>
            </tr>
            <tr>
              <td>Overall Vibration RMS</td>
              <td>${state.vibrationRms.toFixed(2)} mm/s</td>
              <td>&lt; 2.5 mm/s</td>
              <td style="color:${state.vibrationRms > 2.8 ? 'var(--crimson-crit)' : 'var(--emerald-safe)'}">${state.vibrationRms > 2.8 ? 'ELEVATED' : 'NOMINAL'}</td>
            </tr>
            <tr>
              <td>Projected Remaining Useful Life (RUL)</td>
              <td colspan="2"><strong style="color:var(--cyan-hud)">${ai.rulHours} Flight Hours</strong> (95% Confidence)</td>
              <td style="color:var(--text-secondary)">PINN Hybrid Model</td>
            </tr>
          </tbody>
        </table>

        <h3 style="font-family: var(--font-hud); font-size: 12px; color: var(--cyan-hud); margin-top: 24px; border-bottom: 1px solid rgba(0,240,255,0.2); padding-bottom: 4px;">
          2. ROOT CAUSE CLASSIFICATION & MAINTENANCE DIRECTIVES
        </h3>
        <div style="background: rgba(255,255,255,0.02); border-left: 3px solid ${ai.status === 'NOMINAL' ? 'var(--emerald-safe)' : 'var(--crimson-crit)'}; padding: 12px; margin-top: 10px; font-size: 11.5px; line-height: 1.6;">
          <strong style="color:#fff">PRIMARY FINDING:</strong> ${ai.detectedFault}<br>
          <strong style="color:#fff">GROUND CREW ACTION:</strong>
          ${ai.detectedFault.includes('Thermal Runaway') 
            ? 'Ground crew to perform borescope inspection of Cylinder #3 intake/exhaust valves and calibrate injector pulse width. Replace spark plug set.'
            : ai.detectedFault.includes('Wastegate')
            ? 'Inspect turbocharger wastegate bellcrank mechanical linkage and pneumatic servo line. Perform high-altitude chamber pressure leak check.'
            : ai.detectedFault.includes('Oil Pump')
            ? 'Flush lubrication circuit. Inspect oil pump gerotor teeth for cavitation erosion. Send 100ml oil sample for spectrochemical metal wear analysis.'
            : 'No immediate corrective action required. Engine telemetry is within designated CEMILAC airworthiness parameters.'}
        </div>

        <div class="report-sign-off">
          <div>
            <strong>AI FLIGHT RECORDER:</strong> VALIDATED (CAN-429 LINK OK)<br>
            <strong>CHECKSUM:</strong> 0x7E3A-99B1-26054
          </div>
          <div style="text-align: right;">
            <strong>CERTIFYING AIRWORTHINESS OFFICER:</strong><br>
            <span style="font-family: var(--font-hud); color: var(--cyan-hud);">DRDO / ADE PROPULSION WING</span>
          </div>
        </div>
      </div>
    `;
  }

  exportCsv() {
    const replayLog = this.telemetry.replayLog || [];
    const csvRows = [];
    csvRows.push("Timestamp,Phase,RPM,MAP_inHg,FuelFlow_LPH,CHT1,CHT2,CHT3,CHT4,EGT1,EGT2,EGT3,EGT4,OilPress_PSI,OilTemp_C,Vibe_RMS,BatteryVolt_V,FADEC_Advance_Deg,HealthIndex");
    
    if (replayLog.length > 0) {
      replayLog.forEach(frame => {
        const ts = frame.timestamp || new Date().toISOString();
        const ph = frame.phase || 'CRUISE';
        const rpm = Math.round(frame.rpm || 4200);
        const map = (frame.map || 34.5).toFixed(2);
        const ff = (frame.fuelFlow || 24.8).toFixed(2);
        const c1 = Math.round(frame.cht ? frame.cht[0] : 168);
        const c2 = Math.round(frame.cht ? frame.cht[1] : 165);
        const c3 = Math.round(frame.cht ? frame.cht[2] : 171);
        const c4 = Math.round(frame.cht ? frame.cht[3] : 166);
        const e1 = Math.round(frame.egt ? frame.egt[0] : 780);
        const e2 = Math.round(frame.egt ? frame.egt[1] : 775);
        const e3 = Math.round(frame.egt ? frame.egt[2] : 792);
        const e4 = Math.round(frame.egt ? frame.egt[3] : 778);
        const op = (frame.oilPress || 52.4).toFixed(1);
        const ot = Math.round(frame.oilTemp || 88.5);
        const vr = (frame.vibrationRms || 1.8).toFixed(2);
        const bv = (frame.batteryVolt || 28.2).toFixed(1);
        const it = (frame.injectionTimingDeg || 24.0).toFixed(1);
        const hi = (this.ai ? this.ai.healthIndex : 98.5).toFixed(1);
        csvRows.push(`${ts},${ph},${rpm},${map},${ff},${c1},${c2},${c3},${c4},${e1},${e2},${e3},${e4},${op},${ot},${vr},${bv},${it},${hi}`);
      });
    } else {
      const s = this.telemetry.state;
      const ts = new Date().toISOString();
      const hi = (this.ai ? this.ai.healthIndex : 98.5).toFixed(1);
      csvRows.push(`${ts},LIVE,${Math.round(s.rpm)},${s.map.toFixed(2)},${s.fuelFlow.toFixed(2)},${Math.round(s.cht[0])},${Math.round(s.cht[1])},${Math.round(s.cht[2])},${Math.round(s.cht[3])},${Math.round(s.egt[0])},${Math.round(s.egt[1])},${Math.round(s.egt[2])},${Math.round(s.egt[3])},${s.oilPress.toFixed(1)},${Math.round(s.oilTemp)},${s.vibrationRms.toFixed(2)},${s.batteryVolt.toFixed(1)},${s.injectionTimingDeg.toFixed(1)},${hi}`);
    }

    const encodedUri = "data:text/csv;charset=utf-8," + encodeURIComponent(csvRows.join("\r\n"));
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `AERO_TWIN_DRDO_TELEMETRY_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ReportGenerator;
}
if (typeof window !== 'undefined') {
  window.ReportGenerator = ReportGenerator;
}
