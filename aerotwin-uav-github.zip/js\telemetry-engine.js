/* ==========================================================================
   AERO-TWIN: REAL-TIME THERMODYNAMIC & TELEMETRY SIMULATION ENGINE
   Physics-based 0D/1D Aero Piston Engine Model with FFT Vibration & ARINC-429
   ========================================================================== */

class TelemetryEngine {
  constructor() {
    // Flight & Environmental Conditions
    this.altitude = 18000;    // Feet (MALE UAV cruise)
    this.ambientTemp = -21;   // Standard ISA temp at 18k ft (°C)
    this.ambientPress = 14.9; // inHg (~50.5 kPa at 18k ft)
    this.throttle = 0.75;     // 75% loiter throttle
    this.mixture = 1.0;       // Lambda 1.0 stoichiometric
    this.currentEnvProfile = 'nominal_cruise'; // 'nominal_cruise' | 'high_altitude' | 'hot_weather' | 'endurance' | 'throttle_burst'

    // Active Injected Fault Biases
    this.faults = {
      cylHeatBias: [0, 0, 0, 0], // CHT temperature bias per cylinder
      turboWastegateLeak: 0,     // 0 (none) to 1.0 (fully stuck open)
      injectorClog: [0, 0, 0, 0],// Injector restriction ratio 0 to 0.8
      oilPumpWear: 0,            // 0 (nominal) to 1.0 (severe cavitation)
      bearingDamage: 0,          // 0 to 1.0
      fuelWallCutoff: false,     // Fuel Firewall Emergency Shutoff Valve
      fuelPressureLoss: 0,       // 0 to 1.0
      mixtureBias: 0,            // -0.3 (Rich) to +0.4 (Lean / Knock)
      sensorDrift: 0,            // CHT #4 thermistor sensor drift offset (°C)
      combustionInstability: 0,  // 0 to 1.0 (misfire, flame flutter, pressure variance)
      alternatorFault: false,    // Alternator regulator / field failure
      timingBias: 0              // Ignition timing advance/retard offset (°BTDC)
    };

    // Telemetry State Buffer (Aligned with DRDO SIH-26054)
    this.state = {
      rpm: 4200,
      map: 34.5,
      cht: [168, 166, 171, 167],
      egt: [782, 778, 795, 781],
      oilPress: 52.4,
      oilTemp: 88.5,
      fuelFlow: 24.8,            // L/hr
      fuelRemainingKg: 184.2,    // Total fuel mass in KG
      fuelPressure: 43.5,        // Rail pressure in PSI
      fuelWallOpen: true,        // Firewall fuel valve status
      enduranceHrs: 10.3,        // Calculated mission endurance
      afr: 14.7,                 // Air-Fuel Ratio (14.7 = Stoich)
      vibrationRms: 1.8,
      // Battery & Alternator Health (DRDO Spec Section B)
      batteryVolt: 28.2,         // 28V military DC bus voltage
      alternatorAmps: 38.5,      // Alternator load current
      alternatorHealth: 99.4,    // % health index
      // Injection Timing & FADEC Parameters (DRDO Spec Section B)
      injectionTimingDeg: 24.0,  // Advance in degrees BTDC
      injectionPulseWidthMs: 4.25,// Injector on-time in milliseconds
      // Performance & Efficiency Maps (DRDO Spec Section D/F)
      bte: 32.8,                 // Brake Thermal Efficiency (%)
      bsfc: 236,                 // Brake Specific Fuel Consumption (g/kWh)
      // Misfire & Sensor Drift Flags (DRDO Spec Section C)
      misfireRate: 0,            // % misfire rate
      sensorDriftDetected: false,// Sensor drift anomaly flag
      faults: { ...this.faults },
      canFrames: []
    };

    // FFT Vibration Spectrum (0 to 4000 Hz in 64 frequency bins)
    this.fftBins = new Float32Array(64);
    this.vibeAxes = {
      radial: new Float32Array(64),
      vertical: new Float32Array(64),
      axial: new Float32Array(64)
    };
    this.dominantFreq = 70;
    this.dominantAmp = 0.95;

    // Data Source: 'SIMULATED' | 'HARDWARE_SERIAL' | 'HARDWARE_API' | 'BLACKBOX_REPLAY'
    this.source = 'SIMULATED';
    this.hardwareDeviceName = 'None';
    this.hardwarePacketsCount = 0;

    // Mission Blackbox Simulation & Replay Engine (DRDO Spec Section E)
    this.isReplaying = false;
    this.replaySpeed = 1.0;
    this.replayIndex = 0;
    this.replayLog = this.generateHistoricalMissionLog();
    this.replayBuffer = this.replayLog;
    this.historyBuffer = this.replayLog;

    // Callbacks
    this.listeners = [];

    // Telemetry Tick Loop
    this.tickInterval = 100; // 10 Hz nominal
    this.startTick();
  }

  setSource(sourceType, deviceName = 'Connected Hardware') {
    this.source = sourceType;
    this.hardwareDeviceName = deviceName;
  }

  ingestHardwarePacket(packet) {
    this.hardwarePacketsCount++;
    if (packet.rpm !== undefined) this.state.rpm = Number(packet.rpm);
    if (packet.map !== undefined) this.state.map = Number(packet.map);
    if (Array.isArray(packet.cht)) {
      this.state.cht = packet.cht.map(Number);
    }
    if (Array.isArray(packet.egt)) {
      this.state.egt = packet.egt.map(Number);
    }
    if (packet.oilPress !== undefined) this.state.oilPress = Number(packet.oilPress);
    if (packet.oilTemp !== undefined) this.state.oilTemp = Number(packet.oilTemp);
    if (packet.fuelFlow !== undefined) this.state.fuelFlow = Number(packet.fuelFlow);
    if (packet.vibrationRms !== undefined) this.state.vibrationRms = Number(packet.vibrationRms);
    if (packet.rawCan) {
      this.state.canFrames.push({
        time: new Date().toISOString().substring(11, 23),
        id: packet.rawCan.id || '0x290',
        raw: packet.rawCan.raw || 'HW-FRAME',
        eng: packet.rawCan.eng || `HW SENSOR RX`
      });
      if (this.state.canFrames.length > 25) this.state.canFrames.shift();
    }
    this.notifyListeners();
  }

  onUpdate(callback) {
    this.listeners.push(callback);
  }

  setThrottle(val) {
    this.throttle = Math.max(0.1, Math.min(1.0, val));
  }

  setAltitude(altFt) {
    this.altitude = Math.max(0, Math.min(32000, altFt));
    // Standard Atmosphere Barometric Pressure Model
    this.ambientPress = 29.92 * Math.pow(1 - 6.875e-6 * this.altitude, 5.256);
    this.ambientTemp = 15 - (this.altitude * 0.00198); // ISA temperature lapse
  }

  setFault(faultKey, value) {
    if (this.faults.hasOwnProperty(faultKey)) {
      this.faults[faultKey] = value;
    }
  }

  injectFault(faultKey, value) {
    if (this.faults.hasOwnProperty(faultKey)) {
      this.faults[faultKey] = value;
    } else if (faultKey === 'wastegateJam') {
      this.faults.turboWastegateLeak = value ? 0.85 : 0;
    } else if (faultKey === 'oilCavitation') {
      this.faults.oilPumpWear = value ? 0.80 : 0;
      this.faults.bearingDamage = value ? 0.65 : 0;
    }
  }

  resetFaults() {
    this.faults = {
      cylHeatBias: [0, 0, 0, 0],
      turboWastegateLeak: 0,
      injectorClog: [0, 0, 0, 0],
      oilPumpWear: 0,
      bearingDamage: 0,
      fuelWallCutoff: false,
      fuelPressureLoss: 0,
      mixtureBias: 0,
      sensorDrift: 0,
      combustionInstability: 0,
      alternatorFault: false,
      timingBias: 0
    };
    this.state.fuelWallOpen = true;
    this.state.sensorDriftDetected = false;
    this.state.misfireRate = 0;
  }

  clearAllFaults() {
    this.resetFaults();
  }

  setFuelWall(isOpen) {
    this.faults.fuelWallCutoff = !isOpen;
    this.state.fuelWallOpen = !!isOpen;
    return this.faults.fuelWallCutoff;
  }

  toggleFuelWall(cutoffState) {
    this.faults.fuelWallCutoff = (cutoffState !== undefined) ? cutoffState : !this.faults.fuelWallCutoff;
    this.state.fuelWallOpen = !this.faults.fuelWallCutoff;
    return this.faults.fuelWallCutoff;
  }

  setMixture(bias) {
    this.faults.mixtureBias = Math.max(-0.4, Math.min(0.4, bias));
  }

  setFuelPressureLoss(loss) {
    this.faults.fuelPressureLoss = Math.max(0, Math.min(1.0, loss));
  }

  // Environmental Condition Simulation (DRDO Spec Section E)
  setEnvironmentalProfile(profile) {
    this.currentEnvProfile = profile;
    switch (profile) {
      case 'high_altitude':
        // 28,000 FT MSL Thin Air & Low Temperature (-42°C)
        this.setAltitude(28000);
        this.setThrottle(0.86);
        this.ambientTemp = -42;
        break;
      case 'hot_weather':
        // Hot-Weather Tarmac Soak (+45°C, high density-altitude)
        this.setAltitude(3500);
        this.setThrottle(0.78);
        this.ambientTemp = 45;
        break;
      case 'endurance':
        // Long Endurance Mission Loiter (Fuel Conservation)
        this.setAltitude(22000);
        this.setThrottle(0.58);
        this.setMixture(-0.06);
        break;
      case 'throttle_burst':
        // Rapid Throttle Transient Burst (Snap from 20% idle to 100% WOT)
        this.setAltitude(18000);
        this.setThrottle(0.20);
        setTimeout(() => { this.setThrottle(1.0); }, 1200);
        setTimeout(() => { this.setThrottle(0.75); }, 4500);
        break;
      case 'nominal_cruise':
      default:
        this.setAltitude(18000);
        this.setThrottle(0.75);
        this.setMixture(0);
        break;
    }
    return this.currentEnvProfile;
  }

  // Blackbox Mission Simulation & Replay Engine (DRDO Spec Section E)
  generateHistoricalMissionLog() {
    const log = [];
    const baseTime = Date.now() - 3600000;
    for (let sec = 0; sec < 60; sec++) {
      let alt = 18000 + Math.sin(sec / 10) * 800;
      let throt = 0.72 + (sec > 25 && sec < 42 ? 0.14 : 0);
      let rpm = Math.round(4100 + throt * 300 + (Math.random() - 0.5) * 15);
      let map = Number((34.0 + throt * 2.5 + (Math.random() - 0.5) * 0.2).toFixed(1));
      let cyl3Perturb = sec > 32 && sec < 48 ? (sec - 32) * 4.8 : 0;
      let cht = [
        Math.round(168 + Math.sin(sec / 8) * 3),
        Math.round(166 + Math.cos(sec / 8) * 3),
        Math.round(171 + cyl3Perturb + Math.random() * 2),
        Math.round(167 + Math.sin(sec / 6) * 2)
      ];
      let egt = [
        Math.round(782 + Math.random() * 5),
        Math.round(778 + Math.random() * 5),
        Math.round(795 + cyl3Perturb * 1.5 + Math.random() * 6),
        Math.round(781 + Math.random() * 5)
      ];
      let vib = Number((1.7 + (cyl3Perturb > 0 ? 1.4 : 0) + Math.random() * 0.1).toFixed(2));
      log.push({
        sec,
        time: new Date(baseTime + sec * 1000).toISOString().substring(11, 19),
        rpm,
        map,
        cht,
        egt,
        oilPress: Number((52.4 - (cyl3Perturb > 0 ? 6.5 : 0) + Math.random() * 0.2).toFixed(1)),
        oilTemp: Number((88.5 + (cyl3Perturb > 0 ? 14.0 : 0) + Math.random() * 0.2).toFixed(1)),
        fuelFlow: Number((24.5 + throt * 3.0).toFixed(1)),
        batteryVolt: 28.2,
        alternatorAmps: 38.5,
        injectionTimingDeg: 24.0,
        injectionPulseWidthMs: 4.25,
        vibrationRms: vib,
        bte: Number((32.8 - (cyl3Perturb > 0 ? 3.8 : 0)).toFixed(1)),
        bsfc: Math.round(236 + (cyl3Perturb > 0 ? 32 : 0)),
        altitude: Math.round(alt),
        phase: sec < 15 ? "CRUISE CLIMB" : sec < 32 ? "SECTOR LOITER" : sec < 48 ? "CYL-3 PERTURBATION" : "RECOVERY CORRIDOR"
      });
    }
    return log;
  }

  startReplay() {
    this.isReplaying = true;
    this.source = 'BLACKBOX_REPLAY';
  }

  pauseReplay() {
    this.isReplaying = false;
    this.source = 'SIMULATED';
  }

  toggleReplay() {
    if (this.isReplaying) {
      this.pauseReplay();
    } else {
      this.startReplay();
    }
    return this.isReplaying;
  }

  seekReplay(index) {
    this.replayIndex = Math.max(0, Math.min(this.replayLog.length - 1, Number(index)));
    const frame = this.replayLog[Math.floor(this.replayIndex)];
    this.applyReplayFrame(frame);
  }

  setReplaySpeed(spd) {
    this.replaySpeed = Math.max(0.25, Math.min(5.0, Number(spd)));
  }

  stepReplay() {
    if (!this.replayLog || this.replayLog.length === 0) return;
    this.replayIndex += (this.tickInterval / 1000) * this.replaySpeed;
    if (this.replayIndex >= this.replayLog.length) {
      this.replayIndex = 0; // Loop continuous playback
    }
    const idx = Math.floor(this.replayIndex);
    const frame = this.replayLog[idx];
    this.applyReplayFrame(frame);
  }

  applyReplayFrame(frame) {
    if (!frame) return;
    this.state.rpm = frame.rpm;
    this.state.map = frame.map;
    this.state.cht = [...frame.cht];
    this.state.egt = [...frame.egt];
    this.state.oilPress = frame.oilPress;
    this.state.oilTemp = frame.oilTemp;
    this.state.fuelFlow = frame.fuelFlow;
    this.state.batteryVolt = frame.batteryVolt;
    this.state.alternatorAmps = frame.alternatorAmps;
    this.state.injectionTimingDeg = frame.injectionTimingDeg;
    this.state.injectionPulseWidthMs = frame.injectionPulseWidthMs;
    this.state.vibrationRms = frame.vibrationRms;
    this.state.bte = frame.bte;
    this.state.bsfc = frame.bsfc;
    this.altitude = frame.altitude;
    this.notifyListeners();
  }

  startTick() {
    setInterval(() => {
      if (this.isReplaying) {
        this.stepReplay();
        this.computeFftSpectrum();
        this.generateCanBusFrame();
        this.notifyListeners();
        return;
      }
      // If live hardware is supplying data, don't overwrite with simulated model
      if (this.source === 'SIMULATED') {
        this.computePhysicsStep();
        this.computeFftSpectrum();
        this.generateCanBusFrame();
        this.notifyListeners();
      }
    }, this.tickInterval);
  }

  computePhysicsStep() {
    // Check Emergency Fuel Firewall Cutoff Valve (Fuel Wall)
    if (this.faults.fuelWallCutoff) {
      this.state.fuelWallOpen = false;
      this.state.fuelFlow = 0;
      this.state.fuelPressure = 0;
      this.state.rpm = Math.max(0, this.state.rpm - 140);
      this.state.map += (this.ambientPress - this.state.map) * 0.1;
      for (let i = 0; i < 4; i++) {
        this.state.cht[i] += (60 - this.state.cht[i]) * 0.04;
        this.state.egt[i] += (200 - this.state.egt[i]) * 0.08;
      }
      return;
    }

    this.state.fuelWallOpen = true;
    this.state.faults = { ...this.faults };

    // 1. Engine RPM: Based on throttle & turbo boost
    let targetRpm = 1800 + (this.throttle * 3800) - (this.faults.turboWastegateLeak * 600);
    if (this.faults.fuelPressureLoss > 0.6) {
      targetRpm -= this.faults.fuelPressureLoss * 1800; // Fuel starvation
    }
    this.state.rpm += (targetRpm - this.state.rpm) * 0.15 + (Math.random() - 0.5) * 8;
    this.state.rpm = Math.max(1400, Math.min(5800, this.state.rpm));

    // 2. Manifold Absolute Pressure (MAP): Turbocharger pressure ratio
    const baseBoost = 12.0 * this.throttle;
    const turboDegradation = (1 - this.faults.turboWastegateLeak * 0.7);
    const targetMap = (this.ambientPress + baseBoost * turboDegradation);
    this.state.map += (targetMap - this.state.map) * 0.2 + (Math.random() - 0.5) * 0.15;

    // 3. Fuel Subsystem & Consumption Physics
    const normRpm = this.state.rpm / 5000;
    const normMap = this.state.map / 30;
    const pressureMultiplier = Math.max(0.2, 1 - this.faults.fuelPressureLoss * 0.8);
    this.state.fuelFlow = Math.max(0, (18.5 * normRpm * normMap * pressureMultiplier * (1 + this.faults.mixtureBias)) + (Math.random() - 0.5) * 0.2);
    this.state.fuelPressure = Math.max(0, 43.5 * (1 - this.faults.fuelPressureLoss) + (Math.random() - 0.5) * 0.3);
    this.state.afr = Number((14.7 * (1 + this.faults.mixtureBias)).toFixed(1));

    // Continuous Real-Time Fuel Burn (density ~0.72 kg/L)
    this.state.fuelRemainingKg = Math.max(0, this.state.fuelRemainingKg - ((this.state.fuelFlow * 0.72) / 3600) * 0.1);
    this.state.enduranceHrs = Number(((this.state.fuelRemainingKg / 0.72) / Math.max(1, this.state.fuelFlow)).toFixed(1));

    // 4. Cylinder Head Temperatures (CHT 1-4)
    // Nominal CHT: 155°C - 175°C
    for (let i = 0; i < 4; i++) {
      let baseCht = 145 + (this.throttle * 30) + (i % 2 === 0 ? 3 : 0);
      baseCht += this.faults.cylHeatBias[i];
      if (this.faults.injectorClog[i] > 0) {
        baseCht += this.faults.injectorClog[i] * 55;
      }
      this.state.cht[i] += (baseCht - this.state.cht[i]) * 0.08 + (Math.random() - 0.5) * 0.4;
    }

    // 5. Exhaust Gas Temperatures (EGT 1-4)
    // Nominal EGT: 760°C - 810°C
    for (let i = 0; i < 4; i++) {
      let baseEgt = 750 + (this.throttle * 45);
      baseEgt += (this.faults.cylHeatBias[i] * 0.8);
      if (this.faults.injectorClog[i] > 0) {
        baseEgt += this.faults.injectorClog[i] * 70; // Lean burn thermal spike
      }
      this.state.egt[i] += (baseEgt - this.state.egt[i]) * 0.1 + (Math.random() - 0.5) * 1.5;
    }

    // 6. Lubrication: Oil Pressure & Temperature
    let targetOilPress = 54 - (this.faults.oilPumpWear * 34) - ((this.state.rpm - 4200) * 0.001);
    this.state.oilPress += (targetOilPress - this.state.oilPress) * 0.1 + (Math.random() - 0.5) * 0.3;
    this.state.oilPress = Math.max(12, this.state.oilPress);

    let targetOilTemp = 86 + (this.throttle * 12) + (this.faults.oilPumpWear * 28) + (this.faults.bearingDamage * 22);
    this.state.oilTemp += (targetOilTemp - this.state.oilTemp) * 0.05 + (Math.random() - 0.5) * 0.2;

    // 7. Vibration Overall RMS (mm/s)
    let baseVibe = 1.6 + (this.state.rpm / 5000) * 0.6;
    if (this.faults.bearingDamage > 0) baseVibe += this.faults.bearingDamage * 4.5;
    if (this.faults.cylHeatBias[2] > 40) baseVibe += 2.8; // Knock detonation
    this.state.vibrationRms += (baseVibe - this.state.vibrationRms) * 0.2 + (Math.random() - 0.5) * 0.1;

    // 8. Electrical Subsystem (28V DC Mil-STD Bus & Alternator)
    if (this.faults.alternatorFault) {
      this.state.alternatorAmps = Math.max(0, this.state.alternatorAmps - 2.5);
      this.state.batteryVolt = Math.max(22.0, this.state.batteryVolt - 0.05); // Battery discharging under flight avionics load
      this.state.alternatorHealth = 18.0;
    } else {
      const targetVolt = 28.0 + (this.state.rpm / 5000) * 0.4;
      this.state.batteryVolt += (targetVolt - this.state.batteryVolt) * 0.1 + (Math.random() - 0.5) * 0.05;
      const targetAmps = 32.0 + (this.throttle * 9.0);
      this.state.alternatorAmps += (targetAmps - this.state.alternatorAmps) * 0.1 + (Math.random() - 0.5) * 0.2;
      this.state.alternatorHealth = 99.4;
    }
    this.state.batteryVolt = Number(this.state.batteryVolt.toFixed(1));
    this.state.alternatorAmps = Number(this.state.alternatorAmps.toFixed(1));

    // 9. FADEC Injection Timing & Pulse Width (Degrees BTDC & ms)
    const baseAdvance = 18.0 + (this.state.rpm / 5000) * 8.0 - (this.state.map > 30 ? (this.state.map - 30) * 0.3 : 0);
    this.state.injectionTimingDeg = Number((baseAdvance + this.faults.timingBias + (this.faults.combustionInstability > 0 ? (Math.random() - 0.5) * 4.0 : 0)).toFixed(1));
    this.state.injectionPulseWidthMs = Number((2.8 + (this.state.map / 30) * 1.5 * (this.state.fuelFlow / 24)).toFixed(2));

    // 10. Engine Performance Maps: Brake Thermal Efficiency (BTE %) & BSFC (g/kWh)
    let efficiencyPenalty = 0;
    if (this.faults.cylHeatBias[2] > 20) efficiencyPenalty += 4.5;
    if (this.faults.turboWastegateLeak > 0.3) efficiencyPenalty += this.faults.turboWastegateLeak * 6.0;
    if (this.faults.combustionInstability > 0) efficiencyPenalty += this.faults.combustionInstability * 5.0;
    const targetBte = Math.max(16.0, 33.2 - efficiencyPenalty - Math.abs(this.state.afr - 14.7) * 1.2);
    this.state.bte = Number((this.state.bte + (targetBte - this.state.bte) * 0.1).toFixed(1));
    this.state.bsfc = Math.round(230 + (1 - this.state.bte / 34) * 90);

    // 11. Sensor Drift Simulation (CHT #4 Thermistor Open-Circuit Drift)
    if (this.faults.sensorDrift > 0) {
      this.state.cht[3] += this.faults.sensorDrift;
      this.state.sensorDriftDetected = true;
    } else {
      this.state.sensorDriftDetected = false;
    }

    // 12. Combustion Instability & Cyclic Variance (Misfire)
    if (this.faults.combustionInstability > 0) {
      this.state.misfireRate = Math.round(this.faults.combustionInstability * 14 + Math.random() * 4);
      this.state.rpm += (Math.random() - 0.5) * 60; // Rough idle/flutter
    } else {
      this.state.misfireRate = 0;
    }
  }

  computeFftSpectrum() {
    if (!this.vibeAxes) {
      this.vibeAxes = {
        radial: new Float32Array(64),
        vertical: new Float32Array(64),
        axial: new Float32Array(64)
      };
    }

    const shaftBin = Math.max(1, Math.min(63, Math.round((this.state.rpm / 60) / 62.5)));
    const misfire = this.faults.combustionInstability || 0;
    const bearing = this.faults.bearingDamage || 0;
    const knockActive = (this.state.cht[2] > 205 || (this.faults.cylHeatBias && this.faults.cylHeatBias[2] > 35));

    for (let b = 0; b < 64; b++) {
      let amp = 0.06 + Math.random() * 0.04; // Baseline noise floor

      // 0.5X Sub-Harmonic (Combustion cycle flutter, elevated on misfire)
      if (b <= 1) {
        amp += 0.12 + (misfire * 1.5);
      }
      // 1X Shaft Fundamental (~70 Hz)
      if (b === shaftBin) {
        amp += 0.88 + (this.state.rpm / 6000) * 0.2;
      } else if (Math.abs(b - shaftBin) === 1) {
        amp += 0.22; // Natural spectral leakage skirt
      }
      // 2X Reciprocating Second Harmonic (~140 Hz)
      if (b === shaftBin * 2 && b < 64) {
        amp += 0.44;
      }
      // 4X Cylinder Combustion Firing Cadence (~280 Hz)
      if (b === shaftBin * 4 && b < 64) {
        amp += 0.28;
      }
      // PRSU Helical Gear Mesh / Bearing Pass Frequency (1800 Hz -> ~Bin 28-30)
      if (b >= 28 && b <= 30) {
        amp += 0.16 + (bearing * 2.2);
      } else if (b === 27 || b === 31) {
        amp += 0.08 + (bearing * 0.6); // Sideband
      }
      // Ultrasonic Knock Detonation Peak (3200 Hz -> ~Bin 50-52)
      if (b >= 50 && b <= 52 && knockActive) {
        amp += 2.4;
      }

      this.fftBins[b] = amp;

      // Tri-Axial Breakdown channels
      this.vibeAxes.radial[b] = amp * (b === shaftBin ? 1.2 : (b >= 28 && b <= 30) ? 1.35 : 0.75);
      this.vibeAxes.vertical[b] = amp * ((b === shaftBin * 2 || b === shaftBin * 4) ? 1.35 : (b >= 50 && b <= 52) ? 1.5 : 0.8);
      this.vibeAxes.axial[b] = amp * ((b <= 1 || (b >= 28 && b <= 30)) ? 1.3 : 0.7);
    }

    // Determine dominant frequency and peak amplitude
    let maxAmp = 0;
    let maxBin = 0;
    for (let b = 0; b < 64; b++) {
      if (this.fftBins[b] > maxAmp) {
        maxAmp = this.fftBins[b];
        maxBin = b;
      }
    }
    this.dominantFreq = Math.round(maxBin * 62.5);
    this.dominantAmp = maxAmp;
  }

  generateCanBusFrame() {
    const timestamp = new Date().toISOString().substring(11, 23);
    // Standard Aero ARINC 429 / CANaerospace IDs:
    // 0x180: Engine RPM & Throttle
    // 0x280: CHT 1-4
    // 0x290: EGT 1-4
    // 0x380: Oil Press / Oil Temp / MAP
    // 0x480: Electrical Bus Voltage & Alternator Current (DRDO Spec)
    // 0x490: FADEC Injection Timing & Pulse Width (DRDO Spec)
    const canIds = [
      {
        id: '0x180',
        raw: `${Math.round(this.state.rpm).toString(16).padStart(4, '0')} ${Math.round(this.throttle * 100).toString(16).padStart(2, '0')}`,
        eng: `RPM: ${Math.round(this.state.rpm)} | TPS: ${Math.round(this.throttle * 100)}%`
      },
      {
        id: '0x280',
        raw: `${Math.round(this.state.cht[0]).toString(16)} ${Math.round(this.state.cht[1]).toString(16)} ${Math.round(this.state.cht[2]).toString(16)} ${Math.round(this.state.cht[3]).toString(16)}`,
        eng: `CHT: [${Math.round(this.state.cht[0])}, ${Math.round(this.state.cht[1])}, ${Math.round(this.state.cht[2])}, ${Math.round(this.state.cht[3])}]°C`
      },
      {
        id: '0x380',
        raw: `${Math.round(this.state.oilPress).toString(16)} ${Math.round(this.state.oilTemp).toString(16)} ${Math.round(this.state.map * 10).toString(16)}`,
        eng: `OP: ${this.state.oilPress.toFixed(1)} PSI | OT: ${Math.round(this.state.oilTemp)}°C | MAP: ${this.state.map.toFixed(1)}"`
      },
      {
        id: '0x480',
        raw: `${Math.round(this.state.batteryVolt * 10).toString(16)} ${Math.round(this.state.alternatorAmps).toString(16)} 00 64`,
        eng: `ELECTRICAL: ${this.state.batteryVolt.toFixed(1)}V BUS | ALT: ${this.state.alternatorAmps.toFixed(1)}A | OK`
      },
      {
        id: '0x490',
        raw: `${Math.round(this.state.injectionTimingDeg * 10).toString(16)} ${Math.round(this.state.injectionPulseWidthMs * 100).toString(16)}`,
        eng: `FADEC TIMING: ${this.state.injectionTimingDeg.toFixed(1)}° BTDC | PW: ${this.state.injectionPulseWidthMs.toFixed(2)}ms | BTE: ${this.state.bte}%`
      }
    ];

    const pick = canIds[Math.floor(Math.random() * canIds.length)];
    this.state.canFrames.push({
      time: timestamp,
      id: pick.id,
      raw: pick.raw.toUpperCase(),
      eng: pick.eng
    });

    if (this.state.canFrames.length > 25) {
      this.state.canFrames.shift();
    }
  }

  notifyListeners() {
    this.listeners.forEach(cb => cb(this.state, this.fftBins));
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TelemetryEngine;
}
if (typeof window !== 'undefined') {
  window.TelemetryEngine = TelemetryEngine;
}
